﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim db = New Database
        ' Dim dt = New DataTable
        With db
            ''-----------------------------------------EMPTY TransactID---------
            .sqlStr = "insert into `form`(`id`, `fullname`, `vaccine_id`) VALUES 
                ('" & TextBox1.Text.Trim & "','" & TextBox2.Text.Trim & "','" & ComboBox1.Text.Trim & "')"
            .sqlDa.InsertCommand = .sqlcm(.sqlStr, .connect)
            .sqlDa.InsertCommand.ExecuteNonQuery()
            .close()
        End With
        MessageBox.Show("Successfully Saved", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

        Dim db2 = New Database
        Dim dt2 As New DataTable
        With db2
            .sqlStr = "SELECT `vaccine` FROM `vaccine` where vaccine = '" & ComboBox1.Text.Trim & "'" 'query string
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
            .close()
        End With
        dt2 = db2.sqlDt

        If dt2.Rows.Count > 0 Then
            MessageBox.Show("ADDANNNn!", "ALERT", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Else
            Dim db1 = New Database
            With db1
                ''-----------------------------------------EMPTY TransactID---------
                .sqlStr = "INSERT INTO `vaccine`(`vaccine`) VALUES 
                ('" & ComboBox1.Text.Trim & "')"
                .sqlDa.InsertCommand = .sqlcm(.sqlStr, .connect)
                .sqlDa.InsertCommand.ExecuteNonQuery()
                .close()
            End With
            MessageBox.Show("Successfully Saved", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

            ' vaccine()
            vaccine2()
        End If
    End Sub



    Sub vaccine()
        '   Dim item As CType(anObject, Integer) 

        Dim db = New Database
        Dim dt As New DataTable
        With db
            ''-----------------------------------------EMPTY TransactID---------
            .sqlStr = "SELECT `vaccine` FROM `vaccine`"
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
            .close()
        End With
        dt = db.sqlDt
        Dim Items = dt.Rows(0).Item(0).ToString
        For i = 0 To dt.Rows.Count - 1
            ComboBox1.Items.Add(dt.Rows(i).Item(0).ToString)
            'result = itexmo(recipient, msg, apicode, pass)
            ' MessageBox.Show(dt.Rows(0).Item(0).ToString)

        Next

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        vaccine()
    End Sub

    Sub vaccine2()
        '   Dim item As CType(anObject, Integer) 

        Dim db = New Database
        Dim dt As New DataTable
        With db
            ''-----------------------------------------EMPTY TransactID---------
            .sqlStr = "Select vaccine from vaccine where vax_id =(Select LAST_INSERT_ID())"
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
            .close()
        End With
        dt = db.sqlDt
        Dim Items = dt.Rows(0).Item(0).ToString
        '  For i = 0 To dt.Rows.Count - 1
        ComboBox1.Items.Add(dt.Rows(0).Item(0).ToString)
        'result = itexmo(recipient, msg, apicode, pass)
        ' MessageBox.Show(dt.Rows(0).Item(0).ToString)

        ' Next

    End Sub
End Class
