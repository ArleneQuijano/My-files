﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class brgy_stat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend1 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea2 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend2 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series2 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea3 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend3 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series3 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea4 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend4 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series4 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea5 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend5 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series5 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea6 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend6 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series6 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(brgy_stat))
        Me.PanelStat = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Chart6 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Chart3 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Chart4 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Chart2 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Chart5 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.PanelStat.SuspendLayout()
        Me.Panel11.SuspendLayout()
        CType(Me.Chart6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel9.SuspendLayout()
        CType(Me.Chart3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        CType(Me.Chart4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel31.SuspendLayout()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel28.SuspendLayout()
        CType(Me.Chart5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel15.SuspendLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel27.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelStat
        '
        Me.PanelStat.AutoScroll = True
        Me.PanelStat.AutoScrollMargin = New System.Drawing.Size(0, 20)
        Me.PanelStat.BackColor = System.Drawing.Color.LightSteelBlue
        Me.PanelStat.Controls.Add(Me.btnBack)
        Me.PanelStat.Controls.Add(Me.Panel11)
        Me.PanelStat.Controls.Add(Me.Panel9)
        Me.PanelStat.Controls.Add(Me.Panel7)
        Me.PanelStat.Controls.Add(Me.Panel31)
        Me.PanelStat.Controls.Add(Me.Panel28)
        Me.PanelStat.Controls.Add(Me.Panel15)
        Me.PanelStat.Controls.Add(Me.Panel27)
        Me.PanelStat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelStat.Location = New System.Drawing.Point(0, 0)
        Me.PanelStat.Name = "PanelStat"
        Me.PanelStat.Size = New System.Drawing.Size(1370, 749)
        Me.PanelStat.TabIndex = 3
        '
        'Panel11
        '
        Me.Panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel11.Controls.Add(Me.Label96)
        Me.Panel11.Controls.Add(Me.Label94)
        Me.Panel11.Controls.Add(Me.Chart6)
        Me.Panel11.Location = New System.Drawing.Point(10, 476)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(682, 215)
        Me.Panel11.TabIndex = 23
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label96.Location = New System.Drawing.Point(391, 178)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(44, 17)
        Me.Label96.TabIndex = 16
        Me.Label96.Text = "Total: "
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label94.Location = New System.Drawing.Point(167, 5)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(212, 21)
        Me.Label94.TabIndex = 15
        Me.Label94.Text = "Percentage of Work Status"
        '
        'Chart6
        '
        Me.Chart6.BackColor = System.Drawing.Color.Transparent
        Me.Chart6.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart6.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea1.Area3DStyle.Enable3D = True
        ChartArea1.BackColor = System.Drawing.Color.Transparent
        ChartArea1.Name = "ChartArea1"
        Me.Chart6.ChartAreas.Add(ChartArea1)
        Legend1.BackColor = System.Drawing.Color.Transparent
        Legend1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend1.IsTextAutoFit = False
        Legend1.Name = "Legend1"
        Me.Chart6.Legends.Add(Legend1)
        Me.Chart6.Location = New System.Drawing.Point(26, 33)
        Me.Chart6.Name = "Chart6"
        Me.Chart6.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart6.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.Bisque, System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series1.ChartArea = "ChartArea1"
        Series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut
        Series1.Legend = "Legend1"
        Series1.Name = "Series1"
        Series1.YValuesPerPoint = 4
        Me.Chart6.Series.Add(Series1)
        Me.Chart6.Size = New System.Drawing.Size(509, 169)
        Me.Chart6.TabIndex = 10
        Me.Chart6.Text = "Chart6"
        '
        'Panel9
        '
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel9.Controls.Add(Me.Label93)
        Me.Panel9.Controls.Add(Me.Label31)
        Me.Panel9.Controls.Add(Me.Chart3)
        Me.Panel9.Location = New System.Drawing.Point(10, 249)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(682, 221)
        Me.Panel9.TabIndex = 22
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.Location = New System.Drawing.Point(164, 4)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(199, 21)
        Me.Label93.TabIndex = 14
        Me.Label93.Text = "Percentage of Youth Age"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label31.Location = New System.Drawing.Point(391, 189)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(44, 17)
        Me.Label31.TabIndex = 12
        Me.Label31.Text = "Total: "
        '
        'Chart3
        '
        Me.Chart3.BackColor = System.Drawing.Color.Transparent
        Me.Chart3.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart3.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea2.Area3DStyle.Enable3D = True
        ChartArea2.BackColor = System.Drawing.Color.Transparent
        ChartArea2.Name = "ChartArea1"
        Me.Chart3.ChartAreas.Add(ChartArea2)
        Legend2.BackColor = System.Drawing.Color.Transparent
        Legend2.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend2.IsTextAutoFit = False
        Legend2.Name = "Legend1"
        Me.Chart3.Legends.Add(Legend2)
        Me.Chart3.Location = New System.Drawing.Point(14, 33)
        Me.Chart3.Name = "Chart3"
        Me.Chart3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart3.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.Bisque, System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series2.ChartArea = "ChartArea1"
        Series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pyramid
        Series2.Legend = "Legend1"
        Series2.Name = "Series1"
        Me.Chart3.Series.Add(Series2)
        Me.Chart3.Size = New System.Drawing.Size(521, 144)
        Me.Chart3.TabIndex = 7
        Me.Chart3.Text = "Chart3"
        '
        'Panel7
        '
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.Label91)
        Me.Panel7.Controls.Add(Me.Chart4)
        Me.Panel7.Controls.Add(Me.Label27)
        Me.Panel7.Location = New System.Drawing.Point(10, 56)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(682, 187)
        Me.Panel7.TabIndex = 21
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(117, 5)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(271, 21)
        Me.Label91.TabIndex = 14
        Me.Label91.Text = "Percentage of Youth Classification"
        '
        'Chart4
        '
        Me.Chart4.BackColor = System.Drawing.Color.Transparent
        Me.Chart4.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart4.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea3.Area3DStyle.Enable3D = True
        ChartArea3.BackColor = System.Drawing.Color.Transparent
        ChartArea3.Name = "ChartArea1"
        Me.Chart4.ChartAreas.Add(ChartArea3)
        Legend3.BackColor = System.Drawing.Color.Transparent
        Legend3.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend3.IsTextAutoFit = False
        Legend3.Name = "Legend1"
        Me.Chart4.Legends.Add(Legend3)
        Me.Chart4.Location = New System.Drawing.Point(10, 34)
        Me.Chart4.Name = "Chart4"
        Me.Chart4.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart4.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.Bisque, System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series3.ChartArea = "ChartArea1"
        Series3.Legend = "Legend1"
        Series3.Name = "Series1"
        Series3.YValuesPerPoint = 4
        Me.Chart4.Series.Add(Series3)
        Me.Chart4.Size = New System.Drawing.Size(654, 116)
        Me.Chart4.TabIndex = 8
        Me.Chart4.Text = "Chart4"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label27.Location = New System.Drawing.Point(533, 153)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(44, 17)
        Me.Label27.TabIndex = 12
        Me.Label27.Text = "Total: "
        '
        'Panel31
        '
        Me.Panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel31.Controls.Add(Me.Label54)
        Me.Panel31.Controls.Add(Me.Label84)
        Me.Panel31.Controls.Add(Me.Label25)
        Me.Panel31.Controls.Add(Me.Chart2)
        Me.Panel31.Location = New System.Drawing.Point(698, 249)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(641, 222)
        Me.Panel31.TabIndex = 19
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(798, -52)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(184, 21)
        Me.Label54.TabIndex = 12
        Me.Label54.Text = "Percenatage of Gender"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(158, 7)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(205, 21)
        Me.Label84.TabIndex = 13
        Me.Label84.Text = "Percentage of Civil Status"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label25.Location = New System.Drawing.Point(340, 174)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(44, 17)
        Me.Label25.TabIndex = 11
        Me.Label25.Text = "Total: "
        '
        'Chart2
        '
        Me.Chart2.BackColor = System.Drawing.Color.Transparent
        Me.Chart2.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart2.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea4.Area3DStyle.Enable3D = True
        ChartArea4.BackColor = System.Drawing.Color.Transparent
        ChartArea4.Name = "ChartArea1"
        Me.Chart2.ChartAreas.Add(ChartArea4)
        Legend4.BackColor = System.Drawing.Color.Transparent
        Legend4.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend4.IsTextAutoFit = False
        Legend4.Name = "Legend1"
        Me.Chart2.Legends.Add(Legend4)
        Me.Chart2.Location = New System.Drawing.Point(22, 29)
        Me.Chart2.Name = "Chart2"
        Me.Chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart2.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series4.ChartArea = "ChartArea1"
        Series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie
        Series4.Legend = "Legend1"
        Series4.Name = "Series1"
        Me.Chart2.Series.Add(Series4)
        Me.Chart2.Size = New System.Drawing.Size(595, 161)
        Me.Chart2.TabIndex = 6
        Me.Chart2.Text = "Chart2"
        '
        'Panel28
        '
        Me.Panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel28.Controls.Add(Me.Label95)
        Me.Panel28.Controls.Add(Me.Label30)
        Me.Panel28.Controls.Add(Me.Chart5)
        Me.Panel28.Location = New System.Drawing.Point(698, 476)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(641, 214)
        Me.Panel28.TabIndex = 19
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(129, 5)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(302, 21)
        Me.Label95.TabIndex = 16
        Me.Label95.Text = "Percentage of Educational Attainment"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label30.Location = New System.Drawing.Point(376, 178)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(44, 17)
        Me.Label30.TabIndex = 11
        Me.Label30.Text = "Total: "
        '
        'Chart5
        '
        Me.Chart5.BackColor = System.Drawing.Color.Transparent
        Me.Chart5.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart5.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea5.Area3DStyle.Enable3D = True
        ChartArea5.BackColor = System.Drawing.Color.Transparent
        ChartArea5.Name = "ChartArea1"
        Me.Chart5.ChartAreas.Add(ChartArea5)
        Legend5.BackColor = System.Drawing.Color.Transparent
        Legend5.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend5.IsTextAutoFit = False
        Legend5.LegendItemOrder = System.Windows.Forms.DataVisualization.Charting.LegendItemOrder.ReversedSeriesOrder
        Legend5.Name = "Legend1"
        Me.Chart5.Legends.Add(Legend5)
        Me.Chart5.Location = New System.Drawing.Point(22, 33)
        Me.Chart5.Name = "Chart5"
        Me.Chart5.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart5.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series5.ChartArea = "ChartArea1"
        Series5.Legend = "Legend1"
        Series5.Name = "Series1"
        Me.Chart5.Series.Add(Series5)
        Me.Chart5.Size = New System.Drawing.Size(595, 166)
        Me.Chart5.TabIndex = 9
        Me.Chart5.Text = "Chart5"
        '
        'Panel15
        '
        Me.Panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel15.Controls.Add(Me.Label33)
        Me.Panel15.Controls.Add(Me.Label24)
        Me.Panel15.Controls.Add(Me.Label9)
        Me.Panel15.Controls.Add(Me.Chart1)
        Me.Panel15.Location = New System.Drawing.Point(698, 57)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(641, 186)
        Me.Panel15.TabIndex = 18
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(170, 6)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(175, 21)
        Me.Label33.TabIndex = 11
        Me.Label33.Text = "Percentage of Gender"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label24.Location = New System.Drawing.Point(896, 152)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(44, 17)
        Me.Label24.TabIndex = 10
        Me.Label24.Text = "Total: "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(428, 152)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(44, 17)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Total: "
        '
        'Chart1
        '
        Me.Chart1.BackColor = System.Drawing.Color.Transparent
        Me.Chart1.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart1.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea6.Area3DStyle.Enable3D = True
        ChartArea6.BackColor = System.Drawing.Color.Transparent
        ChartArea6.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea6)
        Legend6.BackColor = System.Drawing.Color.Transparent
        Legend6.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend6.IsTextAutoFit = False
        Legend6.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend6)
        Me.Chart1.Location = New System.Drawing.Point(18, 33)
        Me.Chart1.Name = "Chart1"
        Me.Chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart1.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.Bisque, System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series6.ChartArea = "ChartArea1"
        Series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut
        Series6.Legend = "Legend1"
        Series6.Name = "Series1"
        Me.Chart1.Series.Add(Series6)
        Me.Chart1.Size = New System.Drawing.Size(599, 140)
        Me.Chart1.TabIndex = 2
        Me.Chart1.Text = "Chart1"
        '
        'Panel27
        '
        Me.Panel27.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel27.Controls.Add(Me.Label87)
        Me.Panel27.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel27.Location = New System.Drawing.Point(0, 0)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(1353, 48)
        Me.Panel27.TabIndex = 1
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.BackColor = System.Drawing.Color.Transparent
        Me.Label87.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label87.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label87.Location = New System.Drawing.Point(35, 5)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(283, 37)
        Me.Label87.TabIndex = 1
        Me.Label87.Text = "STATISTIC REPORTS"
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Transparent
        Me.btnBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue
        Me.btnBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Image = CType(resources.GetObject("btnBack.Image"), System.Drawing.Image)
        Me.btnBack.Location = New System.Drawing.Point(12, 697)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(75, 35)
        Me.btnBack.TabIndex = 39
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'brgy_stat
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.ControlBox = False
        Me.Controls.Add(Me.PanelStat)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "brgy_stat"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.PanelStat.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        CType(Me.Chart6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        CType(Me.Chart3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        CType(Me.Chart4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel31.ResumeLayout(False)
        Me.Panel31.PerformLayout()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        CType(Me.Chart5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelStat As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label96 As Label
    Friend WithEvents Label94 As Label
    Friend WithEvents Chart6 As DataVisualization.Charting.Chart
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label93 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Chart3 As DataVisualization.Charting.Chart
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label91 As Label
    Friend WithEvents Chart4 As DataVisualization.Charting.Chart
    Friend WithEvents Label27 As Label
    Friend WithEvents Panel31 As Panel
    Friend WithEvents Label54 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Chart2 As DataVisualization.Charting.Chart
    Friend WithEvents Panel28 As Panel
    Friend WithEvents Label95 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Chart5 As DataVisualization.Charting.Chart
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Label33 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Chart1 As DataVisualization.Charting.Chart
    Friend WithEvents Panel27 As Panel
    Friend WithEvents Label87 As Label
    Friend WithEvents btnBack As Button
End Class
