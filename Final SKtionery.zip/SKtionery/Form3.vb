﻿Public Class Form3

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        '   'If ComboBox3.Text = "Type" Then
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT a.category,`type`, b.quarter_name, `total`, `date` FROM `quarterly_stat` as a left OUTer JOIN quarter as b on a.quarter = b.quarter_id WHERE (category like '%" & ComboBox1.Text.Trim & "%' and date  like '%" & TextBox1.Text.Trim & "%' and b.quarter_name like '%" & ComboBox4.Text.Trim & "%');" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            DataGridView1.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                DataGridView1.Rows.Add()
                DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(3).ToString
                DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(2).ToString



            Next
        Catch
            MessageBox.Show("error")
        End Try


        '  End If
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ComboBox4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox4.SelectedIndexChanged
        If ComboBox1.Text = "" Or
      TextBox1.Text = "" Or
       ComboBox4.Text = "" Then
            menuForm.stat_archive()
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        If ComboBox1.Text = "" Or
      TextBox1.Text = "" Or
       ComboBox4.Text = "" Then
            menuForm.stat_archive()
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.Text = "" Or
      TextBox1.Text = "" Or
       ComboBox4.Text = "" Then
            menuForm.stat_archive()
        End If
    End Sub
End Class