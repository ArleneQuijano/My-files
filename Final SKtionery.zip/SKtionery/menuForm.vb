﻿Imports System.Windows.Forms.DataVisualization.Charting
Imports MySql.Data.MySqlClient
Imports System
Imports System.IO


Public Class menuForm
    Dim cn As New MySqlConnection
    Dim id As Integer = 0
    Dim brgy As Integer = 0
    Dim ofd As New OpenFileDialog
    Dim isec As String
    Dim isec3 As String


    Dim seemorelink As String
    Dim seemorelinkk As String
    Dim fileupload As String
    Dim pathfolder As String = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10))

    Dim isCollapsed As Boolean = True


    ' Private currentContactPanelLname As String = Nothing

    'Private contactPanelAddeCount As Integer = 0

    Private childPanel As String = Nothing
    Private childPanel2 As String = Nothing
    Private Count As Integer = 0


    '---Announcemnt'----
    '  Private announcementPanel As String = Nothing


    Public Sub CreateChildPanel()
        Dim cPanel As Panel
        cPanel = New Panel()

        With cPanel
            .BackColor = Color.FromArgb(223, 230, 244)
            .Size = New Size(770, 170)
            .Name = "pnl" + (Count + 1).ToString
        End With
        flpPanel.Controls.Add(cPanel)
        childPanel = cPanel.Name
        Count += 1

    End Sub

    '  Public Sub CreateChildPanel2(ByVal panelName As String)
    '     Dim cPanel2 As Panel
    '     cPanel2 = New Panel()
    '
    '     With cPanel2
    '        .BackColor = Color.Transparent
    '        .Size = New Size(728, 138)
    '        .Name = "pnl" + (Count + 1).ToString
    '        .Location = New Point(19, 18)
    '     End With
    '     For Each obj As Control In flpPanel.Controls
    '        If obj.Name = panelName Then

    '            obj.Controls.Add(cPanel2)
    '   End If
    '    Next

    '  End Sub


    Public Sub CreateChildTitle(ByVal panelName As String, ByVal txtContent As String)
        Dim activity As Label
        activity = New Label

        With activity
            .Location = New Point(12, 76)
            .Name = "lblActivity" + (Count + 1).ToString
            .Text = txtContent
            .Font = New Font("Segoe UI", 11, FontStyle.Bold)
            .Size = New Size(728, 19)
            '  .BackColor = Color.White
        End With

        For Each obj As Control In flpPanel.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(activity)
            End If
        Next
    End Sub

    Public Sub CreateChildDesc(ByVal panelName As String, ByVal txtContent As String)
        Dim desc As Label
        desc = New Label

        With desc
            .Size = New Size(679, 34)
            .Location = New Point(15, 101)
            .Name = "lblDesc" + (Count + 1).ToString
            .Text = txtContent + "..."
            .Font = New Font("Segoe UI", 9.5)
            '   .BackColor = Color.White


        End With

        For Each obj As Control In flpPanel.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(desc)
            End If
        Next
    End Sub


    Public Sub CreateChildDate(ByVal panelName As String, ByVal txtContent As String)
        Dim actDate As Label
        actDate = New Label

        With actDate
            .Location = New Point(15, 143)
            .Name = "lblDate" + (Count + 1).ToString
            .Text = "Date of Activity: " + txtContent
            .Size = New Size(728, 20)
            .Font = New Font("Segoe UI", 9, FontStyle.Regular)
            '    .BackColor = Color.White
        End With

        For Each obj As Control In flpPanel.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(actDate)
            End If
        Next
    End Sub
    Public Sub CreateChildBarangay(ByVal panelName As String, ByVal txtContent As String)
        Dim brgy As Label
        brgy = New Label

        With brgy
            .Location = New Point(15, 32)
            .Name = "lblbrgy" + (Count + 1).ToString
            .Text = txtContent
            .Font = New Font("Segoe UI", 11, FontStyle.Bold)
            .Size = New Size(109, 20)
            '     .BackColor = Color.White
        End With

        For Each obj As Control In flpPanel.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(brgy)
            End If
        Next
    End Sub
    Public Sub CreateChildLabeldate(ByVal panelName As String, ByVal txtContent As String)
        Dim lbldate As Label
        lbldate = New Label

        With lbldate
            .Location = New Point(625, 15)
            .Name = "lbldate" + (Count + 1).ToString
            .Text = txtContent
            .Font = New Font("Segoe UI", 9)
            .Size = New Size(159, 20)
            ' .BackColor = Color.White
        End With

        For Each obj As Control In flpPanel.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(lbldate)
            End If
        Next
    End Sub
    Public Sub CreateChildUser(ByVal panelName As String, ByVal txtContent As String)
        Dim user As Label
        user = New Label

        With user
            .Size = New Size(125, 21)
            '  .BackColor = Color.White
            .Location = New Point(15, 10)
            .Name = "lbluser" + (Count + 1).ToString
            .Text = txtContent
            .Font = New Font("Segoe UI", 12, FontStyle.Bold)

        End With

        For Each obj As Control In flpPanel.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(user)
            End If
        Next
    End Sub
    Public Sub CreateName(ByVal panelName As String, ByVal txtContent As String)
        Dim name As Label
        name = New Label

        With name
            .Size = New Size(300, 17)
            .Location = New Point(15, 55)
            .Name = "lblname" + (Count + 1).ToString
            .Text = txtContent
            .Font = New Font("Segoe UI", 9.5, FontStyle.Bold)
            '  .BackColor = Color.FromArgb(225, 240, 244)
        End With

        For Each obj As Control In flpPanel.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(name)
            End If
        Next
    End Sub

    Public Sub link(ByVal panelName As String, ByVal txtContent As String, ByVal seemorelink As String)
        Dim seemore As LinkLabel
        seemore = New LinkLabel

        With seemore
            .Size = New Size(56, 15)
            .Location = New Point(698, 120)
            .Name = "linkSeemore" + seemorelink
            .Text = txtContent
            .Font = New Font("Segoe UI", 9, FontStyle.Underline)
            ' .ForeColor = Color.Black
            '.BackColor = Color.FromArgb(225, 240, 244)
        End With

        For Each obj As Control In flpPanel.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(seemore)
            End If
        Next
        AddHandler seemore.LinkClicked, AddressOf Lnk_Clicked
    End Sub

    Public Sub Lnk_Clicked(ByVal sender As System.Object, ByVal e As LinkLabelLinkClickedEventArgs)
        Dim textdes As String
        '  Dim des As String
        Dim lblDes As New System.Windows.Forms.Label


        Dim lnk As LinkLabel = CType(sender, LinkLabel)
        seemorelink = lnk.Name.Substring(11)

        'MessageBox.Show(seemorelink)

        Dim db2 = New Database
        Dim dt2 As New DataTable
        With db2
            .sqlStr = "SELECT description from activities where activity_id='" & seemorelink & "'" 'query string
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
            .close()
        End With
        dt2 = db2.sqlDt

        With lblDes
            .Size = New Size(435, 218)
            .Location = New Point(14, 35)
            .BackColor = Color.White
            .Font = New Font("Segoe UI", 9.5)
        End With
        lblDes.Text = dt2.Rows(0).Item(0).ToString
        Form5.Controls.Add(lblDes)
        Form5.Show()







    End Sub


    '  Public Sub CreateChildlblDateofActivity(ByVal panelName As String, ByVal txtContent As String)
    '     Dim activityDate As Label
    '      activityDate = New Label

    '    With activityDate
    '         .Location = New Point(24, 97)
    '         .Name = "lblDateAct" + (Count + 1).ToString
    '         .Text = txtContent
    '         .Font = New Font("Segoe UI", 8)
    '     End With

    '    For Each obj As Control In flpPanel.Controls
    '        If obj.Name = panelName Then
    '            obj.Controls.Add(activityDate)
    'End If
    '  Next
    '  End Sub
    Public Sub GetAllActivities(ByVal con As MySqlConnection)



        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                ' "SELECT a.title, description, activity_date, posted_date ,b.brgy_name from activities as a Left outer join barangay_tbl as b on a.brgy_id = b.brgy_id"
                .sqlStr = "SELECT a.title, short_des, activity_date , b.brgy_name, u.user_type,posted_time, `username`,activity_id from activities as a Left outer join barangay_tbl as b on a.brgy_id = b.brgy_id Left outer join user_tbl as u on a.user_id = u.user_id order by activity_id asc;"
                'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt

            For i = 0 To dt.Rows.Count - 1
                CreateChildPanel()
                '      CreateChildPanel2(childPanel)
                CreateChildTitle(childPanel, dt.Rows(i).Item(0).ToString) 'title
                CreateChildDesc(childPanel, dt.Rows(i).Item(1).ToString) 'desc
                CreateChildDate(childPanel, dt.Rows(i).Item(2).ToString) 'date
                CreateChildBarangay(childPanel, dt.Rows(i).Item(3).ToString) 'brgy
                CreateChildUser(childPanel, dt.Rows(i).Item(4).ToString) 'user_id
                CreateChildLabeldate(childPanel, dt.Rows(i).Item(5).ToString) 'posted_time
                CreateName(childPanel, dt.Rows(i).Item(6).ToString) 'posted_time
                seemorelink = dt.Rows(i).Item(7).ToString
                link(childPanel, "See More", seemorelink)
            Next
        Catch ex As Exception

        End Try

    End Sub
    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Dim result = MessageBox.Show("ARE YOU SURE YOU WANT TO LOG OUT?", "LOG OUT", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            StartForm.TextBox1.Text = ""
            StartForm.TextBox2.Text = ""
            StartForm.Show()
            Me.Hide()
        ElseIf result = DialogResult.No Then
            Exit Sub
        End If
        StartForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        panelbarangay.Visible = False
        PanelSMS.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = True
        PanelArchive2.Visible = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        loadingbarangay()
        PanelStat.Visible = False
        panelReportArchive.Visible = False

        PanelSMS.Visible = False

    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        panelbarangay.Visible = False
        PanelMonthlyReport.Visible = True
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelArchive2.Visible = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False
        TextBox1.Enabled = False
        PanelSMS.Visible = False
        loadFormReports()
        If Label20.Text = "SK Federated" Then
            Button11.Visible = False
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        panelbarangay.Visible = False
        PanelSMS.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = True
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelArchive2.Visible = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False

        TextBox13.ReadOnly = True
        TextBox14.ReadOnly = True
        TextBox15.ReadOnly = True
        TextBox16.ReadOnly = True
        TextBox17.ReadOnly = True
        TextBox18.ReadOnly = True
        TextBox19.ReadOnly = True
        TextBox20.ReadOnly = True
        TextBox21.ReadOnly = True



        Dim db1 = New Database
        Dim dt1 As New DataTable
        With db1
            .sqlStr = "SELECT * FROM organizationa_chart ORDER BY id asc LIMIT 1" 'query string
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
            .close()
        End With
        dt1 = db1.sqlDt
        For i = 0 To dt1.Rows.Count - 1
            TextBox13.Text = dt1.Rows(i).Item(1).ToString 'lydo 
            TextBox14.Text = dt1.Rows(i).Item(2).ToString
            TextBox15.Text = dt1.Rows(i).Item(3).ToString
            TextBox20.Text = dt1.Rows(i).Item(4).ToString
            TextBox19.Text = dt1.Rows(i).Item(5).ToString
            TextBox18.Text = dt1.Rows(i).Item(6).ToString
            TextBox17.Text = dt1.Rows(i).Item(7).ToString
            TextBox16.Text = dt1.Rows(i).Item(8).ToString 'sec
            TextBox21.Text = dt1.Rows(i).Item(9).ToString
        Next

        If Label20.Text = "LYDO" Or
           Label20.Text = "SK Chairperson" Then
            Button23.Visible = False
            Button17.Visible = False
            Button24.Visible = False
        ElseIf Label20.Text = "SK Federated" Then
            Button23.Visible = True
            Button17.Visible = True
            Button24.Visible = True
        End If

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        panelbarangay.Visible = False
        PanelSMS.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = True
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelArchive2.Visible = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        panelbarangay.Visible = False
        PanelSMS.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = True
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelArchive2.Visible = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        panelbarangay.Visible = False
        PanelSMS.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = True
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelArchive2.Visible = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False
        loadForm()
        TextBoxID.Enabled = True
        TextBoxFname.Enabled = True
        TextBoxLname.Enabled = True
        TextBoxMname.Enabled = True
        TextBoxUsername.Enabled = True
        TextBoxPassword.Enabled = True
        ComboBoxUsertype.Enabled = True
        ComboBoxBarangay.Enabled = True
        TextBox3.Enabled = True
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        panelbarangay.Visible = False
        PanelSMS.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = True
        PanelActivities.Visible = False
        PanelArchive2.Visible = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False
    End Sub

    Private Sub ButtonMReports_Click(sender As Object, e As EventArgs)
        panelbarangay.Visible = False
        PanelSMS.Visible = True
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelMonthlyReport.Visible = True
        PanelArchive2.Visible = False
        loadFormReports()
        TextBox1.Enabled = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False
    End Sub

    Private Sub ButtonQreports_Click(sender As Object, e As EventArgs)
        panelbarangay.Visible = False

        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelMonthlyReport.Visible = True
        PanelArchive2.Visible = False

        TextBox1.Enabled = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        panelbarangay.Visible = False
        PanelSMS.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelMonthlyReport.Visible = False
        PanelArchive2.Visible = True
        panelReportArchive.Visible = False
        loadFormArchive()
    End Sub

    Private Sub brgy1button_Click(sender As Object, e As EventArgs) Handles brgy1button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Ayusan Norte"
        brgyform.loadFormBrgy1()
        If Label20.Text = "SK Federated" Or
                Label20.Text = "LYDO" Then

            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            '  brgyform.btnBack.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        TextBox3.Text = ""
        TextBoxID.Text = ""
        TextBoxLname.Text = ""
        TextBoxFname.Text = ""
        TextBoxMname.Text = ""
        TextBoxUsername.Text = ""
        TextBoxPassword.Text = ""
        ComboBoxBarangay.Text = ""
        ComboBoxUsertype.Text = ""
        TextBox3.Enabled = True
        TextBoxID.Enabled = True
        TextBoxFname.Enabled = True
        TextBoxLname.Enabled = True
        TextBoxMname.Enabled = True
        TextBoxUsername.Enabled = True
        TextBoxPassword.Enabled = True
        ComboBoxUsertype.Enabled = True
        ComboBoxBarangay.Enabled = True
        Button20.Enabled = True
    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click


        If TextBoxID.Text.Trim = "'" Then
            TextBoxID.Text.Trim.Replace("'", "\'")
        ElseIf TextBoxFname.Text.Trim = "'" Then
            TextBoxFname.Text.Trim.Replace("'", "\'")
        End If

        Dim id As Integer = 0
        Dim brgy As Integer = 0
        If ComboBoxBarangay.Text = "Ayusan Norte" Then
            brgy = 1
        ElseIf ComboBoxBarangay.Text = "Ayusan Sur" Then
            brgy = 2
        ElseIf ComboBoxBarangay.Text = "Barangay 1" Then
            brgy = 3
        ElseIf ComboBoxBarangay.Text = "Barangay 2" Then
            brgy = 4
        ElseIf ComboBoxBarangay.Text = "Barangay 3" Then
            brgy = 5
        ElseIf ComboBoxBarangay.Text = "Barangay 4" Then
            brgy = 6
        ElseIf ComboBoxBarangay.Text = "Barangay 5" Then
            brgy = 7
        ElseIf ComboBoxBarangay.Text = "Barangay 6" Then
            brgy = 8
        ElseIf ComboBoxBarangay.Text = "Barangay 7" Then
            brgy = 9
        ElseIf ComboBoxBarangay.Text = "Barangay 8" Then
            brgy = 10
        ElseIf ComboBoxBarangay.Text = "Barangay 9" Then
            brgy = 11
        ElseIf ComboBoxBarangay.Text = "Barraca" Then
            brgy = 12
        ElseIf ComboBoxBarangay.Text = "Beddeng Daya" Then
            brgy = 13
        ElseIf ComboBoxBarangay.Text = "Beddeng Laud" Then
            brgy = 14
        ElseIf ComboBoxBarangay.Text = "Bongtolan" Then
            brgy = 15
        ElseIf ComboBoxBarangay.Text = "Bulala" Then
            brgy = 16
        ElseIf ComboBoxBarangay.Text = "Cabalangegan" Then
            brgy = 17
        ElseIf ComboBoxBarangay.Text = "Cabaroan Daya" Then
            brgy = 18
        ElseIf ComboBoxBarangay.Text = "Cabaroan Laud" Then
            brgy = 19
        ElseIf ComboBoxBarangay.Text = "Camangaan" Then
            brgy = 20
        ElseIf ComboBoxBarangay.Text = "Capangpangan" Then
            brgy = 21
        ElseIf ComboBoxBarangay.Text = "Mindoro" Then
            brgy = 22
        ElseIf ComboBoxBarangay.Text = "Nagsangalan" Then
            brgy = 23
        ElseIf ComboBoxBarangay.Text = "Pantay Daya" Then
            brgy = 24
        ElseIf ComboBoxBarangay.Text = "Pantay Fatima" Then
            brgy = 25
        ElseIf ComboBoxBarangay.Text = "Pantay Laud" Then
            brgy = 26
        ElseIf ComboBoxBarangay.Text = "Paoa" Then
            brgy = 27
        ElseIf ComboBoxBarangay.Text = "Paratong" Then
            brgy = 28
        ElseIf ComboBoxBarangay.Text = "Pong-ol" Then
            brgy = 29
        ElseIf ComboBoxBarangay.Text = "Purok-a-bassit" Then
            brgy = 30
        ElseIf ComboBoxBarangay.Text = "Purok-a-dackel" Then
            brgy = 31
        ElseIf ComboBoxBarangay.Text = "Raois" Then
            brgy = 32
        ElseIf ComboBoxBarangay.Text = "Rugsaunan" Then
            brgy = 33
        ElseIf ComboBoxBarangay.Text = "Salindeg" Then
            brgy = 34
        ElseIf ComboBoxBarangay.Text = "San Jose" Then
            brgy = 35
        ElseIf ComboBoxBarangay.Text = "San Julian Norte" Then
            brgy = 36
        ElseIf ComboBoxBarangay.Text = "San Julian Sur" Then
            brgy = 37
        ElseIf ComboBoxBarangay.Text = "San Pedro" Then
            brgy = 38
        ElseIf ComboBoxBarangay.Text = "Tamag" Then
            brgy = 39
        End If
        If ComboBoxUsertype.Text = "SK Federated" Then

            id = 0
        ElseIf ComboBoxUsertype.Text = "SK Chairperson" Then

            id = 1
        ElseIf ComboBoxUsertype.Text = "LYDO" Then
            id = 2
        End If
        If TextBoxID.Text = "" Or
        TextBoxFname.Text = "" Or
        TextBoxLname.Text = "" Or
        TextBoxUsername.Text = "" Or
        TextBoxPassword.Text = "" Or
        ComboBoxUsertype.Text = "" Or
        ComboBoxBarangay.Text = "" Then
            MessageBox.Show("Missing Fields!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim user_type As String
            user_type = "SK Federated"

            Try


                Dim db1 = New Database
                Dim dt1 As New DataTable
                With db1
                    .sqlStr = "SELECT * from account_tbl where id_no ='" & TextBoxID.Text.Trim & "'" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                    .close()
                End With
                dt1 = db1.sqlDt


                Dim db2 = New Database
                Dim dt2 As New DataTable
                With db2
                    .sqlStr = "SELECT * from account_tbl where username ='" & TextBoxUsername.Text.Trim & "'" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                    .close()
                End With
                dt2 = db2.sqlDt


                If dt1.Rows.Count > 0 Then
                    MessageBox.Show("ID NUMBER IS  ALREADY REGISTERED!", "ALERT", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                ElseIf dt2.Rows.Count > 0 Then
                    MessageBox.Show("USERNAME IS ALREADY USED!", "ALERT", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                Else
                    Dim db = New Database
                    With db
                        ''-----------------------------------------EMPTY TransactID---------
                        .sqlStr = "insert into account_tbl (id_no,lastname,firstname,middlename,contact,username,password,user_id,brgy_id) values
                ('" & TextBoxID.Text.Trim & "','" & TextBoxLname.Text.Trim & "','" & TextBoxFname.Text.Trim & "','" & TextBoxMname.Text.Trim & "','" & TextBox3.Text.Trim & "','" & TextBoxUsername.Text.Trim & "','" & TextBoxPassword.Text.Trim &
                                "','" & id & "','" & brgy & "')"
                        .sqlDa.InsertCommand = .sqlcm(.sqlStr, .connect)
                        .sqlDa.InsertCommand.ExecuteNonQuery()
                        .close()
                    End With
                    MessageBox.Show("Successfully Saved", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    Refresh()
                    loadForm()

                    TextBoxID.Text = ""
                    TextBoxFname.Text = ""
                    TextBoxMname.Text = ""
                    TextBoxLname.Text = ""
                    TextBoxUsername.Text = ""
                    TextBoxPassword.Text = ""
                    ComboBoxUsertype.Text = ""
                    ComboBoxBarangay.Text = ""
                    TextBox3.Text = ""

                End If


            Catch
                MessageBox.Show("error")
            End Try
        End If
    End Sub
    Public Sub loadForm()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db

                .sqlStr = "SELECT * from account_tbl Order by lastname ASC"
                'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            DataGridView3.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                DataGridView3.Rows.Add()
                DataGridView3.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                DataGridView3.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                DataGridView3.Rows(i).Cells(2).Value = dt.Rows(i).Item(3).ToString
                DataGridView3.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                DataGridView3.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                DataGridView3.Rows(i).Cells(5).Value = dt.Rows(i).Item(6).ToString
                DataGridView3.Rows(i).Cells(6).Value = dt.Rows(i).Item(7).ToString
                DataGridView3.Rows(i).Cells(7).Value = dt.Rows(i).Item(1).ToString
                DataGridView3.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString

                If dt.Rows(i).Item(1).ToString = "0" Then
                    DataGridView3.Rows(i).Cells(7).Value = "SK Federated"
                ElseIf dt.Rows(i).Item(1).ToString = "1" Then
                    DataGridView3.Rows(i).Cells(7).Value = "SK Chairperson"
                ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                    DataGridView3.Rows(i).Cells(7).Value = "LYDO"
                End If

                If dt.Rows(i).Item(8).ToString = "1" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(8).ToString = "2" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(8).ToString = "3" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(8).ToString = "4" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(8).ToString = "5" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(8).ToString = "6" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(8).ToString = "7" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(8).ToString = "8" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(8).ToString = "9" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(8).ToString = "10" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(8).ToString = "11" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(8).ToString = "12" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barraca"
                ElseIf dt.Rows(i).Item(8).ToString = "13" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(8).ToString = "14" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(8).ToString = "15" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(8).ToString = "16" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Bulala"
                ElseIf dt.Rows(i).Item(8).ToString = "17" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(8).ToString = "18" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(8).ToString = "19" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(8).ToString = "20" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(8).ToString = "21" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(8).ToString = "22" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(8).ToString = "23" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(8).ToString = "24" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(8).ToString = "25" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(8).ToString = "26" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(8).ToString = "27" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Paoa"
                ElseIf dt.Rows(i).Item(8).ToString = "28" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Paratong"
                ElseIf dt.Rows(i).Item(8).ToString = "29" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(8).ToString = "30" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(8).ToString = "31" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(8).ToString = "32" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Raois"
                ElseIf dt.Rows(i).Item(8).ToString = "33" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(8).ToString = "34" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(8).ToString = "35" Then
                    DataGridView3.Rows(i).Cells(8).Value = "San Jose"
                ElseIf dt.Rows(i).Item(8).ToString = "36" Then
                    DataGridView3.Rows(i).Cells(8).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(8).ToString = "37" Then
                    DataGridView3.Rows(i).Cells(8).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(8).ToString = "38" Then
                    DataGridView3.Rows(i).Cells(8).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(8).ToString = "39" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Tamag"
                End If
            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Private Sub ComboBoxUsertype_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxUsertype.SelectedIndexChanged



    End Sub

    Private Sub TextBoxFname_TextChanged(sender As Object, e As EventArgs) Handles TextBoxFname.TextChanged
        '   TextBoxFname.Text = StrConv(TextBoxFname.Text, vbProperCase)
    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        If TextBoxID.Text = "" Or
            TextBoxFname.Text = "" Or
            TextBoxLname.Text = "" Or
            TextBoxUsername.Text = "" Or
            TextBoxPassword.Text = "" Or
            ComboBoxUsertype.Text = "" Or
            TextBox3.Text = "" Or
            ComboBoxBarangay.Text = "" Then
            MessageBox.Show("Please Select Data", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else

            TextBoxID.Enabled = True
            TextBoxFname.Enabled = True
            TextBoxLname.Enabled = True
            TextBoxMname.Enabled = True
            TextBoxUsername.Enabled = True
            TextBoxPassword.Enabled = True
            ComboBoxUsertype.Enabled = True
            ComboBoxBarangay.Enabled = True
            TextBox3.Enabled = True
            Button20.Enabled = False
        End If
    End Sub

    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        If TextBoxID.Text = "" Then
            MessageBox.Show("Please Select Data", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error)


        Else
            TextBoxID.Enabled = False
            TextBoxFname.Enabled = False
            TextBoxLname.Enabled = False
            TextBoxMname.Enabled = False
            TextBoxUsername.Enabled = False
            TextBoxPassword.Enabled = False
            ComboBoxUsertype.Enabled = False
            ComboBoxBarangay.Enabled = False
            TextBox3.Enabled = False
            Try
                Dim result = MessageBox.Show("ARE YOU SURE?", "DELETE SELECTED", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If result = DialogResult.No Then

                    TextBoxID.Text = ""
                    TextBoxFname.Text = ""
                    TextBoxLname.Text = ""
                    TextBoxMname.Text = ""
                    TextBoxUsername.Text = ""
                    TextBoxPassword.Text = ""
                    ComboBoxUsertype.Text = ""
                    ComboBoxBarangay.Text = ""
                    TextBox3.Text = ""
                    TextBoxID.Enabled = True
                    TextBoxFname.Enabled = True
                    TextBoxLname.Enabled = True
                    TextBoxMname.Enabled = True
                    TextBoxUsername.Enabled = True
                    TextBoxPassword.Enabled = True
                    ComboBoxUsertype.Enabled = True
                    ComboBoxBarangay.Enabled = True
                    TextBox3.Enabled = True

                ElseIf result = DialogResult.Yes Then
                    Dim db1 = New Database
                    Dim dt1 As New DataTable
                    With db1
                        .sqlStr = "delete from account_tbl where id_no='" & DataGridView3.CurrentRow.Cells(0).Value & "'" 'query string
                        .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                        .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                        .close()
                    End With
                    MessageBox.Show("Successfully Deleted", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

                    loadForm()
                    TextBoxID.Text = ""
                    TextBoxFname.Text = ""
                    TextBoxLname.Text = ""
                    TextBoxMname.Text = ""
                    TextBoxUsername.Text = ""
                    TextBoxPassword.Text = ""
                    ComboBoxUsertype.Text = ""
                    ComboBoxBarangay.Text = ""
                    TextBox3.Text = ""
                End If

            Catch
                MessageBox.Show("ERROR")
            End Try
        End If
    End Sub



    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click

        Dim id As Integer = 0
        Dim brgy As Integer = 0
        If ComboBoxBarangay.Text = "Ayusan Norte" Then
            brgy = 1
        ElseIf ComboBoxBarangay.Text = "Ayusan Sur" Then
            brgy = 2
        ElseIf ComboBoxBarangay.Text = "Barangay 1" Then
            brgy = 3
        ElseIf ComboBoxBarangay.Text = "Barangay 2" Then
            brgy = 4
        ElseIf ComboBoxBarangay.Text = "Barangay 3" Then
            brgy = 5
        ElseIf ComboBoxBarangay.Text = "Barangay 4" Then
            brgy = 6
        ElseIf ComboBoxBarangay.Text = "ABarangay 5" Then
            brgy = 7
        ElseIf ComboBoxBarangay.Text = "Barangay 6" Then
            brgy = 8
        ElseIf ComboBoxBarangay.Text = "Barangay 7" Then
            brgy = 9
        ElseIf ComboBoxBarangay.Text = "Barangay 8" Then
            brgy = 10
        ElseIf ComboBoxBarangay.Text = "Barangay 9" Then
            brgy = 11
        ElseIf ComboBoxBarangay.Text = "Barraca" Then
            brgy = 12
        ElseIf ComboBoxBarangay.Text = "Beddeng Daya" Then
            brgy = 13
        ElseIf ComboBoxBarangay.Text = "Beddeng Laud" Then
            brgy = 14
        ElseIf ComboBoxBarangay.Text = "Bongtolan" Then
            brgy = 15
        ElseIf ComboBoxBarangay.Text = "Bulala" Then
            brgy = 16
        ElseIf ComboBoxBarangay.Text = "Cabalangegan" Then
            brgy = 17
        ElseIf ComboBoxBarangay.Text = "Cabaroan Daya" Then
            brgy = 18
        ElseIf ComboBoxBarangay.Text = "Cabaroan Laud" Then
            brgy = 19
        ElseIf ComboBoxBarangay.Text = "Camangaan" Then
            brgy = 20
        ElseIf ComboBoxBarangay.Text = "Capangpangan" Then
            brgy = 21
        ElseIf ComboBoxBarangay.Text = "Mindoro" Then
            brgy = 22
        ElseIf ComboBoxBarangay.Text = "Nagsangalan" Then
            brgy = 23
        ElseIf ComboBoxBarangay.Text = "Pantay Daya" Then
            brgy = 24
        ElseIf ComboBoxBarangay.Text = "Pantay Fatima" Then
            brgy = 25
        ElseIf ComboBoxBarangay.Text = "Pantay Laud" Then
            brgy = 26
        ElseIf ComboBoxBarangay.Text = "Paoa" Then
            brgy = 27
        ElseIf ComboBoxBarangay.Text = "Paratong" Then
            brgy = 28
        ElseIf ComboBoxBarangay.Text = "Pong-ol" Then
            brgy = 29
        ElseIf ComboBoxBarangay.Text = "Purok-a-bassit" Then
            brgy = 30
        ElseIf ComboBoxBarangay.Text = "Purok-a-dackel" Then
            brgy = 31
        ElseIf ComboBoxBarangay.Text = "Raois" Then
            brgy = 32
        ElseIf ComboBoxBarangay.Text = "Rugsaunan" Then
            brgy = 33
        ElseIf ComboBoxBarangay.Text = "Salindeg" Then
            brgy = 34
        ElseIf ComboBoxBarangay.Text = "San Jose" Then
            brgy = 35
        ElseIf ComboBoxBarangay.Text = "San Julian Norte" Then
            brgy = 36
        ElseIf ComboBoxBarangay.Text = "San Julian Sur" Then
            brgy = 37
        ElseIf ComboBoxBarangay.Text = "San Pedro" Then
            brgy = 38
        ElseIf ComboBoxBarangay.Text = "Tamag" Then
            brgy = 39
        End If
        If ComboBoxUsertype.Text = "SK Federated" Then

            id = 0
        ElseIf ComboBoxUsertype.Text = "SK Chairperson" Then

            id = 1
        ElseIf ComboBoxUsertype.Text = "LYDO" Then
            id = 2
        End If
        If TextBoxID.Text = "" Or
        TextBoxFname.Text = "" Or
        TextBox3.Text = "" Or
        TextBoxLname.Text = "" Or
        TextBoxUsername.Text = "" Or
        TextBoxPassword.Text = "" Or
        ComboBoxUsertype.Text = "" Or
        ComboBoxBarangay.Text = "" Then
            MessageBox.Show("Missing Fields!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else

            Dim db1 = New Database
            Dim dt1 As New DataTable
            With db1
                .sqlStr = "UPDATE `account_tbl` SET `user_id`='" & TextBoxID.Text.Trim & "',`lastname`='" & TextBoxLname.Text.Trim & "',`firstname`='" & TextBoxFname.Text.Trim & "',`middlename`='" & TextBoxMname.Text.Trim & "',`contact`='" & TextBox3.Text.Trim & "',`username`='" & TextBoxUsername.Text.Trim & "',`password`='" & TextBoxPassword.Text.Trim & "',`brgy_id`='" & brgy & "',`user_id`='" & id & "' Where id_no= '" & DataGridView3.CurrentRow.Cells(0).Value & "'" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                .close()
            End With

            MessageBox.Show("Successfully Updated", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Refresh()
            loadForm()
            TextBoxID.Enabled = True
            TextBoxFname.Enabled = True
            TextBoxLname.Enabled = True
            TextBoxMname.Enabled = True
            TextBoxUsername.Enabled = True
            TextBoxPassword.Enabled = True
            ComboBoxUsertype.Enabled = True
            ComboBoxBarangay.Enabled = True
            TextBox3.Enabled = True
            Button20.Enabled = True
        End If
    End Sub

    Private Sub brgy2button_Click(sender As Object, e As EventArgs) Handles brgy2button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Ayusan Sur"
        brgyform.loadFormBrgy2()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy3button_Click(sender As Object, e As EventArgs) Handles brgy3button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay I"
        brgyform.loadFormBrgy3()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy4button_Click(sender As Object, e As EventArgs) Handles brgy4button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay II"
        brgyform.loadFormBrgy4()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy5button_Click(sender As Object, e As EventArgs) Handles brgy5button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay III"
        brgyform.loadFormBrgy5()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy6button_Click(sender As Object, e As EventArgs) Handles brgy6button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay IV"
        brgyform.loadFormBrgy6()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy7button_Click(sender As Object, e As EventArgs) Handles brgy7button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay V"
        brgyform.loadFormBrgy7()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy8button_Click(sender As Object, e As EventArgs) Handles brgy8button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay VI"
        brgyform.loadFormBrgy8()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy9button_Click(sender As Object, e As EventArgs) Handles brgy9button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay VII"
        brgyform.loadFormBrgy9()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy10button_Click(sender As Object, e As EventArgs) Handles brgy10button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay VIII"
        brgyform.loadFormBrgy10()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy11button_Click(sender As Object, e As EventArgs) Handles brgy11button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay IX"
        brgyform.loadFormBrgy11()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy12button_Click(sender As Object, e As EventArgs) Handles brgy12button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Barraca"
        brgyform.loadFormBrgy12()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy13button_Click(sender As Object, e As EventArgs) Handles brgy13button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Beddeng Daya"
        brgyform.loadFormBrgy13()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy14button_Click(sender As Object, e As EventArgs) Handles brgy14button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Beddeng Laud"
        brgyform.loadFormBrgy14()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy15button_Click(sender As Object, e As EventArgs) Handles brgy15button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Bongtolan"
        brgyform.loadFormBrgy15()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub
    Private Sub brgy16button_Click(sender As Object, e As EventArgs) Handles brgy16button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Bulala"
        brgyform.loadFormBrgy16()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy17button_Click(sender As Object, e As EventArgs) Handles brgy17button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Cabalangegan"
        brgyform.loadFormBrgy17()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy18button_Click(sender As Object, e As EventArgs) Handles brgy18button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Cabaroan Daya"
        brgyform.loadFormBrgy18()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy19button_Click(sender As Object, e As EventArgs) Handles brgy19button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Cabaroan Laud"
        brgyform.loadFormBrgy19()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy20button_Click(sender As Object, e As EventArgs) Handles brgy20button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Camangaan"
        brgyform.loadFormBrgy20()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy21button_Click(sender As Object, e As EventArgs) Handles brgy21button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Capangpangan"
        brgyform.loadFormBrgy21()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy22button_Click(sender As Object, e As EventArgs) Handles brgy22button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Mindoro"
        brgyform.loadFormBrgy22()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy23button_Click(sender As Object, e As EventArgs) Handles brgy23button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Nagsangalan"
        brgyform.loadFormBrgy23()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy24button_Click(sender As Object, e As EventArgs) Handles brgy24button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Pantay Daya"
        brgyform.loadFormBrgy24()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy25button_Click(sender As Object, e As EventArgs) Handles brgy25button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Pantay Fatima"
        brgyform.loadFormBrgy25()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy26button_Click(sender As Object, e As EventArgs) Handles brgy26button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Pantay Laud"
        brgyform.loadFormBrgy26()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy27button_Click(sender As Object, e As EventArgs) Handles brgy27button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Paoa"
        brgyform.loadFormBrgy27()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy28button_Click(sender As Object, e As EventArgs) Handles brgy28button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Paratong"
        brgyform.loadFormBrgy28()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy29button_Click(sender As Object, e As EventArgs) Handles brgy29button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Pong-ol"
        brgyform.loadFormBrgy29()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy30button_Click(sender As Object, e As EventArgs) Handles brgy30button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Purok-a-bassit"
        brgyform.loadFormBrgy30()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy31button_Click(sender As Object, e As EventArgs) Handles brgy31button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Purok-a-dackel"
        brgyform.loadFormBrgy31()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy32button_Click(sender As Object, e As EventArgs) Handles brgy32button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Raois"
        brgyform.loadFormBrgy32()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy33button_Click(sender As Object, e As EventArgs) Handles brgy33button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Salindeg "
        brgyform.loadFormBrgy34()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy34button_Click(sender As Object, e As EventArgs) Handles brgy34button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Rugsuanan"
        brgyform.loadFormBrgy33()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy35button_Click(sender As Object, e As EventArgs) Handles brgy35button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay San Jose"
        brgyform.loadFormBrgy35()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy36button_Click(sender As Object, e As EventArgs) Handles brgy36button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay San Julian Norte"
        brgyform.loadFormBrgy36()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy37button_Click(sender As Object, e As EventArgs) Handles brgy37button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay San Julian Sur"
        brgyform.loadFormBrgy37()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy38button_Click(sender As Object, e As EventArgs) Handles brgy38button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay San Pedro"
        brgyform.loadFormBrgy38()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub

    Private Sub brgy39button_Click(sender As Object, e As EventArgs) Handles brgy39button.Click
        brgyform.Show()
        Me.Hide()
        brgyform.Label14.Text = "Barangay Tamag"
        brgyform.loadFormBrgy39()
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            brgyform.TextBoxID.Enabled = False
            brgyform.TextBoxFname.Enabled = False
            brgyform.TextBoxLname.Enabled = False
            brgyform.ComboBoxGender.Enabled = False
            brgyform.TextBoxContact.Enabled = False
            brgyform.TextBoxMname.Enabled = False
            brgyform.TextBoxEmail.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxYouthAge.Enabled = False
            brgyform.ComboBoxEducation.Enabled = False
            brgyform.ComboBoxClassification.Enabled = False
            brgyform.ComboBoxCivil.Enabled = False
            brgyform.ComboBoxWork.Enabled = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
            brgyform.DateTimePicker1.Enabled = False
        Else
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True
            brgyform.btnClear.Visible = True
            brgyform.btnSave.Visible = True
            brgyform.btnEdit.Visible = True
            brgyform.Button1.Visible = True
            brgyform.btnDelete.Visible = True
        End If
    End Sub
    Public Sub loadFormArchive()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
        youthclassification,educ_id,workstatus,brgy_id from information_archive Order by lname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub

    Private Sub Button47_Click(sender As Object, e As EventArgs) Handles Button47.Click
        With ofd
            .Filter = "PDF|*.pdf"
            .Multiselect = False
            .Title = "Add documents"
            If ofd.ShowDialog = 1 Then
                TextBox1.Text = ofd.FileName
            End If
        End With
        Button49.Enabled = True
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        isec = Date.Now.ToString("dd MMM yyyy hh:mm tt")
    End Sub

    Private Sub Button49_Click(sender As Object, e As EventArgs) Handles Button49.Click
        Dim conn As New MySqlConnection
        Dim cmd As New MySqlCommand


        Dim query As String
        conn.ConnectionString = "datasource= 157.245.54.54 ;database= sk_tionery_db;uid= thesis; pwd= 2022Thesis!;port=3306"



        Dim FileSize As UInt32
        Dim rawData() As Byte
        Dim fs As FileStream
        Dim strFileName As String = ""


        Dim stat As Integer = 0

        Dim brgy As Integer = 0
        If Label19.Text = "Ayusan Norte" Then
            brgy = 1
        ElseIf Label19.Text = "Ayusan Sur" Then
            brgy = 2
        ElseIf Label19.Text = "Barangay I" Then
            brgy = 3
        ElseIf Label19.Text = "Barangay II" Then
            brgy = 4
        ElseIf Label19.Text = "Barangay III" Then
            brgy = 5
        ElseIf Label19.Text = "Barangay IV" Then
            brgy = 6
        ElseIf Label19.Text = "Barangay V" Then
            brgy = 7
        ElseIf Label19.Text = "Barangay VI" Then
            brgy = 8
        ElseIf Label19.Text = "Barangay VII" Then
            brgy = 9
        ElseIf Label19.Text = "Barangay VIII" Then
            brgy = 10
        ElseIf Label19.Text = "Barangay IX" Then
            brgy = 11
        ElseIf Label19.Text = "Barraca" Then
            brgy = 12
        ElseIf Label19.Text = "Beddeng Daya" Then
            brgy = 13
        ElseIf Label19.Text = "Beddeng Laud" Then
            brgy = 14
        ElseIf Label19.Text = "Bongtolan" Then
            brgy = 15
        ElseIf Label19.Text = "Bulala" Then
            brgy = 16
        ElseIf Label19.Text = "Cabalangegan" Then
            brgy = 17
        ElseIf Label19.Text = "Cabaroan Daya" Then
            brgy = 18
        ElseIf Label19.Text = "Cabaroan Laud" Then
            brgy = 19
        ElseIf Label19.Text = "Camangaan" Then
            brgy = 20
        ElseIf Label19.Text = "Capangpangan" Then
            brgy = 21
        ElseIf Label19.Text = "Mindoro" Then
            brgy = 22
        ElseIf Label19.Text = "Nagsangalan" Then
            brgy = 23
        ElseIf Label19.Text = "Pantay Daya" Then
            brgy = 24
        ElseIf Label19.Text = "Pantay Fatima" Then
            brgy = 25
        ElseIf Label19.Text = "Pantay Laud" Then
            brgy = 26
        ElseIf Label19.Text = "Paoa" Then
            brgy = 27
        ElseIf Label19.Text = "Paratong" Then
            brgy = 28
        ElseIf Label19.Text = "Pong-ol" Then
            brgy = 29
        ElseIf Label19.Text = "Purok-a-bassit" Then
            brgy = 30
        ElseIf Label19.Text = "Purok-a-dackel" Then
            brgy = 31
        ElseIf Label19.Text = "Raois" Then
            brgy = 32
        ElseIf Label19.Text = "Rugsaunan" Then
            brgy = 33
        ElseIf Label19.Text = "Salindeg" Then
            brgy = 34
        ElseIf Label19.Text = "San Jose" Then
            brgy = 35
        ElseIf Label19.Text = "San Julian Norte" Then
            brgy = 36
        ElseIf Label19.Text = "San Julian Sur!" Then
            brgy = 37
        ElseIf Label19.Text = "San Pedro!" Then
            brgy = 38
        ElseIf Label19.Text = "Tamag!" Then
            brgy = 39

        End If
        Dim AD As String = ""
        Dim Name = Label23.Text

        Try
            fs = New FileStream(TextBox1.Text, FileMode.Open, FileAccess.Read)
            FileSize = fs.Length
            strFileName = Path.GetFileName(TextBox1.Text)
            rawData = New Byte(FileSize) {}
            fs.Read(rawData, 0, FileSize)
            fs.Close()

            conn.Open()





            query = "INSERT INTO report_tbl(brgy_id, Name, file, time, file_size, file_name,status,approved_date) VALUES (@BRY,@Name,@Data, @Time, @FileSize, @FileName,@Stat,@AD)"
            'query = "INSERT INTO monthlyreport VALUES (NULL, @BRY, @Time, @FileName, @FileSize, @Data)"



            cmd.Connection = conn
            cmd.CommandText = query
            cmd.Parameters.AddWithValue("@BRY", brgy)
            cmd.Parameters.AddWithValue("@Name", Name)
            cmd.Parameters.AddWithValue("@Data", rawData)
            cmd.Parameters.AddWithValue("@Time", isec)
            cmd.Parameters.AddWithValue("@FileSize", FileSize)
            cmd.Parameters.AddWithValue("@FileName", strFileName)
            cmd.Parameters.AddWithValue("@Stat", stat)
            cmd.Parameters.AddWithValue("@AD", AD)
            cmd.ExecuteNonQuery()

            conn.Close()
            MessageBox.Show("Successfully Added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            loadFormReports()

        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        '

    End Sub

    Private Sub Button59_Click(sender As Object, e As EventArgs) Handles Button59.Click


        If TextBox1.Text = "" Then
            MessageBox.Show("Please Select Data", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Else
            Form4.Show()
            Form4.Label2.Text = "Download File"
        End If
    End Sub

    Sub download()
        Dim conn As New MySqlConnection
        Dim cmd As New MySqlCommand
        Dim myData As MySqlDataReader
        Dim query As String
        Dim rawData() As Byte
        Dim FileSize As UInt32
        Dim fs As FileStream
        Dim strFileName As String

        conn.ConnectionString = "datasource= 157.245.54.54 ;database= sk_tionery_db;uid= thesis; pwd= 2022Thesis!;port=3306"

        query = "Select file_name, file_size, file FROM report_tbl WHERE repID = '" & DataGridView1.CurrentRow.Cells(0).Value & "'"

        Try
            conn.Open()
            cmd.Connection = conn
            cmd.CommandText = query

            myData = cmd.ExecuteReader

            If Not myData.HasRows Then Throw New Exception("No Blob file")

            myData.Read()

            FileSize = myData.GetUInt32(myData.GetOrdinal("file_size"))
            strFileName = myData.GetString("file_name")
            rawData = New Byte(FileSize) {}

            myData.GetBytes(myData.GetOrdinal("file"), 0, rawData, 0, FileSize)

            fs = New FileStream("C:\Download\" + strFileName, FileMode.OpenOrCreate, FileAccess.Write)
            fs.Write(rawData, 0, FileSize)
            fs.Close()

            MessageBox.Show("File written on disk", "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            myData.Close()
            conn.Close()

        Catch ex As Exception
            MessageBox.Show("Error " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub loadFormReports()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT a. repID, b.brgy_name,Name, time, file_name, c.status_name,approved_date from report_tbl as a Left outer join barangay_tbl as b on a.brgy_id = b.brgy_id Left outer join status_tbl as c on a.status = c.status_id Order by time DESC;" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            DataGridView1.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                DataGridView1.Rows.Add()
                DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                DataGridView1.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                DataGridView1.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub



    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        If TextBox1.Text = "" Then
            MessageBox.Show("Please Select Data", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Else
            Dim result = MessageBox.Show("Are you sure you want to APPROVE the file?", "File Selected", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If result = DialogResult.No Then
                Exit Sub
            ElseIf result = DialogResult.Yes Then
                Form4.Show()
                Form4.Label2.Text = "Approve File"
            End If
        End If
    End Sub

    Private Sub DataGridView1_CellEnter(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellEnter
        TextBox1.Text = DataGridView1.CurrentRow.Cells(3).Value

        Button49.Enabled = False
        If Label20.Text = "SK Federated" Or
                Label20.Text = "LYDO" And
            DataGridView1.CurrentRow.Cells(4).Value = "Pending" Then
            Button59.Enabled = True

        ElseIf Label20.Text = "SK Chairperson" And
            DataGridView1.CurrentRow.Cells(4).Value = "Pending" Then
            Button59.Enabled = False
        ElseIf Label20.Text = "SK Chairperson" And
                DataGridView1.CurrentRow.Cells(4).Value = "Approved" Then
            Button59.Enabled = True
        End If
    End Sub

    Sub approve()
        Dim db = New Database
        Dim dt As New DataTable
        With db
            .sqlStr = "Update report_tbl set status = 1 ,  approved_date = '" & isec & "'  where repID = '" & DataGridView1.CurrentRow.Cells(0).Value & "'"
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt. ( brgy_id = " & brgy1 & ")"
            .close()


            MessageBox.Show("Suucessfully Approved", "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            dt = db.sqlDt
            DataGridView1.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                DataGridView1.Rows.Add()
                DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                DataGridView1.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                DataGridView1.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
            Next
        End With

        loadFormReports()




    End Sub



    Private Sub Button60_Click(sender As Object, e As EventArgs) Handles Button60.Click
        If TextBox1.Text = "" Then
            MessageBox.Show("Please Select Data", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Else
            Dim result = MessageBox.Show("Are you sure?", "Delete Selected", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If result = DialogResult.No Then
                Exit Sub
            ElseIf result = DialogResult.Yes Then
                Form4.Show()
                Form4.Label2.Text = "Delete File"



            End If
        End If
    End Sub
    Sub delete()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "insert into report_archive (repID,brgy_id,name,time,file_name,file_size,file,status, approved_date)
                                      select repID,brgy_id,Name,time,file_name,file_size,file,status, approved_date
                                        from report_tbl
                                        where repID = '" & DataGridView1.CurrentRow.Cells(0).Value & "'"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                .close()
            End With
            Dim db1 = New Database
            Dim dt1 As New DataTable
            With db1
                .sqlStr = "delete from report_tbl where repID='" & DataGridView1.CurrentRow.Cells(0).Value & "'" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                .close()
            End With
            MessageBox.Show("Successfully Deleted", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

            loadFormReports()

            TextBox1.Text = ""


        Catch
            MessageBox.Show("Error", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

        End Try
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "Select * from account_tbl where (id_no like '%" & TextBox4.Text.Trim & "%' or lastname like '%" & TextBox4.Text.Trim & "%' or firstname like '%" & TextBox4.Text.Trim & "%' or middlename like '%" & TextBox4.Text.Trim & "%') order by lastname asc"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            DataGridView3.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                DataGridView3.Rows.Add()
                DataGridView3.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                DataGridView3.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                DataGridView3.Rows(i).Cells(2).Value = dt.Rows(i).Item(3).ToString
                DataGridView3.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                DataGridView3.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                DataGridView3.Rows(i).Cells(5).Value = dt.Rows(i).Item(6).ToString
                DataGridView3.Rows(i).Cells(6).Value = dt.Rows(i).Item(7).ToString
                DataGridView3.Rows(i).Cells(7).Value = dt.Rows(i).Item(1).ToString
                DataGridView3.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString

                If dt.Rows(i).Item(1).ToString = "0" Then
                    DataGridView3.Rows(i).Cells(7).Value = "SK Federated"
                ElseIf dt.Rows(i).Item(1).ToString = "1" Then
                    DataGridView3.Rows(i).Cells(7).Value = "SK Chairperson"
                ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                    DataGridView3.Rows(i).Cells(7).Value = "LYDO"
                End If

                If dt.Rows(i).Item(8).ToString = "1" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(8).ToString = "2" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(8).ToString = "3" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(8).ToString = "4" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(8).ToString = "5" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(8).ToString = "6" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(8).ToString = "7" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(8).ToString = "8" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(8).ToString = "9" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(8).ToString = "10" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(8).ToString = "11" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(8).ToString = "12" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Barraca"
                ElseIf dt.Rows(i).Item(8).ToString = "13" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(8).ToString = "14" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(8).ToString = "15" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(8).ToString = "16" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Bulala"
                ElseIf dt.Rows(i).Item(8).ToString = "17" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(8).ToString = "18" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(8).ToString = "19" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(8).ToString = "20" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(8).ToString = "21" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(8).ToString = "22" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(8).ToString = "23" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(8).ToString = "24" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(8).ToString = "25" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(8).ToString = "26" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(8).ToString = "27" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Paoa"
                ElseIf dt.Rows(i).Item(8).ToString = "28" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Paratong"
                ElseIf dt.Rows(i).Item(8).ToString = "29" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(8).ToString = "30" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(8).ToString = "31" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(8).ToString = "32" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Raois"
                ElseIf dt.Rows(i).Item(8).ToString = "33" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(8).ToString = "34" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(8).ToString = "35" Then
                    DataGridView3.Rows(i).Cells(8).Value = "San Jose"
                ElseIf dt.Rows(i).Item(8).ToString = "36" Then
                    DataGridView3.Rows(i).Cells(8).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(8).ToString = "37" Then
                    DataGridView3.Rows(i).Cells(8).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(8).ToString = "38" Then
                    DataGridView3.Rows(i).Cells(8).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(8).ToString = "39" Then
                    DataGridView3.Rows(i).Cells(8).Value = "Tamag"
                End If
            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Private Sub menuForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer2.Enabled = True
        ToolTip1.SetToolTip(Button47, "Open File")
        ToolTip1.SetToolTip(Button49, "Upload")
        ToolTip1.SetToolTip(Button59, "Download")
        ToolTip1.SetToolTip(Button60, "Delete")
        ToolTip1.SetToolTip(Button11, "Approve")


        'user management------
        ToolTip1.SetToolTip(Button19, "Clear")
        ToolTip1.SetToolTip(Button20, "Save")
        ToolTip1.SetToolTip(Button22, "Delete")
        ToolTip1.SetToolTip(Button21, "Edit")
        ToolTip1.SetToolTip(Button18, "Update")


        With cn
            .ConnectionString = "Server=157.245.54.54; user id = thesis; password=2022Thesis!; database = sk_tionery_db"
            .Open()
        End With

        loadGender()
        loadCivilStat()
        loadYouthAge()
        loadClassification()
        loadEduc()
        loadWork()
        QuarDate()
        GetAllActivities(cn)
        GetAllAnnouncemnt(cn)
        GetAllOfficials(cn)
        total()
        If Label20.Text = "SK Federated" Then
            '   Label20.Text = "LYDO" Then
            panelbarangay.Visible = True
            PanelMonthlyReport.Visible = False
            panelOfficials.Visible = False
            panelHistory.Visible = False
            PanelArchive.Visible = False
            PanelUserManagement.Visible = False
            panelAboutUs.Visible = False
            PanelActivities.Visible = False
            PanelSMS.Visible = False
            PanelArchive2.Visible = False
            panelReportArchive.Visible = False
            brgyform.btnClear.Visible = False
            brgyform.btnSave.Visible = False
            brgyform.btnEdit.Visible = False
            brgyform.Button1.Visible = False
            brgyform.btnDelete.Visible = False
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Label22.Text = Date.Now.ToString("dd MMM yyyy hh:mm tt")
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs)
        '     Panel8.Visible = True
    End Sub



    Private Sub Panel12_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Panel7_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Button24_Click(sender As Object, e As EventArgs)
        'Panel14.Visible = True
    End Sub

    Private Sub Button26_Click(sender As Object, e As EventArgs)
        '  Panel14.Visible = False
    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs)
        '    createEvent()
    End Sub

    Private Sub Panel8_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs)
        isec3 = Format(Now, "MM-dd-yy hh:mm tt")
    End Sub

    Private Sub MonthCalendar1_DateChanged(sender As Object, e As DateRangeEventArgs)

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)
        Seemore.Show()
    End Sub

    Private Sub Button27_Click(sender As Object, e As EventArgs) Handles Button27.Click
        loadGender()
        loadCivilStat()
        loadYouthAge()
        loadClassification()
        loadEduc()
        loadWork()
        QuarDate()
        total()
        panelbarangay.Visible = False
        PanelSMS.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelArchive2.Visible = False
        PanelStat.Visible = True


    End Sub

    Sub loadGender()
        Try
            With Chart1
                .Series.Clear()
                .Series.Add("Series1")

            End With

            Dim da As New MySqlDataAdapter("Select gender,count(id) as genTotal from information_tbl group by gender", cn)
            Dim ds As New DataSet

            da.Fill(ds, "gender")
            Chart1.DataSource = ds.Tables("gender")
            Dim series1 As Series = Chart1.Series("Series1")
            series1.ChartType = SeriesChartType.Doughnut
            series1.Name = "gender"
            With Chart1
                .Series(series1.Name).XValueMember = "gender"
                .Series(series1.Name).YValueMembers = "genTotal"
                .Series(0).LabelFormat = "{#,##0}"
                .Series(0).IsValueShownAsLabel = True

                .Series(0).LegendText = "#VALX (#PERCENT)"

            End With
        Catch
            MessageBox.Show("Failed to load", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Sub loadCivilStat()
        With Chart2
            .Series.Clear()
            .Series.Add("Series1")

        End With

        Dim da As New MySqlDataAdapter("Select civil_status,count(id) as civTotal from information_tbl group by civil_status", cn)
        Dim ds As New DataSet

        da.Fill(ds, "civil_status")
        Chart2.DataSource = ds.Tables("civil_status")
        Dim series1 As Series = Chart2.Series("Series1")
        series1.ChartType = SeriesChartType.Column
        series1.Name = "civil_status"
        With Chart2
            .Series(series1.Name).XValueMember = "civil_status"
            .Series(series1.Name).YValueMembers = "civTotal"
            .Series(0).Label = ("#PERCENT{P}")
            '.Series(0).IsValueShownAsLabel = True

            .Series(0).LegendText = "Civil Status"
        End With
    End Sub

    Sub loadYouthAge()
        With Chart3
            .Series.Clear()
            .Series.Add("Series1")

        End With

        Dim da As New MySqlDataAdapter("Select youth_age,count(id) as ageTotal from information_tbl group by youth_age", cn)
        Dim ds As New DataSet

        da.Fill(ds, "youth_age")
        Chart3.DataSource = ds.Tables("youth_age")
        Dim series1 As Series = Chart3.Series("Series1")
        series1.ChartType = SeriesChartType.Pie
        series1.Name = "youth_age"
        With Chart3
            .Series(series1.Name).XValueMember = "youth_age"
            .Series(series1.Name).YValueMembers = "ageTotal"
            .Series(0).LabelFormat = "{#,##0}"
            .Series(0).IsValueShownAsLabel = True

            .Series(0).LegendText = "#VALX (#PERCENT)"
        End With
    End Sub

    Sub loadClassification()
        With Chart4
            .Series.Clear()
            .Series.Add("Series1")

        End With

        Dim da As New MySqlDataAdapter("Select youth_classification,count(id) as classTotal from information_tbl group by youth_classification", cn)
        Dim ds As New DataSet

        da.Fill(ds, "youth_classification")
        Chart4.DataSource = ds.Tables("youth_classification")
        Dim series1 As Series = Chart4.Series("Series1")
        series1.ChartType = SeriesChartType.Pyramid
        series1.Name = "youth_classification"
        With Chart4
            .Series(series1.Name).XValueMember = "youth_classification"
            .Series(series1.Name).YValueMembers = "classTotal"
            .Series(0).LabelFormat = "{#,##0}"
            .Series(0).IsValueShownAsLabel = True

            .Series(0).LegendText = "#VALX (#PERCENT)"

        End With
    End Sub
    Sub loadEduc()
        Dim edu As String
        With Chart5
            .Series.Clear()
            .Series.Add("Series1")

        End With

        Dim da As New MySqlDataAdapter("Select information_tbl.educ_id,count(id) as educTotal, educ_tbl.educational_level FROM information_tbl INNER JOIN educ_tbl on information_tbl.educ_id= educ_tbl.educ_id GROUP BY educ_id", cn)
        Dim ds As New DataSet

        da.Fill(ds, "educ_id")
        Chart5.DataSource = ds.Tables("educ_id")
        Dim series1 As Series = Chart5.Series("Series1")
        series1.ChartType = SeriesChartType.Column
        series1.Name = "educ_id"
        With Chart5
            .Series(series1.Name).XValueMember = "educational_level"
            .Series(series1.Name).YValueMembers = "educTotal"
            .Series(0).Label = ("#PERCENT{P}")
            .Series(0).IsValueShownAsLabel = True
            ' .Series(0).LegendText = text
            .Series(0).LegendText = "Educational Attainment"

        End With
    End Sub
    Sub loadWork()

        With Chart6
            .Series.Clear()
            .Series.Add("Series1")

        End With

        Dim da As New MySqlDataAdapter("Select work_status,count(id) as workTotal from information_tbl group by work_status", cn)
        Dim ds As New DataSet

        da.Fill(ds, "work_status")
        Chart6.DataSource = ds.Tables("work_status")
        Dim series1 As Series = Chart6.Series("Series1")
        series1.ChartType = SeriesChartType.Doughnut
        series1.Name = "work_status"
        With Chart6
            .Series(series1.Name).XValueMember = "work_status"
            .Series(series1.Name).YValueMembers = "workTotal"
            .Series(0).LabelFormat = "{#,##0}"
            .Series(0).IsValueShownAsLabel = True
            ' .Series(0).LegendText = text
            .Series(0).LegendText = "#VALX (#PERCENT)"

        End With
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        panelbarangay.Visible = False
        PanelSMS.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelMonthlyReport.Visible = False
        PanelArchive2.Visible = False
        panelReportArchive.Visible = True
        PanelSMS.Visible = False
        loadFormReportsArchive()
    End Sub
    Public Sub loadFormReportsArchive()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT a. repID, b.brgy_name,name, time, file_name, c.status_name,approved_date from report_archive as a Left outer join barangay_tbl as b on a.brgy_id = b.brgy_id Left outer join status_tbl as c on a.status = c.status_id Order by time DESC;" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            DataGridView2.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                DataGridView2.Rows.Add()
                DataGridView2.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                DataGridView2.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                DataGridView2.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                DataGridView2.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                DataGridView2.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                DataGridView2.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                DataGridView2.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs)
        panelbarangay.Visible = False
        PanelSMS.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelMonthlyReport.Visible = False
        PanelArchive2.Visible = False
        panelReportArchive.Visible = True
        loadFormQuarterlyReportsArchive()
        Label89.Text = "QUARTERLY REPORT ARCHIVE"
    End Sub
    Public Sub loadFormQuarterlyReportsArchive()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT repID,brgy_id, time, file_name,status,approved_date from report_archive where report_id = 2 Order by time ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            DataGridView2.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                DataGridView2.Rows.Add()
                DataGridView2.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                DataGridView2.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                DataGridView2.Rows(i).Cells(2).Value = dt.Rows(i).Item(3).ToString
                DataGridView2.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                DataGridView2.Rows(i).Cells(4).Value = dt.Rows(i).Item(2).ToString
                DataGridView2.Rows(i).Cells(5).Value = dt.Rows(i).Item(5).ToString
                If dt.Rows(i).Item(1).ToString = "1" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(1).ToString = "3" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(1).ToString = "4" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(1).ToString = "5" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(1).ToString = "6" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(1).ToString = "7" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(1).ToString = "8" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(1).ToString = "9" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(1).ToString = "10" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(1).ToString = "11" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(1).ToString = "12" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Barraca"
                ElseIf dt.Rows(i).Item(1).ToString = "13" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(1).ToString = "14" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(1).ToString = "15" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(1).ToString = "16" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Bulala"
                ElseIf dt.Rows(i).Item(1).ToString = "17" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(1).ToString = "18" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(1).ToString = "19" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(1).ToString = "20" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(1).ToString = "21" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(1).ToString = "22" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(1).ToString = "23" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(1).ToString = "24" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(1).ToString = "25" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(1).ToString = "26" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(1).ToString = "27" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Paoa"
                ElseIf dt.Rows(i).Item(1).ToString = "28" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Paratong"
                ElseIf dt.Rows(i).Item(1).ToString = "29" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(1).ToString = "30" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(1).ToString = "31" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(1).ToString = "32" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Raois"
                ElseIf dt.Rows(i).Item(1).ToString = "33" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(1).ToString = "34" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(1).ToString = "35" Then
                    DataGridView2.Rows(i).Cells(1).Value = "San Jose"
                ElseIf dt.Rows(i).Item(1).ToString = "36" Then
                    DataGridView2.Rows(i).Cells(1).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(1).ToString = "37" Then
                    DataGridView2.Rows(i).Cells(1).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(1).ToString = "38" Then
                    DataGridView2.Rows(i).Cells(1).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(1).ToString = "39" Then
                    DataGridView2.Rows(i).Cells(1).Value = "Tamag"
                End If
                If dt.Rows(i).Item(4).ToString = "0" Then
                    DataGridView2.Rows(i).Cells(3).Value = "Pending"
                ElseIf dt.Rows(i).Item(4).ToString = "1" Then
                    DataGridView2.Rows(i).Cells(3).Value = "Approved"
                End If
            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Private Sub TextBox9_TextChanged(sender As Object, e As EventArgs) Handles TextBox9.TextChanged

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT repID, brgy_id,name, time, file_name, status,approved_date from report_archive where brgy_id IN (select brgy_id from barangay_tbl where brgy_name like '%" & TextBox9.Text.Trim & "%') or name like '%" & TextBox9.Text.Trim & "%' Order by time DESC;" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            DataGridView2.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                DataGridView2.Rows.Add()
                DataGridView2.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                DataGridView2.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                DataGridView2.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                DataGridView2.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                DataGridView2.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                DataGridView2.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                DataGridView2.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString

                If dt.Rows(i).Item(5).ToString = "0" Then
                    DataGridView2.Rows(i).Cells(4).Value = "Pending"
                ElseIf dt.Rows(i).Item(5).ToString = "1" Then
                    DataGridView2.Rows(i).Cells(4).Value = "Approved"
                End If
                If dt.Rows(i).Item(1).ToString = "1" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(1).ToString = "3" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(1).ToString = "4" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(1).ToString = "5" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(1).ToString = "6" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(1).ToString = "7" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(1).ToString = "8" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(1).ToString = "9" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(1).ToString = "10" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(1).ToString = "11" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(1).ToString = "12" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Barraca"
                ElseIf dt.Rows(i).Item(1).ToString = "13" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(1).ToString = "14" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(1).ToString = "15" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(1).ToString = "16" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Bulala"
                ElseIf dt.Rows(i).Item(1).ToString = "17" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(1).ToString = "18" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(1).ToString = "19" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(1).ToString = "20" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(1).ToString = "21" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(1).ToString = "22" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(1).ToString = "23" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(1).ToString = "24" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(1).ToString = "25" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(1).ToString = "26" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(1).ToString = "27" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Paoa"
                ElseIf dt.Rows(i).Item(1).ToString = "28" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Paratong"
                ElseIf dt.Rows(i).Item(1).ToString = "29" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(1).ToString = "30" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(1).ToString = "31" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(1).ToString = "32" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Raois"
                ElseIf dt.Rows(i).Item(1).ToString = "33" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(1).ToString = "34" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(1).ToString = "35" Then
                    DataGridView2.Rows(i).Cells(2).Value = "San Jose"
                ElseIf dt.Rows(i).Item(1).ToString = "36" Then
                    DataGridView2.Rows(i).Cells(2).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(1).ToString = "37" Then
                    DataGridView2.Rows(i).Cells(2).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(1).ToString = "38" Then
                    DataGridView2.Rows(i).Cells(2).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(1).ToString = "39" Then
                    DataGridView2.Rows(i).Cells(2).Value = "Tamag"
                End If
            Next
            'loadFormReports()
        Catch
            MessageBox.Show("error")
        End Try
    End Sub



    Private Sub Button28_Click(sender As Object, e As EventArgs) Handles Button28.Click
        panelbarangay.Visible = False

        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = True
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelArchive2.Visible = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False
    End Sub

    Private Sub Button29_Click(sender As Object, e As EventArgs) Handles Button29.Click
        panelbarangay.Visible = False

        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = True
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelArchive2.Visible = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False
    End Sub
    Public Sub loadingbarangay()
        brgyform.TextBoxID.Enabled = True
        brgyform.TextBoxFname.Enabled = True
        brgyform.TextBoxLname.Enabled = True
        brgyform.ComboBoxGender.Enabled = True
        brgyform.TextBoxContact.Enabled = True
        brgyform.TextBoxMname.Enabled = True
        brgyform.TextBoxEmail.Enabled = True
        brgyform.ComboBoxCivil.Enabled = True
        brgyform.ComboBoxYouthAge.Enabled = True
        brgyform.ComboBoxEducation.Enabled = True
        brgyform.ComboBoxClassification.Enabled = True
        brgyform.ComboBoxCivil.Enabled = True
        brgyform.ComboBoxWork.Enabled = True
        If Label20.Text = "SK Federated" Or
            Label20.Text = "LYDO" Then
            panelbarangay.Visible = True
            PanelMonthlyReport.Visible = False
            panelOfficials.Visible = False
            panelHistory.Visible = False
            PanelArchive.Visible = False
            PanelUserManagement.Visible = False
            panelAboutUs.Visible = False
            PanelActivities.Visible = False
            PanelSMS.Visible = False
            PanelArchive2.Visible = False
            panelReportArchive.Visible = False

        ElseIf Label19.Text = "Ayusan Norte" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Ayusan Norte"
            brgyform.loadFormBrgy1()
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
            Me.Hide()
        ElseIf Label19.Text = "Ayusan Sur" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Ayusan Sur"
            brgyform.loadFormBrgy2()
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
            Me.Hide()
        ElseIf Label19.Text = "Barangay I" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay I"
            brgyform.loadFormBrgy3()
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
            Me.Hide()
        ElseIf Label19.Text = " Barangay II" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay II"
            brgyform.loadFormBrgy4()
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Barangay III" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay III"
            brgyform.loadFormBrgy5()
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Barangay IV" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay IV"
            brgyform.loadFormBrgy6()
            brgyform.DateTimePicker1.Enabled = True
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Barangay V" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay V"
            brgyform.loadFormBrgy7()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Barangay VI" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay VI"
            brgyform.loadFormBrgy8()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Barangay VII" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay VII"
            brgyform.loadFormBrgy9()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Barangay VIII" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay VIII"
            brgyform.loadFormBrgy10()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Barangay IX" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay IX"
            brgyform.loadFormBrgy11()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Barraca" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Barraca"
            brgyform.loadFormBrgy12()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Beddeng Daya" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Beddeng Daya"
            brgyform.loadFormBrgy13()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Beddeng Laud" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Beddeng Laud"
            brgyform.loadFormBrgy14()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Bongtolan" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Bongtolan"
            brgyform.loadFormBrgy15()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Bulala" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Bulala"
            brgyform.loadFormBrgy16()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Cabalangegan" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Cabalangegan"
            brgyform.loadFormBrgy17()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Cabaroan Daya" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Cabaroan Daya"
            brgyform.loadFormBrgy18()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Cabaroan Laud" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Cabaroan Laud"
            brgyform.loadFormBrgy19()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Camangaan" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Camangaan"
            brgyform.loadFormBrgy20()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Capangpangan" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Capangpangan"
            brgyform.loadFormBrgy21()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Mindoro" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Mindoro"
            brgyform.loadFormBrgy22()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Nagsangalan" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Nagsangalan"
            brgyform.loadFormBrgy23()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Pantay Daya" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Pantay Daya"
            brgyform.loadFormBrgy24()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Pantay Fatima" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Pantay Fatima"
            brgyform.loadFormBrgy25()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Pantay Laud" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Pantay Laud"
            brgyform.loadFormBrgy26()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Paoa" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Paoa"
            brgyform.loadFormBrgy27()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Paratong" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Paratong"
            brgyform.loadFormBrgy28()
            brgyform.Show()
        ElseIf Label19.Text = "Pong-ol" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Pong-ol"
            brgyform.loadFormBrgy29()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Purok-a-bassit" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Purok-a-bassit"
            brgyform.loadFormBrgy30()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Purok-a-dackel" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Purok-a-dackel"
            brgyform.loadFormBrgy31()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "SK Raois" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Raois"
            brgyform.loadFormBrgy32()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Rugsaunan" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Rugsaunan"
            brgyform.loadFormBrgy33()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Salindeg" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Salindeg"
            brgyform.loadFormBrgy34()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "San Jose" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay San Jose"
            brgyform.loadFormBrgy35()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "San Julian Norte" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay San Julian Norte"
            brgyform.loadFormBrgy36()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "San Julian Sur" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay San Julian Sur"
            brgyform.loadFormBrgy37()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "San Pedro" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay San Pedro"
            brgyform.loadFormBrgy38()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        ElseIf Label19.Text = "Tamag" And Label20.Text = "SK Chairperson" Then
            brgyform.Label14.Text = "Barangay Tamag"
            brgyform.loadFormBrgy39()
            brgyform.TextBoxID.Enabled = True
            brgyform.TextBoxFname.Enabled = True
            brgyform.TextBoxLname.Enabled = True
            brgyform.ComboBoxGender.Enabled = True
            brgyform.TextBoxContact.Enabled = True
            brgyform.TextBoxMname.Enabled = True
            brgyform.TextBoxEmail.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxYouthAge.Enabled = True
            brgyform.ComboBoxEducation.Enabled = True
            brgyform.ComboBoxClassification.Enabled = True
            brgyform.ComboBoxCivil.Enabled = True
            brgyform.ComboBoxWork.Enabled = True

            brgyform.Show()
        End If
    End Sub

    Private Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click

        Dim aaa As String = RichTextBox1.Text.Trim
        Dim bbb As String = aaa.Replace("'", "\'")

        Dim ccc As String = TextBox12.Text.Trim
        Dim ddd As String = ccc.Replace("'", "\'")

        If TextBox12.Text = "" Or
           RichTextBox1.Text = "" Then
            MessageBox.Show("Missing Fields", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Else


            Dim user As Integer
                Dim brgy2 As Integer
                Dim db1 = New Database
                Dim dt1 As New DataTable



                With db1
                    .sqlStr = "SELECT password, user_id,brgy_id from account_tbl where username = '" & StartForm.TextBox1.Text.Trim() & "'" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                    .close()
                End With
                dt1 = db1.sqlDt

                If dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 1 Then
                    user = 0
                    brgy2 = 1
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 2 Then
                    user = 0
                    brgy2 = 2
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 3 Then
                    user = 0
                    brgy2 = 3
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 4 Then
                    user = 0
                    brgy2 = 4
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 5 Then
                    user = 0
                    brgy2 = 5
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 6 Then
                    user = 0
                    brgy2 = 6
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 7 Then
                    user = 0
                    brgy2 = 7
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 8 Then
                    user = 0
                    brgy2 = 8
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 9 Then
                    user = 0
                    brgy2 = 9
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 10 Then
                    user = 0
                    brgy2 = 10
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 11 Then
                    user = 0
                    brgy2 = 11
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 12 Then
                    user = 0
                    brgy2 = 12
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 13 Then
                    user = 0
                    brgy2 = 13
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 14 Then
                    user = 0
                    brgy2 = 14
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 15 Then
                    user = 0
                    brgy2 = 15
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 16 Then
                    user = 0
                    brgy2 = 16
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 17 Then
                    user = 0
                    brgy2 = 17
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 18 Then
                    user = 0
                    brgy2 = 18
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 19 Then
                    user = 0
                    brgy2 = 19
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 20 Then
                    user = 0
                    brgy2 = 20
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 21 Then
                    user = 0
                    brgy2 = 21
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 22 Then
                    user = 0
                    brgy2 = 22
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 23 Then
                    user = 0
                    brgy2 = 23
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 24 Then
                    user = 0
                    brgy2 = 24
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 25 Then
                    user = 0
                    brgy2 = 25
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 26 Then
                    user = 0
                    brgy2 = 26
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 27 Then
                    user = 0
                    brgy2 = 27
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 28 Then
                    user = 0
                    brgy = 28
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 29 Then
                    user = 0
                    brgy2 = 29
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 30 Then
                    user = 0
                    brgy2 = 30
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 31 Then
                    user = 0
                    brgy2 = 31
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 32 Then
                    user = 0
                    brgy2 = 32
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 33 Then
                    user = 0
                    brgy2 = 33
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 34 Then
                    user = 0
                    brgy2 = 34
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 35 Then
                    user = 0
                    brgy2 = 35
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 36 Then
                    user = 0
                    brgy2 = 36
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 37 Then
                    user = 0
                    brgy2 = 37
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 38 Then
                    user = 0
                    brgy2 = 38
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 39 Then
                    user = 0
                    brgy2 = 39
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 1 Then
                    user = 1
                    brgy2 = 1
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 2 Then
                    user = 1
                    brgy2 = 2
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 3 Then
                    user = 1
                    brgy2 = 3
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 4 Then
                    user = 1
                    brgy2 = 4
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 5 Then
                    user = 1
                    brgy2 = 5
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 6 Then
                    user = 1
                    brgy2 = 6
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 7 Then
                    user = 1
                    brgy2 = 7
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 8 Then
                    user = 1
                    brgy2 = 8
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 9 Then
                    user = 1
                    brgy2 = 9
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 10 Then
                    user = 1
                    brgy2 = 10
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 11 Then
                    user = 1
                    brgy2 = 11
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 12 Then
                    user = 1
                    brgy2 = 12
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 13 Then
                    user = 1
                    brgy2 = 13
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 14 Then
                    user = 1
                    brgy2 = 14
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 15 Then
                    user = 1
                    brgy2 = 15
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 16 Then
                    user = 1
                    brgy2 = 16
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 17 Then
                    user = 1
                    brgy2 = 17
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 18 Then
                    user = 1
                    brgy2 = 18
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 19 Then
                    user = 1
                    brgy2 = 19
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 20 Then
                    user = 1
                    brgy2 = 20
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 21 Then
                    user = 1
                    brgy2 = 21
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 22 Then
                    user = 1
                    brgy2 = 22
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 23 Then
                    user = 1
                    brgy2 = 23
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 24 Then
                    user = 1
                    brgy2 = 24
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 25 Then
                    user = 1
                    brgy2 = 25
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 26 Then
                    user = 1
                    brgy2 = 26
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 27 Then
                    user = 1
                    brgy2 = 27
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 28 Then
                    user = 1
                    brgy2 = 28
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 29 Then
                    user = 1
                    brgy2 = 29
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 30 Then
                    user = 1
                    brgy2 = 30
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 31 Then
                    user = 1
                    brgy2 = 31
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 32 Then
                    user = 1
                    brgy2 = 32
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 33 Then
                    user = 1
                    brgy2 = 33
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 34 Then
                    user = 1
                    brgy2 = 34
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 35 Then
                    user = 1
                    brgy2 = 35
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 36 Then
                    user = 1
                    brgy2 = 36
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 37 Then
                    user = 1
                    brgy2 = 37
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 38 Then
                    user = 1
                    brgy2 = 38
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 39 Then
                    user = 1
                    brgy2 = 39
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 1 Then
                    user = 2
                    brgy2 = 1
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 2 Then
                    user = 2
                    brgy2 = 2
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 3 Then
                    user = 2
                    brgy2 = 3
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 4 Then
                    user = 2
                    brgy2 = 4
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 5 Then
                    user = 2
                    brgy2 = 5
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 6 Then
                    user = 2
                    brgy2 = 6
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 7 Then
                    user = 2
                    brgy2 = 7
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 8 Then
                    user = 2
                    brgy2 = 8
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 9 Then
                    user = 2
                    brgy2 = 9
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 10 Then
                    user = 2
                    brgy2 = 10
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 11 Then
                    user = 2
                    brgy2 = 11
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 12 Then
                    user = 2
                    brgy2 = 12
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 13 Then
                    user = 2
                    brgy2 = 13
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 14 Then
                    user = 2
                    brgy2 = 14
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 15 Then
                    user = 2
                    brgy2 = 15
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 16 Then
                    user = 2
                    brgy2 = 16
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 17 Then
                    user = 2
                    brgy2 = 17
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 18 Then
                    user = 2
                    brgy2 = 18
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 19 Then
                    user = 2
                    brgy2 = 19
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 20 Then
                    user = 2
                    brgy2 = 20
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 21 Then
                    user = 2
                    brgy2 = 21
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 22 Then
                    user = 2
                    brgy2 = 22
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 23 Then
                    user = 2
                    brgy2 = 23
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 24 Then
                    user = 2
                    brgy2 = 24
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 25 Then
                    user = 2
                    brgy2 = 25
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 26 Then
                    user = 2
                    brgy2 = 26
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 27 Then
                    user = 2
                    brgy2 = 27
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 28 Then
                    user = 2
                    brgy2 = 28
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 29 Then
                    user = 2
                    brgy2 = 29
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 30 Then
                    user = 2
                    brgy2 = 30
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 31 Then
                    user = 2
                    brgy2 = 31
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 32 Then
                    user = 2
                    brgy2 = 32
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 33 Then
                    user = 2
                    brgy2 = 33
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 34 Then
                    user = 2
                    brgy2 = 34
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 35 Then
                    user = 2
                    brgy2 = 35
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 36 Then
                    user = 2
                    brgy2 = 36
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 37 Then
                    user = 2
                    brgy2 = 37
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 38 Then
                    user = 2
                    brgy2 = 38
                ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 39 Then
                    user = 2
                    brgy2 = 39

                End If



                Try

                Dim datasource As String = "157.245.54.54" 'default
                Dim username As String = "thesis" 'default
                Dim password As String = "2022Thesis!"
                Dim database As String = "sk_tionery_db" 'change
                    Dim port As String = "3306" 'default

                    Dim connn As MySqlConnection = New MySqlConnection("datasource=" + datasource + ";database=" + database + ";uid=" + username + ";pwd=" + password + ";port=" + port)
                    ' Dim db_obj = New Database
                    ' db_obj.connect()
                    connn.Open()
                Dim select_str As String = "INSERT INTO `activities` (`title`, `description`,`short_des`, `activity_date`, `user_id`,`brgy_id`,posted_time,`username`) VALUES ('" & ddd & "','" & bbb & "','" & bbb & "','" & DateTimePicker1.Text.Trim & "','" & user & "','" & brgy2 & "','" & isec & "','" & Label23.Text & "'); Select LAST_INSERT_ID();"
                Dim insert_cmd As MySqlCommand = New MySqlCommand(select_str, connn)
                    Dim result_id As Integer = CInt(insert_cmd.ExecuteScalar())
                    ' MessageBox.Show(result_id)

                    MessageBox.Show("Please Wait.. SMS is sending", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

                    CreateChildPanel()
                '  CreateChildPanel2(childPanel)
                CreateChildTitle(childPanel, ddd)
                CreateChildDesc(childPanel, bbb)
                CreateChildDate(childPanel, DateTimePicker1.Text) 'date
                    CreateChildBarangay(childPanel, Label19.Text) 'brgy
                    CreateChildUser(childPanel, Label20.Text) 'user_id
                    CreateChildLabeldate(childPanel, isec) 'posted_time
                    CreateName(childPanel, Label23.Text)
                    link(childPanel, "See More", result_id)



                Dim recipient, msg, apicode, pass, result, description As String
                msg = Label20.Text + " " + Label19.Text + " " + Label23.Text + " " + TextBox12.Text + " " + RichTextBox1.Text + " " + "Date of Activity:" + " " + DateTimePicker1.Text
                apicode = "ST-ARLEN474863_VHTQ3"
                pass = "m49(wzzrmn"
                result = 0

                Dim db3 = New Database
                Dim dt3 As New DataTable
                With db3
                    ' "SELECT a.title, description, activity_date, posted_date ,b.brgy_name from activities as a Left outer join barangay_tbl as b on a.brgy_id = b.brgy_id"
                    .sqlStr = "SELECT `contact` from account_tbl where contact <>'' "
                    'query String
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt3 = db3.sqlDt
                For i = 0 To dt3.Rows.Count - 1
                    recipient = dt3.Rows(i).Item(0).ToString
                    result = itexmo(recipient, msg, apicode, pass)
                Next

                Dim db4 = New Database
                Dim dt4 As New DataTable
                With db4
                    ' "SELECT a.title, description, activity_date, posted_date ,b.brgy_name from activities as a Left outer join barangay_tbl as b on a.brgy_id = b.brgy_id"
                    .sqlStr = "SELECT contact_no FROM information_tbl where contact_no <>' '"
                    'query String
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt4 = db4.sqlDt
                For i = 0 To dt4.Rows.Count - 1
                    recipient = dt4.Rows(i).Item(0).ToString
                    result = itexmo(recipient, msg, apicode, pass)
                Next


                TextBox12.Text = ""
                    RichTextBox1.Text = ""
                    DateTimePicker1.Text = ""

                MessageBox.Show("Successfully Sent", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                Me.Refresh()
                '   GetAllActivities(cn)


            Catch ex As Exception
                    MessageBox.Show("error")
                    MessageBox.Show(ex.ToString)
                End Try

            End If
    End Sub

    Function itexmo(ByVal Number As String, ByVal Message As String, ByVal ApiCode As String, ByVal ApiPassword As String)
        Using client As New Net.WebClient
            Dim parameter As New Specialized.NameValueCollection
            Dim url As String = "https://www.itexmo.com/php_api/api.php"
            parameter.Add("1", Number)
            parameter.Add("2", Message)
            parameter.Add("3", ApiCode)
            parameter.Add("passwd", ApiPassword)
            Dim rpb = client.UploadValues(url, "POST", parameter)
            itexmo = (New System.Text.UTF8Encoding).GetString(rpb)
        End Using
    End Function

    Private Sub TextBoxSearch_TextChanged(sender As Object, e As EventArgs) Handles TextBoxSearch.TextChanged
        If ComboBox1.Text = "Last Name" Then
            SLastname()
        ElseIf ComboBox1.Text = "First Name" Then
            SFirstname()
        ElseIf ComboBox1.Text = "Middle Name" Then
            SMiddlename()
        ElseIf ComboBox1.Text = "Gender" Then
            SGender()
        ElseIf ComboBox1.Text = "Birthday" Then
            SBirthday()
        ElseIf ComboBox1.Text = "Contact Number" Then
            SContact()
        ElseIf ComboBox1.Text = "Email" Then
            SEmail()
        ElseIf ComboBox1.Text = "Civil Status" Then
            SCivilStatus()
        ElseIf ComboBox1.Text = "Youth Age" Then
            SYouthAge()
        ElseIf ComboBox1.Text = "Youth Classification" Then
            SYouthclassification()
        ElseIf ComboBox1.Text = "Educational Attainment" Then
            SEduc()
        ElseIf ComboBox1.Text = "Work Status" Then
            SWork_status()
        ElseIf ComboBox1.Text = "Barangay" Then
            SBrgy()
        ElseIf ComboBox1.Text = "ID" Then
            SID()
        End If
        If TextBoxSearch.Text = "" Then
            loadFormArchive()
        End If
    End Sub
    Public Sub SLastname()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (lname like '%" & TextBoxSearch.Text.Trim & "%')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If


            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SFirstname()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (fname like '%" & TextBoxSearch.Text.Trim & "%')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SMiddlename()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (mname like '%" & TextBoxSearch.Text.Trim & "%')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SBirthday()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (birthday like '%" & TextBoxSearch.Text.Trim & "%')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SContact()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (contact like '%" & TextBoxSearch.Text.Trim & "%')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If


                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If


            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SEmail()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (email like '%" & TextBoxSearch.Text.Trim & "%')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SCivilStatus()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (civilstatus like '%" & TextBoxSearch.Text.Trim & "%')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SYouthAge()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (youthage like '%" & TextBoxSearch.Text.Trim & "%')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SYouthclassification()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (youthclassification like '%" & TextBoxSearch.Text.Trim & "%')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SGender()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (gender = '" & TextBoxSearch.Text.Trim & "')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SWork_status()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (workstatus = '" & TextBoxSearch.Text.Trim & "')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SEduc()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where educ_id In (SELECT educ_id from educ_tbl where (educational_level like '%" & TextBoxSearch.Text.Trim & "%'))"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SBrgy()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where brgy_id In (SELECT brgy_id from barangay_tbl where (brgy_name like '%" & TextBoxSearch.Text.Trim & "%'))"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If


                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If


            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SID()

        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                        youthclassification,educ_id,workstatus,brgy_id from information_archive where (archive_id like '%" & TextBoxSearch.Text.Trim & "%')"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoarchiveDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoarchiveDataGridView.Rows.Add()
                infoarchiveDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoarchiveDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoarchiveDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoarchiveDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoarchiveDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoarchiveDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoarchiveDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoarchiveDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoarchiveDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoarchiveDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoarchiveDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoarchiveDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoarchiveDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoarchiveDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoarchiveDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs)

    End Sub


    Private _EventPanelsAddedCount As Integer = 0

    Private _currentEventPanelName As String = Nothing
    '   Public Sub createEvent()
    '     Dim eventpanel As Panel
    '     eventpanel = New Panel()

    '     With eventpanel
    '        .BackColor = Color.White
    '       .Size = New Size(237, 100)
    '    .Name = "panelevent" + (_EventPanelsAddedCount + 1).ToString
    '   End With

    '   FlowLayoutPanel2.Controls.Add(eventpanel)

    '   _currentEventPanelName = eventpanel.Name
    '  _EventPanelsAddedCount += 1
    '  End Sub


    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ANNOUNCEMNETToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub RichTextBoxBrgy1_TextChanged(sender As Object, e As EventArgs)

    End Sub



    Private Sub ANNOUNCEMENTToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub


    Private Sub TabControl1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button12_Click_1(sender As Object, e As EventArgs)
        Panel19.Visible = True
    End Sub

    Private Sub TabPage4_Click(sender As Object, e As EventArgs) Handles TabPage4.Click
        ' GetAllAnnouncemnt(cn)
    End Sub

    Private Sub TabControl2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl2.SelectedIndexChanged
        If TabControl2.SelectedTab Is TabPage4 Then
            Label26.Text = "ANNOUNCEMENT"
            '  GetAllAnnouncemnt(cn)
        ElseIf TabControl2.SelectedTab Is TabPage3 Then
            Label26.Text = "ACTIVITIES AND UPDATES"

        End If
    End Sub

    Private Sub Button13_Click_1(sender As Object, e As EventArgs) Handles Button13.Click


        Dim eee As String = RichTextBox2.Text.Trim
        Dim fff As String = eee.Replace("'", "\'")

        If RichTextBox2.Text = "" Then
            MessageBox.Show("Missing Field", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Else
            Dim user As Integer
            Dim brgy2 As Integer
            Dim db1 = New Database
            Dim dt1 As New DataTable



            With db1
                .sqlStr = "SELECT password, user_id,brgy_id from account_tbl where username = '" & StartForm.TextBox1.Text.Trim() & "'" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                .close()
            End With
            dt1 = db1.sqlDt

            If dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 1 Then
                user = 0
                brgy2 = 1
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 2 Then
                user = 0
                brgy2 = 2
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 3 Then
                user = 0
                brgy2 = 3
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 4 Then
                user = 0
                brgy2 = 4
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 5 Then
                user = 0
                brgy2 = 5
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 6 Then
                user = 0
                brgy2 = 6
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 7 Then
                user = 0
                brgy2 = 7
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 8 Then
                user = 0
                brgy2 = 8
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 9 Then
                user = 0
                brgy2 = 9
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 10 Then
                user = 0
                brgy2 = 10
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 11 Then
                user = 0
                brgy2 = 11
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 12 Then
                user = 0
                brgy2 = 12
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 13 Then
                user = 0
                brgy2 = 13
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 14 Then
                user = 0
                brgy2 = 14
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 15 Then
                user = 0
                brgy2 = 15
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 16 Then
                user = 0
                brgy2 = 16
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 17 Then
                user = 0
                brgy2 = 17
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 18 Then
                user = 0
                brgy2 = 18
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 19 Then
                user = 0
                brgy2 = 19
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 20 Then
                user = 0
                brgy2 = 20
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 21 Then
                user = 0
                brgy2 = 21
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 22 Then
                user = 0
                brgy2 = 22
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 23 Then
                user = 0
                brgy2 = 23
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 24 Then
                user = 0
                brgy2 = 24
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 25 Then
                user = 0
                brgy2 = 25
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 26 Then
                user = 0
                brgy2 = 26
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 27 Then
                user = 0
                brgy2 = 27
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 28 Then
                user = 0
                brgy = 28
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 29 Then
                user = 0
                brgy2 = 29
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 30 Then
                user = 0
                brgy2 = 30
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 31 Then
                user = 0
                brgy2 = 31
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 32 Then
                user = 0
                brgy2 = 32
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 33 Then
                user = 0
                brgy2 = 33
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 34 Then
                user = 0
                brgy2 = 34
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 35 Then
                user = 0
                brgy2 = 35
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 36 Then
                user = 0
                brgy2 = 36
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 37 Then
                user = 0
                brgy2 = 37
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 38 Then
                user = 0
                brgy2 = 38
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 0 And dt1.Rows(0)("brgy_id") = 39 Then
                user = 0
                brgy2 = 39
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 1 Then
                user = 1
                brgy2 = 1
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 2 Then
                user = 1
                brgy2 = 2
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 3 Then
                user = 1
                brgy2 = 3
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 4 Then
                user = 1
                brgy2 = 4
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 5 Then
                user = 1
                brgy2 = 5
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 6 Then
                user = 1
                brgy2 = 6
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 7 Then
                user = 1
                brgy2 = 7
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 8 Then
                user = 1
                brgy2 = 8
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 9 Then
                user = 1
                brgy2 = 9
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 10 Then
                user = 1
                brgy2 = 10
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 11 Then
                user = 1
                brgy2 = 11
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 12 Then
                user = 1
                brgy2 = 12
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 13 Then
                user = 1
                brgy2 = 13
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 14 Then
                user = 1
                brgy2 = 14
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 15 Then
                user = 1
                brgy2 = 15
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 16 Then
                user = 1
                brgy2 = 16
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 17 Then
                user = 1
                brgy2 = 17
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 18 Then
                user = 1
                brgy2 = 18
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 19 Then
                user = 1
                brgy2 = 19
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 20 Then
                user = 1
                brgy2 = 20
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 21 Then
                user = 1
                brgy2 = 21
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 22 Then
                user = 1
                brgy2 = 22
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 23 Then
                user = 1
                brgy2 = 23
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 24 Then
                user = 1
                brgy2 = 24
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 25 Then
                user = 1
                brgy2 = 25
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 26 Then
                user = 1
                brgy2 = 26
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 27 Then
                user = 1
                brgy2 = 27
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 28 Then
                user = 1
                brgy2 = 28
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 29 Then
                user = 1
                brgy2 = 29
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 30 Then
                user = 1
                brgy2 = 30
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 31 Then
                user = 1
                brgy2 = 31
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 32 Then
                user = 1
                brgy2 = 32
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 33 Then
                user = 1
                brgy2 = 33
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 34 Then
                user = 1
                brgy2 = 34
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 35 Then
                user = 1
                brgy2 = 35
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 36 Then
                user = 1
                brgy2 = 36
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 37 Then
                user = 1
                brgy2 = 37
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 38 Then
                user = 1
                brgy2 = 38
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 1 And dt1.Rows(0)("brgy_id") = 39 Then
                user = 1
                brgy2 = 39
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 1 Then
                user = 2
                brgy2 = 1
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 2 Then
                user = 2
                brgy2 = 2
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 3 Then
                user = 2
                brgy2 = 3
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 4 Then
                user = 2
                brgy2 = 4
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 5 Then
                user = 2
                brgy2 = 5
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 6 Then
                user = 2
                brgy2 = 6
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 7 Then
                user = 2
                brgy2 = 7
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 8 Then
                user = 2
                brgy2 = 8
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 9 Then
                user = 2
                brgy2 = 9
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 10 Then
                user = 2
                brgy2 = 10
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 11 Then
                user = 2
                brgy2 = 11
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 12 Then
                user = 2
                brgy2 = 12
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 13 Then
                user = 2
                brgy2 = 13
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 14 Then
                user = 2
                brgy2 = 14
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 15 Then
                user = 2
                brgy2 = 15
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 16 Then
                user = 2
                brgy2 = 16
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 17 Then
                user = 2
                brgy2 = 17
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 18 Then
                user = 2
                brgy2 = 18
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 19 Then
                user = 2
                brgy2 = 19
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 20 Then
                user = 2
                brgy2 = 20
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 21 Then
                user = 2
                brgy2 = 21
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 22 Then
                user = 2
                brgy2 = 22
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 23 Then
                user = 2
                brgy2 = 23
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 24 Then
                user = 2
                brgy2 = 24
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 25 Then
                user = 2
                brgy2 = 25
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 26 Then
                user = 2
                brgy2 = 26
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 27 Then
                user = 2
                brgy2 = 27
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 28 Then
                user = 2
                brgy2 = 28
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 29 Then
                user = 2
                brgy2 = 29
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 30 Then
                user = 2
                brgy2 = 30
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 31 Then
                user = 2
                brgy2 = 31
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 32 Then
                user = 2
                brgy2 = 32
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 33 Then
                user = 2
                brgy2 = 33
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 34 Then
                user = 2
                brgy2 = 34
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 35 Then
                user = 2
                brgy2 = 35
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 36 Then
                user = 2
                brgy2 = 36
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 37 Then
                user = 2
                brgy2 = 37
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 38 Then
                user = 2
                brgy2 = 38
            ElseIf dt1.Rows(0)("password") = StartForm.TextBox2.Text And dt1.Rows(0)("user_id") = 2 And dt1.Rows(0)("brgy_id") = 39 Then
                user = 2
                brgy2 = 39
            End If
            Try
                Dim datasource As String = "157.245.54.54" 'default
                Dim username As String = "thesis" 'default
                Dim password As String = "2022Thesis!"
                Dim database As String = "sk_tionery_db" 'change
                Dim port As String = "3306" 'default
                Dim connn As MySqlConnection = New MySqlConnection("datasource=" + datasource + ";database=" + database + ";uid=" + username + ";pwd=" + password + ";port=" + port)
                ' Dim db_obj = New Database
                ' db_obj.connect()
                connn.Open()
                Dim select_str As String = "INSERT INTO `annoucements`(`announcements`,`short_announcement`, `user_id`, `brgy_id`, `date`,`username`) VALUES ('" & fff & "','" & fff & "','" & user & "','" & brgy2 & "','" & isec & "','" & Label23.Text & "'); Select LAST_INSERT_ID();"
                Dim insert_cmd As MySqlCommand = New MySqlCommand(select_str, connn)
                Dim result_id2 As Integer = CInt(insert_cmd.ExecuteScalar())
                ' MessageBox.Show(result_id)



                ' MessageBox.Show(user)
                MessageBox.Show("Please Wait.. SMS is sending", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                ' GetAllAnnouncemnt(cn)
                '   Refresh()

                AnCreateChildPanel()
                AnnChildDesc(childPanel, fff)
                DateAnn(childPanel, isec) 'posted_time
                CreateAnnBarangay(childPanel, Label19.Text)
                CreateChildNick(childPanel, Label20.Text)
                CreateNameAnn(childPanel, Label23.Text)
                link2(childPanel, "See More", result_id2)


                Dim recipient, msg, apicode, pass, result, description As String
                msg = Label20.Text + " " + Label23.Text + " " + RichTextBox2.Text
                apicode = "ST-ARLEN474863_VHTQ3"
                pass = "m49(wzzrmn"
                result = 0

                Dim db3 = New Database
                Dim dt3 As New DataTable
                With db3
                    '"SELECT a.title, description, activity_date, posted_date ,b.brgy_name from activities as a Left outer join barangay_tbl as b on a.brgy_id = b.brgy_id"
                    .sqlStr = "SELECT `contact` from account_tbl where contact <>'' "
                    'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt3 = db3.sqlDt
                For i = 0 To dt3.Rows.Count - 1
                    recipient = dt3.Rows(i).Item(0).ToString
                    result = itexmo(recipient, msg, apicode, pass)
                Next


                RichTextBox2.Text = ""
                MessageBox.Show("Successfully Sent", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

                '   GetAllAnnouncemnt(cn)
                Refresh()
            Catch
                MessageBox.Show("error")
            End Try
        End If
    End Sub
    Public Sub link2(ByVal panelName As String, ByVal txtContent As String, ByVal seemorelinkk As String)
        Dim seemore2 As LinkLabel
        seemore2 = New LinkLabel

        With seemore2
            .Size = New Size(56, 15)
            .Location = New Point(698, 136)
            .Name = "lbllink" + seemorelinkk
            .Text = txtContent
            .Font = New Font("Segoe UI", 9, FontStyle.Underline)
            ' .ForeColor = Color.Black
            '.BackColor = Color.FromArgb(225, 240, 244)
        End With

        For Each obj As Control In flpAnnouncements.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(seemore2)
            End If
        Next
        AddHandler seemore2.LinkClicked, AddressOf Lnkk_Clicked
    End Sub

    Public Sub Lnkk_Clicked(ByVal sender As System.Object, ByVal e As LinkLabelLinkClickedEventArgs)
        '  Dim des As String
        Dim lblDes2 As New Label
        lblDes2 = New Label

        Dim lnk As LinkLabel = CType(sender, LinkLabel)
        seemorelinkk = lnk.Name.Substring(7)

        ' MessageBox.Show(seemorelinkk)
        Dim db2 = New Database
        '
        Dim dt2 As New DataTable
        With db2
            .sqlStr = "SELECT announcements from annoucements where num='" & seemorelinkk & "'" 'query string
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
            .close()
        End With
        dt2 = db2.sqlDt

        With lblDes2
            .Size = New Size(435, 218)
            .Location = New Point(14, 35)
            .BackColor = Color.White
            .Font = New Font("Segoe UI", 9.5)
        End With
        lblDes2.Text = dt2.Rows(0).Item(0).ToString
        '  MessageBox.Show(textdes)
        Form5.Controls.Add(lblDes2)
        Form5.Show()





    End Sub
    Public Sub AnCreateChildPanel()
        Dim aPanel As Panel
        aPanel = New Panel()

        With aPanel
            .BackColor = Color.FromArgb(223, 230, 244)
            .Size = New Size(770, 170)
            .Name = "pnl" + (Count + 1).ToString

        End With
        flpAnnouncements.Controls.Add(aPanel)
        childPanel = aPanel.Name
        Count += 1


    End Sub

    Public Sub AnnChildDesc(ByVal panelName As String, ByVal txtContent As String)
        Dim andesc As Label
        andesc = New Label

        With andesc
            .Size = New Size(691, 51)
            .Location = New Point(15, 84)
            .Name = "lblDesc" + (Count + 1).ToString
            .Text = txtContent + "..."
            .Font = New Font("Segoe UI", 9.5)


        End With

        For Each obj As Control In flpAnnouncements.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(andesc)
            End If
        Next
    End Sub
    Public Sub GetAllAnnouncemnt(ByVal con As MySqlConnection)
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                ' "SELECT a.title, description, activity_date, posted_date ,b.brgy_name from activities as a Left outer join barangay_tbl as b on a.brgy_id = b.brgy_id"
                .sqlStr = "Select a.short_announcement , Date, b.brgy_name, u.user_type, username,num from annoucements As a Left outer join barangay_tbl As b On a.brgy_id = b.brgy_id Left outer join user_tbl As u On a.user_id = u.user_id order by num asc;"
                'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt

            For i = 0 To dt.Rows.Count - 1
                AnCreateChildPanel()
                AnnChildDesc(childPanel, dt.Rows(i).Item(0).ToString)
                DateAnn(childPanel, dt.Rows(i).Item(1).ToString)
                CreateAnnBarangay(childPanel, dt.Rows(i).Item(2).ToString)
                CreateChildNick(childPanel, dt.Rows(i).Item(3).ToString)
                CreateNameAnn(childPanel, dt.Rows(i).Item(4).ToString)
                seemorelinkk = dt.Rows(i).Item(5).ToString
                link2(childPanel, "See More", seemorelinkk) 'posted_time'desc
                '      CreateChildDate(childPanel, dt.Rows(i).Item(2).ToString) 'date
                '     CreateChildBarangay(childPanel, dt.Rows(i).Item(3).ToString) 'brgy
                '    CreateChildUser(childPanel, dt.Rows(i).Item(4).ToString) 'user_id
                '    CreateChildLabeldate(childPanel, dt.Rows(i).Item(5).ToString) 'posted_time
                '  CreateChildlblDateofActivity()
            Next
        Catch ex As Exception

        End Try

    End Sub
    Public Sub DateAnn(ByVal panelName As String, ByVal txtContent As String)
        Dim dateann As Label
        dateann = New Label

        With dateann
            .Location = New Point(625, 15)
            .Name = "lbldate" + (Count + 1).ToString
            .Text = txtContent
            .Font = New Font("Segoe UI", 9)
            .Size = New Size(159, 20)

        End With

        For Each obj As Control In flpAnnouncements.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(dateann)
            End If
        Next
    End Sub
    Public Sub CreateAnnBarangay(ByVal panelName As String, ByVal txtContent As String)
        Dim annbrgy As Label
        annbrgy = New Label

        With annbrgy
            .Location = New Point(15, 31)
            .Name = "lblbrgy" + (Count + 1).ToString
            .Text = txtContent
            .Font = New Font("Segoe UI", 11, FontStyle.Bold)
            .Size = New Size(300, 21)
        End With

        For Each obj As Control In flpAnnouncements.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(annbrgy)
            End If
        Next
    End Sub
    Public Sub CreateChildNick(ByVal panelName As String, ByVal txtContent As String)
        Dim nickname As Label
        nickname = New Label

        With nickname
            .Size = New Size(300, 21)
            '  .BackColor = Color.White
            .Location = New Point(15, 10)
            .Name = "lbluser" + (Count + 1).ToString
            .Text = txtContent
            .Font = New Font("Segoe UI", 12, FontStyle.Bold)
        End With

        For Each obj As Control In flpAnnouncements.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(nickname)
            End If
        Next
    End Sub
    Public Sub CreateNameAnn(ByVal panelName As String, ByVal txtContent As String)
        Dim nameann As Label
        nameann = New Label

        With nameann
            .Size = New Size(200, 17)
            .Location = New Point(15, 54)
            .Name = "lblname" + (Count + 1).ToString
            .Text = txtContent
            .Font = New Font("Segoe UI", 9.5, FontStyle.Bold)
            '  .BackColor = Color.FromArgb(225, 240, 244)
        End With

        For Each obj As Control In flpAnnouncements.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(nameann)
            End If
        Next
    End Sub
    Private Sub TabPage3_Click(sender As Object, e As EventArgs) Handles TabPage3.Click

    End Sub

    Private Sub PanelMonthlyReport_Click(sender As Object, e As EventArgs) Handles PanelMonthlyReport.Click

    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        If ComboBox3.Text = "Name" Then
            Try
                Dim db = New Database
                Dim dt As New DataTable
                With db
                    .sqlStr = "SELECT repID, brgy_id,Name, time, file_name, status,approved_date from report_tbl where Name like '%" & TextBox2.Text.Trim & "%' Order by time DESC;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt = db.sqlDt
                DataGridView1.Rows.Clear()
                For i = 0 To dt.Rows.Count - 1
                    DataGridView1.Rows.Add()
                    DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                    DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                    DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                    DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                    DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                    DataGridView1.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                    DataGridView1.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString

                    If dt.Rows(i).Item(5).ToString = "0" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Pending"
                    ElseIf dt.Rows(i).Item(5).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Approved"
                    End If
                    If dt.Rows(i).Item(1).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "3" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 1"
                    ElseIf dt.Rows(i).Item(1).ToString = "4" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 2"
                    ElseIf dt.Rows(i).Item(1).ToString = "5" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 3"
                    ElseIf dt.Rows(i).Item(1).ToString = "6" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 4"
                    ElseIf dt.Rows(i).Item(1).ToString = "7" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 5"
                    ElseIf dt.Rows(i).Item(1).ToString = "8" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 6"
                    ElseIf dt.Rows(i).Item(1).ToString = "9" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 7"
                    ElseIf dt.Rows(i).Item(1).ToString = "10" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 8"
                    ElseIf dt.Rows(i).Item(1).ToString = "11" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 9"
                    ElseIf dt.Rows(i).Item(1).ToString = "12" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barraca"
                    ElseIf dt.Rows(i).Item(1).ToString = "13" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "14" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "15" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bongtolan"
                    ElseIf dt.Rows(i).Item(1).ToString = "16" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bulala"
                    ElseIf dt.Rows(i).Item(1).ToString = "17" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabalangegan"
                    ElseIf dt.Rows(i).Item(1).ToString = "18" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "19" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "20" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Camangaan"
                    ElseIf dt.Rows(i).Item(1).ToString = "21" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Capangpangan"
                    ElseIf dt.Rows(i).Item(1).ToString = "22" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Mindoro"
                    ElseIf dt.Rows(i).Item(1).ToString = "23" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Nagsangalan"
                    ElseIf dt.Rows(i).Item(1).ToString = "24" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "25" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Fatima"
                    ElseIf dt.Rows(i).Item(1).ToString = "26" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "27" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paoa"
                    ElseIf dt.Rows(i).Item(1).ToString = "28" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paratong"
                    ElseIf dt.Rows(i).Item(1).ToString = "29" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pong-ol"
                    ElseIf dt.Rows(i).Item(1).ToString = "30" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-bassit"
                    ElseIf dt.Rows(i).Item(1).ToString = "31" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-dackel"
                    ElseIf dt.Rows(i).Item(1).ToString = "32" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Raois"
                    ElseIf dt.Rows(i).Item(1).ToString = "33" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Rugsaunan"
                    ElseIf dt.Rows(i).Item(1).ToString = "34" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Salindeg"
                    ElseIf dt.Rows(i).Item(1).ToString = "35" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Jose"
                    ElseIf dt.Rows(i).Item(1).ToString = "36" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "37" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "38" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Pedro"
                    ElseIf dt.Rows(i).Item(1).ToString = "39" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Tamag"
                    End If
                Next
                'loadFormReports()
            Catch
                MessageBox.Show("error")
            End Try

        ElseIf ComboBox3.Text = "Barangay" Then

            Try
                Dim db = New Database
                Dim dt As New DataTable
                With db
                    .sqlStr = "SELECT repID, brgy_id,Name, time, file_name, status,approved_date from report_tbl where brgy_id IN (select brgy_id from barangay_tbl where brgy_name like '%" & TextBox2.Text.Trim & "%') ;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt = db.sqlDt
                DataGridView1.Rows.Clear()
                For i = 0 To dt.Rows.Count - 1
                    DataGridView1.Rows.Add()
                    DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                    DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                    DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                    DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                    DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                    DataGridView1.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                    DataGridView1.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString

                    If dt.Rows(i).Item(5).ToString = "0" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Pending"
                    ElseIf dt.Rows(i).Item(5).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Approved"
                    End If
                    If dt.Rows(i).Item(1).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "3" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 1"
                    ElseIf dt.Rows(i).Item(1).ToString = "4" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 2"
                    ElseIf dt.Rows(i).Item(1).ToString = "5" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 3"
                    ElseIf dt.Rows(i).Item(1).ToString = "6" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 4"
                    ElseIf dt.Rows(i).Item(1).ToString = "7" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 5"
                    ElseIf dt.Rows(i).Item(1).ToString = "8" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 6"
                    ElseIf dt.Rows(i).Item(1).ToString = "9" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 7"
                    ElseIf dt.Rows(i).Item(1).ToString = "10" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 8"
                    ElseIf dt.Rows(i).Item(1).ToString = "11" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 9"
                    ElseIf dt.Rows(i).Item(1).ToString = "12" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barraca"
                    ElseIf dt.Rows(i).Item(1).ToString = "13" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "14" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "15" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bongtolan"
                    ElseIf dt.Rows(i).Item(1).ToString = "16" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bulala"
                    ElseIf dt.Rows(i).Item(1).ToString = "17" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabalangegan"
                    ElseIf dt.Rows(i).Item(1).ToString = "18" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "19" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "20" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Camangaan"
                    ElseIf dt.Rows(i).Item(1).ToString = "21" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Capangpangan"
                    ElseIf dt.Rows(i).Item(1).ToString = "22" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Mindoro"
                    ElseIf dt.Rows(i).Item(1).ToString = "23" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Nagsangalan"
                    ElseIf dt.Rows(i).Item(1).ToString = "24" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "25" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Fatima"
                    ElseIf dt.Rows(i).Item(1).ToString = "26" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "27" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paoa"
                    ElseIf dt.Rows(i).Item(1).ToString = "28" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paratong"
                    ElseIf dt.Rows(i).Item(1).ToString = "29" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pong-ol"
                    ElseIf dt.Rows(i).Item(1).ToString = "30" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-bassit"
                    ElseIf dt.Rows(i).Item(1).ToString = "31" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-dackel"
                    ElseIf dt.Rows(i).Item(1).ToString = "32" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Raois"
                    ElseIf dt.Rows(i).Item(1).ToString = "33" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Rugsaunan"
                    ElseIf dt.Rows(i).Item(1).ToString = "34" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Salindeg"
                    ElseIf dt.Rows(i).Item(1).ToString = "35" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Jose"
                    ElseIf dt.Rows(i).Item(1).ToString = "36" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "37" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "38" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Pedro"
                    ElseIf dt.Rows(i).Item(1).ToString = "39" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Tamag"
                    End If
                Next
                'loadFormReports()
            Catch
                MessageBox.Show("error")
            End Try


        ElseIf ComboBox3.Text = "File" Then

            Try
                Dim db = New Database
                Dim dt As New DataTable
                With db
                    .sqlStr = "SELECT repID, brgy_id,Name, time, file_name, status,approved_date from report_tbl where  file_name like '%" & TextBox2.Text.Trim & "%' Order by time DESC ;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt = db.sqlDt
                DataGridView1.Rows.Clear()
                For i = 0 To dt.Rows.Count - 1
                    DataGridView1.Rows.Add()
                    DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                    DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                    DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                    DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                    DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                    DataGridView1.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                    DataGridView1.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString

                    If dt.Rows(i).Item(5).ToString = "0" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Pending"
                    ElseIf dt.Rows(i).Item(5).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Approved"
                    End If
                    If dt.Rows(i).Item(1).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "3" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 1"
                    ElseIf dt.Rows(i).Item(1).ToString = "4" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 2"
                    ElseIf dt.Rows(i).Item(1).ToString = "5" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 3"
                    ElseIf dt.Rows(i).Item(1).ToString = "6" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 4"
                    ElseIf dt.Rows(i).Item(1).ToString = "7" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 5"
                    ElseIf dt.Rows(i).Item(1).ToString = "8" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 6"
                    ElseIf dt.Rows(i).Item(1).ToString = "9" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 7"
                    ElseIf dt.Rows(i).Item(1).ToString = "10" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 8"
                    ElseIf dt.Rows(i).Item(1).ToString = "11" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 9"
                    ElseIf dt.Rows(i).Item(1).ToString = "12" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barraca"
                    ElseIf dt.Rows(i).Item(1).ToString = "13" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "14" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "15" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bongtolan"
                    ElseIf dt.Rows(i).Item(1).ToString = "16" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bulala"
                    ElseIf dt.Rows(i).Item(1).ToString = "17" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabalangegan"
                    ElseIf dt.Rows(i).Item(1).ToString = "18" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "19" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "20" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Camangaan"
                    ElseIf dt.Rows(i).Item(1).ToString = "21" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Capangpangan"
                    ElseIf dt.Rows(i).Item(1).ToString = "22" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Mindoro"
                    ElseIf dt.Rows(i).Item(1).ToString = "23" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Nagsangalan"
                    ElseIf dt.Rows(i).Item(1).ToString = "24" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "25" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Fatima"
                    ElseIf dt.Rows(i).Item(1).ToString = "26" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "27" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paoa"
                    ElseIf dt.Rows(i).Item(1).ToString = "28" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paratong"
                    ElseIf dt.Rows(i).Item(1).ToString = "29" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pong-ol"
                    ElseIf dt.Rows(i).Item(1).ToString = "30" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-bassit"
                    ElseIf dt.Rows(i).Item(1).ToString = "31" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-dackel"
                    ElseIf dt.Rows(i).Item(1).ToString = "32" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Raois"
                    ElseIf dt.Rows(i).Item(1).ToString = "33" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Rugsaunan"
                    ElseIf dt.Rows(i).Item(1).ToString = "34" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Salindeg"
                    ElseIf dt.Rows(i).Item(1).ToString = "35" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Jose"
                    ElseIf dt.Rows(i).Item(1).ToString = "36" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "37" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "38" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Pedro"
                    ElseIf dt.Rows(i).Item(1).ToString = "39" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Tamag"
                    End If
                Next
            Catch
                MessageBox.Show("error")
            End Try



        ElseIf ComboBox3.Text = "Status" Then

            Try
                Dim db = New Database
                Dim dt As New DataTable
                With db
                    .sqlStr = "SELECT repID, brgy_id,Name, time, file_name, status,approved_date from report_tbl where status IN (select status from status_tbl where status_name like '%" & TextBox2.Text.Trim & "%') ;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt = db.sqlDt
                DataGridView1.Rows.Clear()
                For i = 0 To dt.Rows.Count - 1
                    DataGridView1.Rows.Add()
                    DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                    DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                    DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                    DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                    DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                    DataGridView1.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                    DataGridView1.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString

                    If dt.Rows(i).Item(5).ToString = "0" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Pending"
                    ElseIf dt.Rows(i).Item(5).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Approved"
                    End If
                    If dt.Rows(i).Item(1).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "3" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 1"
                    ElseIf dt.Rows(i).Item(1).ToString = "4" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 2"
                    ElseIf dt.Rows(i).Item(1).ToString = "5" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 3"
                    ElseIf dt.Rows(i).Item(1).ToString = "6" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 4"
                    ElseIf dt.Rows(i).Item(1).ToString = "7" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 5"
                    ElseIf dt.Rows(i).Item(1).ToString = "8" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 6"
                    ElseIf dt.Rows(i).Item(1).ToString = "9" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 7"
                    ElseIf dt.Rows(i).Item(1).ToString = "10" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 8"
                    ElseIf dt.Rows(i).Item(1).ToString = "11" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 9"
                    ElseIf dt.Rows(i).Item(1).ToString = "12" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barraca"
                    ElseIf dt.Rows(i).Item(1).ToString = "13" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "14" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "15" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bongtolan"
                    ElseIf dt.Rows(i).Item(1).ToString = "16" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bulala"
                    ElseIf dt.Rows(i).Item(1).ToString = "17" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabalangegan"
                    ElseIf dt.Rows(i).Item(1).ToString = "18" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "19" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "20" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Camangaan"
                    ElseIf dt.Rows(i).Item(1).ToString = "21" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Capangpangan"
                    ElseIf dt.Rows(i).Item(1).ToString = "22" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Mindoro"
                    ElseIf dt.Rows(i).Item(1).ToString = "23" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Nagsangalan"
                    ElseIf dt.Rows(i).Item(1).ToString = "24" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "25" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Fatima"
                    ElseIf dt.Rows(i).Item(1).ToString = "26" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "27" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paoa"
                    ElseIf dt.Rows(i).Item(1).ToString = "28" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paratong"
                    ElseIf dt.Rows(i).Item(1).ToString = "29" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pong-ol"
                    ElseIf dt.Rows(i).Item(1).ToString = "30" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-bassit"
                    ElseIf dt.Rows(i).Item(1).ToString = "31" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-dackel"
                    ElseIf dt.Rows(i).Item(1).ToString = "32" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Raois"
                    ElseIf dt.Rows(i).Item(1).ToString = "33" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Rugsaunan"
                    ElseIf dt.Rows(i).Item(1).ToString = "34" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Salindeg"
                    ElseIf dt.Rows(i).Item(1).ToString = "35" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Jose"
                    ElseIf dt.Rows(i).Item(1).ToString = "36" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "37" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "38" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Pedro"
                    ElseIf dt.Rows(i).Item(1).ToString = "39" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Tamag"
                    End If
                Next
                'loadFormReports()
            Catch
                MessageBox.Show("error")
            End Try


        ElseIf ComboBox3.Text = "File" Then

            Try
                Dim db = New Database
                Dim dt As New DataTable
                With db
                    .sqlStr = "SELECT repID, brgy_id,Name, time, file_name, status,approved_date from report_tbl where  file_name like '%" & TextBox2.Text.Trim & "%' Order by time DESC ;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt = db.sqlDt
                DataGridView1.Rows.Clear()
                For i = 0 To dt.Rows.Count - 1
                    DataGridView1.Rows.Add()
                    DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                    DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                    DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                    DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                    DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                    DataGridView1.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                    DataGridView1.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString

                    If dt.Rows(i).Item(5).ToString = "0" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Pending"
                    ElseIf dt.Rows(i).Item(5).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Approved"
                    End If
                    If dt.Rows(i).Item(1).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "3" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 1"
                    ElseIf dt.Rows(i).Item(1).ToString = "4" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 2"
                    ElseIf dt.Rows(i).Item(1).ToString = "5" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 3"
                    ElseIf dt.Rows(i).Item(1).ToString = "6" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 4"
                    ElseIf dt.Rows(i).Item(1).ToString = "7" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 5"
                    ElseIf dt.Rows(i).Item(1).ToString = "8" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 6"
                    ElseIf dt.Rows(i).Item(1).ToString = "9" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 7"
                    ElseIf dt.Rows(i).Item(1).ToString = "10" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 8"
                    ElseIf dt.Rows(i).Item(1).ToString = "11" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 9"
                    ElseIf dt.Rows(i).Item(1).ToString = "12" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barraca"
                    ElseIf dt.Rows(i).Item(1).ToString = "13" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "14" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "15" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bongtolan"
                    ElseIf dt.Rows(i).Item(1).ToString = "16" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bulala"
                    ElseIf dt.Rows(i).Item(1).ToString = "17" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabalangegan"
                    ElseIf dt.Rows(i).Item(1).ToString = "18" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "19" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "20" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Camangaan"
                    ElseIf dt.Rows(i).Item(1).ToString = "21" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Capangpangan"
                    ElseIf dt.Rows(i).Item(1).ToString = "22" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Mindoro"
                    ElseIf dt.Rows(i).Item(1).ToString = "23" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Nagsangalan"
                    ElseIf dt.Rows(i).Item(1).ToString = "24" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "25" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Fatima"
                    ElseIf dt.Rows(i).Item(1).ToString = "26" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "27" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paoa"
                    ElseIf dt.Rows(i).Item(1).ToString = "28" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paratong"
                    ElseIf dt.Rows(i).Item(1).ToString = "29" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pong-ol"
                    ElseIf dt.Rows(i).Item(1).ToString = "30" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-bassit"
                    ElseIf dt.Rows(i).Item(1).ToString = "31" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-dackel"
                    ElseIf dt.Rows(i).Item(1).ToString = "32" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Raois"
                    ElseIf dt.Rows(i).Item(1).ToString = "33" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Rugsaunan"
                    ElseIf dt.Rows(i).Item(1).ToString = "34" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Salindeg"
                    ElseIf dt.Rows(i).Item(1).ToString = "35" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Jose"
                    ElseIf dt.Rows(i).Item(1).ToString = "36" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "37" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "38" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Pedro"
                    ElseIf dt.Rows(i).Item(1).ToString = "39" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Tamag"
                    End If
                Next
            Catch
                MessageBox.Show("error")
            End Try


        ElseIf ComboBox3.Text = "Date Upload" Then

            Try
                Dim db = New Database
                Dim dt As New DataTable
                With db
                    .sqlStr = "SELECT repID, brgy_id,Name, time, file_name, status,approved_date from report_tbl where time like '%" & TextBox2.Text.Trim & "%' ;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt = db.sqlDt
                DataGridView1.Rows.Clear()
                For i = 0 To dt.Rows.Count - 1
                    DataGridView1.Rows.Add()
                    DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                    DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                    DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                    DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                    DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                    DataGridView1.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                    DataGridView1.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString

                    If dt.Rows(i).Item(5).ToString = "0" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Pending"
                    ElseIf dt.Rows(i).Item(5).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Approved"
                    End If
                    If dt.Rows(i).Item(1).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "3" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 1"
                    ElseIf dt.Rows(i).Item(1).ToString = "4" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 2"
                    ElseIf dt.Rows(i).Item(1).ToString = "5" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 3"
                    ElseIf dt.Rows(i).Item(1).ToString = "6" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 4"
                    ElseIf dt.Rows(i).Item(1).ToString = "7" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 5"
                    ElseIf dt.Rows(i).Item(1).ToString = "8" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 6"
                    ElseIf dt.Rows(i).Item(1).ToString = "9" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 7"
                    ElseIf dt.Rows(i).Item(1).ToString = "10" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 8"
                    ElseIf dt.Rows(i).Item(1).ToString = "11" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 9"
                    ElseIf dt.Rows(i).Item(1).ToString = "12" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barraca"
                    ElseIf dt.Rows(i).Item(1).ToString = "13" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "14" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "15" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bongtolan"
                    ElseIf dt.Rows(i).Item(1).ToString = "16" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bulala"
                    ElseIf dt.Rows(i).Item(1).ToString = "17" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabalangegan"
                    ElseIf dt.Rows(i).Item(1).ToString = "18" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "19" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "20" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Camangaan"
                    ElseIf dt.Rows(i).Item(1).ToString = "21" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Capangpangan"
                    ElseIf dt.Rows(i).Item(1).ToString = "22" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Mindoro"
                    ElseIf dt.Rows(i).Item(1).ToString = "23" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Nagsangalan"
                    ElseIf dt.Rows(i).Item(1).ToString = "24" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "25" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Fatima"
                    ElseIf dt.Rows(i).Item(1).ToString = "26" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "27" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paoa"
                    ElseIf dt.Rows(i).Item(1).ToString = "28" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paratong"
                    ElseIf dt.Rows(i).Item(1).ToString = "29" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pong-ol"
                    ElseIf dt.Rows(i).Item(1).ToString = "30" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-bassit"
                    ElseIf dt.Rows(i).Item(1).ToString = "31" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-dackel"
                    ElseIf dt.Rows(i).Item(1).ToString = "32" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Raois"
                    ElseIf dt.Rows(i).Item(1).ToString = "33" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Rugsaunan"
                    ElseIf dt.Rows(i).Item(1).ToString = "34" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Salindeg"
                    ElseIf dt.Rows(i).Item(1).ToString = "35" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Jose"
                    ElseIf dt.Rows(i).Item(1).ToString = "36" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "37" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "38" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Pedro"
                    ElseIf dt.Rows(i).Item(1).ToString = "39" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Tamag"
                    End If
                Next
                'loadFormReports()
            Catch
                MessageBox.Show("error")
            End Try

            'loadFormReports()

        ElseIf ComboBox3.Text = "Approved Date" Then

            Try
                Dim db = New Database
                Dim dt As New DataTable
                With db
                    .sqlStr = "SELECT repID, brgy_id,Name, time, file_name, status,approved_date from report_tbl where approved_date like '%" & TextBox2.Text.Trim & "%' ;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt = db.sqlDt
                DataGridView1.Rows.Clear()
                For i = 0 To dt.Rows.Count - 1
                    DataGridView1.Rows.Add()
                    DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                    DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(2).ToString
                    DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(1).ToString
                    DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
                    DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(5).ToString
                    DataGridView1.Rows(i).Cells(5).Value = dt.Rows(i).Item(3).ToString
                    DataGridView1.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString

                    If dt.Rows(i).Item(5).ToString = "0" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Pending"
                    ElseIf dt.Rows(i).Item(5).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(4).Value = "Approved"
                    End If
                    If dt.Rows(i).Item(1).ToString = "1" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "2" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Ayusan Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "3" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 1"
                    ElseIf dt.Rows(i).Item(1).ToString = "4" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 2"
                    ElseIf dt.Rows(i).Item(1).ToString = "5" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 3"
                    ElseIf dt.Rows(i).Item(1).ToString = "6" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 4"
                    ElseIf dt.Rows(i).Item(1).ToString = "7" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 5"
                    ElseIf dt.Rows(i).Item(1).ToString = "8" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 6"
                    ElseIf dt.Rows(i).Item(1).ToString = "9" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 7"
                    ElseIf dt.Rows(i).Item(1).ToString = "10" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 8"
                    ElseIf dt.Rows(i).Item(1).ToString = "11" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barangay 9"
                    ElseIf dt.Rows(i).Item(1).ToString = "12" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Barraca"
                    ElseIf dt.Rows(i).Item(1).ToString = "13" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "14" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Beddeng Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "15" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bongtolan"
                    ElseIf dt.Rows(i).Item(1).ToString = "16" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Bulala"
                    ElseIf dt.Rows(i).Item(1).ToString = "17" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabalangegan"
                    ElseIf dt.Rows(i).Item(1).ToString = "18" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "19" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Cabaroan Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "20" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Camangaan"
                    ElseIf dt.Rows(i).Item(1).ToString = "21" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Capangpangan"
                    ElseIf dt.Rows(i).Item(1).ToString = "22" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Mindoro"
                    ElseIf dt.Rows(i).Item(1).ToString = "23" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Nagsangalan"
                    ElseIf dt.Rows(i).Item(1).ToString = "24" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Daya"
                    ElseIf dt.Rows(i).Item(1).ToString = "25" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Fatima"
                    ElseIf dt.Rows(i).Item(1).ToString = "26" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pantay Laud"
                    ElseIf dt.Rows(i).Item(1).ToString = "27" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paoa"
                    ElseIf dt.Rows(i).Item(1).ToString = "28" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Paratong"
                    ElseIf dt.Rows(i).Item(1).ToString = "29" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Pong-ol"
                    ElseIf dt.Rows(i).Item(1).ToString = "30" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-bassit"
                    ElseIf dt.Rows(i).Item(1).ToString = "31" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Purok-a-dackel"
                    ElseIf dt.Rows(i).Item(1).ToString = "32" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Raois"
                    ElseIf dt.Rows(i).Item(1).ToString = "33" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Rugsaunan"
                    ElseIf dt.Rows(i).Item(1).ToString = "34" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Salindeg"
                    ElseIf dt.Rows(i).Item(1).ToString = "35" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Jose"
                    ElseIf dt.Rows(i).Item(1).ToString = "36" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Norte"
                    ElseIf dt.Rows(i).Item(1).ToString = "37" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Julian Sur"
                    ElseIf dt.Rows(i).Item(1).ToString = "38" Then
                        DataGridView1.Rows(i).Cells(2).Value = "San Pedro"
                    ElseIf dt.Rows(i).Item(1).ToString = "39" Then
                        DataGridView1.Rows(i).Cells(2).Value = "Tamag"
                    End If
                Next
                'loadFormReports()
            Catch
                MessageBox.Show("error")
            End Try



        Else
            MessageBox.Show("No Data Found", "Error")
            'loadFormReports()
        End If
    End Sub

    Private Sub panelReportArchive_Paint(sender As Object, e As PaintEventArgs) Handles panelReportArchive.Paint

    End Sub

    Private Sub Label53_Click(sender As Object, e As EventArgs) Handles Label53.Click

    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If Asc(e.KeyChar) < 4 Or Asc(e.KeyChar) > 57 Then
            e.Handled = True
            MessageBox.Show("Please type numbers", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        End If
    End Sub

    Private Sub DataGridView3_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView3.CellContentClick
        TextBoxID.Text = DataGridView3.CurrentRow.Cells(0).Value
        TextBoxLname.Text = DataGridView3.CurrentRow.Cells(1).Value
        TextBoxFname.Text = DataGridView3.CurrentRow.Cells(2).Value
        TextBoxMname.Text = DataGridView3.CurrentRow.Cells(3).Value
        TextBoxUsername.Text = DataGridView3.CurrentRow.Cells(5).Value
        TextBoxPassword.Text = DataGridView3.CurrentRow.Cells(6).Value
        ComboBoxUsertype.Text = DataGridView3.CurrentRow.Cells(7).Value
        ComboBoxBarangay.Text = DataGridView3.CurrentRow.Cells(8).Value
        TextBox3.Text = DataGridView3.CurrentRow.Cells(4).Value
        TextBoxID.Enabled = False
        TextBoxFname.Enabled = False
        TextBoxLname.Enabled = False
        TextBoxMname.Enabled = False
        TextBoxUsername.Enabled = False
        TextBoxPassword.Enabled = False
        ComboBoxUsertype.Enabled = False
        ComboBoxBarangay.Enabled = False
        TextBox3.Enabled = False
    End Sub

    Private Sub DataGridView3_Click(sender As Object, e As EventArgs) Handles DataGridView3.Click
        TextBoxID.Text = DataGridView3.CurrentRow.Cells(0).Value
        TextBoxLname.Text = DataGridView3.CurrentRow.Cells(1).Value
        TextBoxFname.Text = DataGridView3.CurrentRow.Cells(2).Value
        TextBoxMname.Text = DataGridView3.CurrentRow.Cells(3).Value
        TextBoxUsername.Text = DataGridView3.CurrentRow.Cells(5).Value
        TextBoxPassword.Text = DataGridView3.CurrentRow.Cells(6).Value
        ComboBoxUsertype.Text = DataGridView3.CurrentRow.Cells(7).Value
        ComboBoxBarangay.Text = DataGridView3.CurrentRow.Cells(8).Value
        TextBox3.Text = DataGridView3.CurrentRow.Cells(4).Value
        TextBoxID.Enabled = False
        TextBoxFname.Enabled = False
        TextBoxLname.Enabled = False
        TextBoxMname.Enabled = False
        TextBoxUsername.Enabled = False
        TextBoxPassword.Enabled = False
        ComboBoxUsertype.Enabled = False
        ComboBoxBarangay.Enabled = False
        TextBox3.Enabled = False
    End Sub

    Sub QuarDate()
        Dim type As String
        Dim total As String
        Dim datetime As DateTime = DateTime.Now.ToShortDateString
        Dim currQuarter As Integer = (datetime.Month - 1) \ 3 + 1
        Dim dtFirstDay As Date = New DateTime(Date.Today.Year, 3 * currQuarter - 2, 1)
        Dim dtLastDay As Date = New DateTime(dtFirstDay.Year, dtFirstDay.Month + 2, 1).AddMonths(1).AddDays(-1)


        Dim Category1, Category2, Category3, Category4, Category5, Category6 As String
        Category1 = "Gender"
        Category2 = "Civil Status"
        Category3 = "Youth Age"
        Category4 = "Youth Classification"
        Category5 = "Educational Attainment"
        Category6 = "Work Status"

        If dtLastDay = datetime Then
            Dim db6 = New Database
            Dim dt6 As New DataTable
            With db6
                '  "Select gender,count(id) as genTotal from information_tbl group by gender" 'query 
                .sqlStr = "Select category, type, total, date from quarterly_stat where date = '" & datetime & "'" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt6 = db6.sqlDt


            If dt6.Rows.Count > 0 Then
                Exit Sub
            Else
                Dim db = New Database
                Dim dt As New DataTable
                With db
                    '  "Select gender,count(id) as genTotal from information_tbl group by gender" 'query 
                    .sqlStr = "insert into quarterly_stat (category, type,quarter,date,total ) Select '" & Category1 & "', gender,'" & currQuarter & "','" & datetime & "',count(*) from information_tbl group by gender;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt = db.sqlDt

                '---
                Dim db1 = New Database
                Dim dt1 As New DataTable
                With db1
                    ' "Select gender,count(id) as genTotal from information_tbl group by gender" 'query 
                    .sqlStr = "insert into quarterly_stat (category, type,quarter,date,total ) Select '" & Category2 & "', civil_status,'" & currQuarter & "','" & datetime & "',count(*) from information_tbl group by civil_status;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt1 = db1.sqlDt
                Dim db2 = New Database
                Dim dt2 As New DataTable
                With db2
                    ' "Select gender,count(id) as genTotal from information_tbl group by gender" 'query 
                    .sqlStr = "insert into quarterly_stat (category, type,quarter,date,total ) Select '" & Category3 & "',youth_age,'" & currQuarter & "','" & datetime & "',count(*) from information_tbl group by youth_age;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt2 = db2.sqlDt

                Dim db3 = New Database
                Dim dt3 As New DataTable
                With db3
                    ' "Select gender,count(id) as genTotal from information_tbl group by gender" 'query 
                    .sqlStr = "insert into quarterly_stat (category, type,quarter,date,total ) Select '" & Category4 & "', youth_classification,'" & currQuarter & "','" & datetime & "',count(*) from information_tbl group by youth_classification;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt2 = db2.sqlDt

                Dim db4 = New Database
                Dim dt4 As New DataTable
                With db4
                    ' "Select gender,count(id) as genTotal from information_tbl group by gender" 'query 
                    .sqlStr = "insert into quarterly_stat (category, type,quarter,date,total ) Select '" & Category5 & "', educ_tbl.educational_level,'" & currQuarter & "','" & datetime & "',count(*) as educTotal FROM information_tbl INNER JOIN educ_tbl on information_tbl.educ_id= educ_tbl.educ_id GROUP BY educational_level;" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt4 = db4.sqlDt

                Dim db5 = New Database
                Dim dt5 As New DataTable
                With db5
                    ' "Select gender,count(id) as genTotal from information_tbl group by gender" 'query 
                    .sqlStr = "insert into quarterly_stat (category, type,quarter,date,total ) Select '" & Category6 & "', work_status,'" & currQuarter & "','" & datetime & "',count(id) as workTotal from information_tbl group by work_status" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                    .close()
                End With
                dt5 = db5.sqlDt
            End If
        End If
    End Sub


    Sub total()
        Dim db = New Database
        Dim dt As New DataTable
        With db
            .sqlStr = "select count(*) from information_tbl;"
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
            .close()
        End With
        dt = db.sqlDt
        Label9.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label24.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label25.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label27.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label30.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label31.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label96.Text = "Total: " + dt.Rows(0).Item(0).ToString
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Form3.Show()
        stat_archive()
    End Sub

    Sub stat_archive()
        Dim db = New Database
        Dim dt As New DataTable
        With db
            .sqlStr = "SELECT a.category, `type`, b.`quarter_name`, `total`, `date` FROM `quarterly_stat` as a left OUTer JOIN quarter as b on a.quarter = b.quarter_id; " 'query string
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
            .close()
        End With
        dt = db.sqlDt
        Form3.DataGridView1.Rows.Clear()
        For i = 0 To dt.Rows.Count - 1
            Form3.DataGridView1.Rows.Add()
            Form3.DataGridView1.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
            Form3.DataGridView1.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
            Form3.DataGridView1.Rows(i).Cells(2).Value = dt.Rows(i).Item(3).ToString
            Form3.DataGridView1.Rows(i).Cells(3).Value = dt.Rows(i).Item(4).ToString
            Form3.DataGridView1.Rows(i).Cells(4).Value = dt.Rows(i).Item(2).ToString
        Next
    End Sub

    Private Sub Button12_Click_2(sender As Object, e As EventArgs) Handles Button12.Click
        PanelSMS.Visible = True
        loadarchiveArtivity()
        Label98.Text = "ACTIVITY ARCHIVE"
        RichTextBox3.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        RichTextBox3.Enabled = False
        TextBox5.Enabled = False
        TextBox6.Enabled = False
        TextBox7.Enabled = False
        TextBox8.Enabled = False
        panelbarangay.Visible = False
        DataGridView4.Visible = True
        DataGridView5.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelMonthlyReport.Visible = False
        PanelArchive2.Visible = False
        panelReportArchive.Visible = False
    End Sub

    Sub countActivities()

        Dim db = New Database
        Dim dt As New DataTable
        With db
            .sqlStr = " select count(*) from activities; " 'query string
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
            .close()
        End With
        dt = db.sqlDt
        'MessageBox.Show(dt.Rows(0).Item(0).ToString)
        If dt.Rows(0).Item(0) = 20 Then
            Dim db1 = New Database
            Dim dt1 As New DataTable
            With db1
                .sqlStr = " INSERT INTO `activity_archive`(`id`, `arch_title`, `arch_desc`, `arch_activity_date`, `arch_brgy_id`, `arch_user_id`, `arch_posted_time`, `arch_username`) SELECT `activity_id`, `title`, `description`,  `activity_date`, `brgy_id`, `user_id`, `posted_time`, `username` FROM `activities`  " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt1 = db1.sqlDt

            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db1
                .sqlStr = " Delete  From activities" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            '  MessageBox.Show("success!")
        Else
            '   MessageBox.Show(dt.Rows(0).Item(0))
        End If
    End Sub


    Sub countAnnouncements()

        Dim db = New Database
        Dim dt As New DataTable
        With db
            .sqlStr = " select count(*) from annoucements " 'query string
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
            .close()
        End With
        dt = db.sqlDt
        'MessageBox.Show(dt.Rows(0).Item(0).ToString)
        If dt.Rows(0).Item(0) = 20 Then
            Dim db1 = New Database
            Dim dt1 As New DataTable
            With db1
                .sqlStr = " INSERT INTO `announcements_archive`(`archive_num`, `arch_announcements`, `user_id`, `brgy_id`, `arch_date`, `arch_username`)  SELECT `num`, `announcements`, `user_id`, `brgy_id`, `date`, `username` FROM `annoucements` " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt1 = db1.sqlDt

            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = " Delete  From annoucements" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            '  MessageBox.Show("success!")
        Else
            '   MessageBox.Show(dt.Rows(0).Item(0))
        End If
    End Sub
    Sub loadarchiveArtivity()
        Dim db2 = New Database
        Dim dt2 As New DataTable
        With db2
            .sqlStr = "SELECT a.`arch_title`, `arch_desc`, `arch_activity_date`, b.`brgy_name`, u.`user_type`, `arch_posted_time`, `arch_username` FROM `activity_archive` as a LEFT outer join barangay_tbl as b on a.`arch_brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`arch_user_id` = u.user_id; " 'query string
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
            .close()
        End With
        dt2 = db2.sqlDt
        DataGridView4.Rows.Clear()
        For i = 0 To dt2.Rows.Count - 1
            DataGridView4.Rows.Add()
            DataGridView4.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
            DataGridView4.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
            DataGridView4.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
            DataGridView4.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
            DataGridView4.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString
            DataGridView4.Rows(i).Cells(5).Value = dt2.Rows(i).Item(5).ToString
            DataGridView4.Rows(i).Cells(6).Value = dt2.Rows(i).Item(6).ToString
        Next
    End Sub

    Sub loadAnnouncements()
        Dim db2 = New Database
        Dim dt2 As New DataTable
        With db2
            .sqlStr = "SELECT a.arch_announcements,u.`user_type`, b.`brgy_name`, arch_date, arch_username FROM announcements_archive as a LEFT outer join barangay_tbl as b on a.`brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`user_id` = u.user_id;; " 'query string
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
            .close()
        End With
        dt2 = db2.sqlDt
        DataGridView5.Rows.Clear()
        For i = 0 To dt2.Rows.Count - 1
            DataGridView5.Rows.Add()
            DataGridView5.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
            DataGridView5.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
            DataGridView5.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
            DataGridView5.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
            DataGridView5.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString

        Next
    End Sub

    Private Sub Button14_Click_1(sender As Object, e As EventArgs) Handles Button14.Click
        PanelSMS.Visible = True
        loadAnnouncements()
        Label98.Text = "ANNOUNCEMENT ARCHIVE"
        RichTextBox3.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        RichTextBox3.Enabled = False
        TextBox5.Enabled = False
        TextBox6.Enabled = False
        TextBox7.Enabled = False
        TextBox8.Enabled = False
        panelbarangay.Visible = False
        DataGridView5.Visible = True
        DataGridView4.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = False
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelMonthlyReport.Visible = False
        PanelArchive2.Visible = False
        panelReportArchive.Visible = False
    End Sub

    Private Sub DataGridView5_CellEnter(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView5.CellEnter
        RichTextBox3.Text = DataGridView5.CurrentRow.Cells(0).Value
        TextBox5.Text = DataGridView5.CurrentRow.Cells(3).Value
        TextBox6.Text = DataGridView5.CurrentRow.Cells(2).Value
        TextBox7.Text = DataGridView5.CurrentRow.Cells(4).Value
        TextBox8.Text = DataGridView5.CurrentRow.Cells(1).Value
    End Sub

    Private Sub DataGridView5_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView5.CellContentClick
        RichTextBox3.Text = DataGridView5.CurrentRow.Cells(0).Value
        TextBox5.Text = DataGridView5.CurrentRow.Cells(3).Value
        TextBox6.Text = DataGridView5.CurrentRow.Cells(2).Value
        TextBox7.Text = DataGridView5.CurrentRow.Cells(4).Value
        TextBox8.Text = DataGridView5.CurrentRow.Cells(1).Value
    End Sub

    Private Sub DataGridView4_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView4.CellContentClick
        RichTextBox3.Text = DataGridView4.CurrentRow.Cells(1).Value
        TextBox5.Text = DataGridView4.CurrentRow.Cells(5).Value
        TextBox6.Text = DataGridView4.CurrentRow.Cells(3).Value
        TextBox7.Text = DataGridView4.CurrentRow.Cells(6).Value
        TextBox8.Text = DataGridView4.CurrentRow.Cells(4).Value
    End Sub

    Private Sub DataGridView5_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView5.CellClick
        RichTextBox3.Text = DataGridView5.CurrentRow.Cells(0).Value
        TextBox5.Text = DataGridView5.CurrentRow.Cells(3).Value
        TextBox6.Text = DataGridView5.CurrentRow.Cells(2).Value
        TextBox7.Text = DataGridView5.CurrentRow.Cells(4).Value
        TextBox8.Text = DataGridView5.CurrentRow.Cells(1).Value
    End Sub

    Private Sub DataGridView4_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView4.CellClick
        RichTextBox3.Text = DataGridView4.CurrentRow.Cells(1).Value
        TextBox5.Text = DataGridView4.CurrentRow.Cells(5).Value
        TextBox6.Text = DataGridView4.CurrentRow.Cells(3).Value
        TextBox7.Text = DataGridView4.CurrentRow.Cells(6).Value
        TextBox8.Text = DataGridView4.CurrentRow.Cells(4).Value
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        panelbarangay.Visible = False
        PanelMonthlyReport.Visible = False
        panelOfficials.Visible = False
        panelHistory.Visible = False
        PanelArchive.Visible = True
        PanelUserManagement.Visible = False
        panelAboutUs.Visible = False
        PanelActivities.Visible = False
        PanelArchive2.Visible = False
        PanelStat.Visible = False
        panelReportArchive.Visible = False
        PanelSMS.Visible = False
    End Sub

    Private Sub TextBox10_TextChanged(sender As Object, e As EventArgs) Handles TextBox10.TextChanged
        If Label98.Text = "ACTIVITY ARCHIVE" Then
            searcharctivity()
        ElseIf Label98.Text = "ANNOUNCEMENT ARCHIVE" Then
            searchAnnouncement()
        End If
    End Sub
    'Activity/Announcements
    'Date
    'Barangay
    'Name
    'User Type
    Sub searchAnnouncement()
        If ComboBox4.Text = "Activity/Announcements" Then
            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = "SELECT a.arch_announcements,u.`user_type`, b.`brgy_name`, arch_date, arch_username FROM announcements_archive as a LEFT outer join barangay_tbl as b on a.`brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`user_id` = u.user_id where arch_announcements like '%" & TextBox10.Text.Trim & "%'  " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            DataGridView5.Rows.Clear()
            For i = 0 To dt2.Rows.Count - 1
                DataGridView5.Rows.Add()
                DataGridView5.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
                DataGridView5.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
                DataGridView5.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
                DataGridView5.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
                DataGridView5.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString

            Next
        ElseIf ComboBox4.Text = "Date" Then
            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = "SELECT a.arch_announcements,u.`user_type`, b.`brgy_name`, arch_date, arch_username FROM announcements_archive as a LEFT outer join barangay_tbl as b on a.`brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`user_id` = u.user_id where arch_date like '%" & TextBox10.Text.Trim & "%'  " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            DataGridView5.Rows.Clear()
            For i = 0 To dt2.Rows.Count - 1
                DataGridView5.Rows.Add()
                DataGridView5.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
                DataGridView5.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
                DataGridView5.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
                DataGridView5.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
                DataGridView5.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString

            Next
        ElseIf ComboBox4.Text = "Barangay" Then
            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = "SELECT a.arch_announcements,u.`user_type`, b.`brgy_name`, arch_date, arch_username FROM announcements_archive as a LEFT outer join barangay_tbl as b on a.`brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`user_id` = u.user_id where b.`brgy_name` like '%" & TextBox10.Text.Trim & "%'  " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            DataGridView5.Rows.Clear()
            For i = 0 To dt2.Rows.Count - 1
                DataGridView5.Rows.Add()
                DataGridView5.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
                DataGridView5.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
                DataGridView5.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
                DataGridView5.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
                DataGridView5.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString

            Next
        ElseIf ComboBox4.Text = "Name" Then
            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = "SELECT a.arch_announcements,u.`user_type`, b.`brgy_name`, arch_date, arch_username FROM announcements_archive as a LEFT outer join barangay_tbl as b on a.`brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`user_id` = u.user_id where arch_username like '%" & TextBox10.Text.Trim & "%'  " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            DataGridView5.Rows.Clear()
            For i = 0 To dt2.Rows.Count - 1
                DataGridView5.Rows.Add()
                DataGridView5.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
                DataGridView5.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
                DataGridView5.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
                DataGridView5.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
                DataGridView5.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString

            Next
        ElseIf ComboBox4.Text = "User Type" Then
            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = "SELECT a.arch_announcements,u.`user_type`, b.`brgy_name`, arch_date, arch_username FROM announcements_archive as a LEFT outer join barangay_tbl as b on a.`brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`user_id` = u.user_id where u.`user_type` like '%" & TextBox10.Text.Trim & "%'  " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            DataGridView5.Rows.Clear()
            For i = 0 To dt2.Rows.Count - 1
                DataGridView5.Rows.Add()
                DataGridView5.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
                DataGridView5.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
                DataGridView5.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
                DataGridView5.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
                DataGridView5.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString

            Next
        End If
    End Sub




    Sub searcharctivity()
        If ComboBox4.Text = "Activity/Announcements" Then
            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = "SELECT a.`arch_title`, `arch_desc`, `arch_activity_date`, b.`brgy_name`, u.`user_type`, `arch_posted_time`, `arch_username` FROM `activity_archive` as a LEFT outer join barangay_tbl as b on a.`arch_brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`arch_user_id` = u.user_id where `arch_desc` like '%" & TextBox10.Text.Trim & "%' " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            DataGridView4.Rows.Clear()
            For i = 0 To dt2.Rows.Count - 1
                DataGridView4.Rows.Add()
                DataGridView4.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
                DataGridView4.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
                DataGridView4.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
                DataGridView4.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
                DataGridView4.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString
                DataGridView4.Rows(i).Cells(5).Value = dt2.Rows(i).Item(5).ToString
                DataGridView4.Rows(i).Cells(6).Value = dt2.Rows(i).Item(6).ToString
            Next
        ElseIf ComboBox4.Text = "Date" Then
            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = "SELECT a.`arch_title`, `arch_desc`, `arch_activity_date`, b.`brgy_name`, u.`user_type`, `arch_posted_time`, `arch_username` FROM `activity_archive` as a LEFT outer join barangay_tbl as b on a.`arch_brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`arch_user_id` = u.user_id where `arch_activity_date` like '%" & TextBox10.Text.Trim & "%' " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            DataGridView4.Rows.Clear()
            For i = 0 To dt2.Rows.Count - 1
                DataGridView4.Rows.Add()
                DataGridView4.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
                DataGridView4.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
                DataGridView4.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
                DataGridView4.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
                DataGridView4.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString
                DataGridView4.Rows(i).Cells(5).Value = dt2.Rows(i).Item(5).ToString
                DataGridView4.Rows(i).Cells(6).Value = dt2.Rows(i).Item(6).ToString
            Next
        ElseIf ComboBox4.Text = "Barangay" Then
            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = "SELECT a.`arch_title`, `arch_desc`, `arch_activity_date`, b.`brgy_name`, u.`user_type`, `arch_posted_time`, `arch_username` FROM `activity_archive` as a LEFT outer join barangay_tbl as b on a.`arch_brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`arch_user_id` = u.user_id where b.`brgy_name` like '%" & TextBox10.Text.Trim & "%' " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            DataGridView4.Rows.Clear()
            For i = 0 To dt2.Rows.Count - 1
                DataGridView4.Rows.Add()
                DataGridView4.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
                DataGridView4.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
                DataGridView4.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
                DataGridView4.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
                DataGridView4.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString
                DataGridView4.Rows(i).Cells(5).Value = dt2.Rows(i).Item(5).ToString
                DataGridView4.Rows(i).Cells(6).Value = dt2.Rows(i).Item(6).ToString
            Next
        ElseIf ComboBox4.Text = "Name" Then
            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = "SELECT a.`arch_title`, `arch_desc`, `arch_activity_date`, b.`brgy_name`, u.`user_type`, `arch_posted_time`, `arch_username` FROM `activity_archive` as a LEFT outer join barangay_tbl as b on a.`arch_brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`arch_user_id` = u.user_id where `arch_username` like '%" & TextBox10.Text.Trim & "%' " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            DataGridView4.Rows.Clear()
            For i = 0 To dt2.Rows.Count - 1
                DataGridView4.Rows.Add()
                DataGridView4.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
                DataGridView4.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
                DataGridView4.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
                DataGridView4.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
                DataGridView4.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString
                DataGridView4.Rows(i).Cells(5).Value = dt2.Rows(i).Item(5).ToString
                DataGridView4.Rows(i).Cells(6).Value = dt2.Rows(i).Item(6).ToString
            Next
        ElseIf ComboBox4.Text = "User Type" Then
            Dim db2 = New Database
            Dim dt2 As New DataTable
            With db2
                .sqlStr = "SELECT a.`arch_title`, `arch_desc`, `arch_activity_date`, b.`brgy_name`, u.`user_type`, `arch_posted_time`, `arch_username` FROM `activity_archive` as a LEFT outer join barangay_tbl as b on a.`arch_brgy_id` = b.brgy_id Left outer join user_tbl as u on a.`arch_user_id` = u.user_id where u.`user_type` like '%" & TextBox10.Text.Trim & "%' " 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt2 = db2.sqlDt
            DataGridView4.Rows.Clear()
            For i = 0 To dt2.Rows.Count - 1
                DataGridView4.Rows.Add()
                DataGridView4.Rows(i).Cells(0).Value = dt2.Rows(i).Item(0).ToString
                DataGridView4.Rows(i).Cells(1).Value = dt2.Rows(i).Item(1).ToString
                DataGridView4.Rows(i).Cells(2).Value = dt2.Rows(i).Item(2).ToString
                DataGridView4.Rows(i).Cells(3).Value = dt2.Rows(i).Item(3).ToString
                DataGridView4.Rows(i).Cells(4).Value = dt2.Rows(i).Item(4).ToString
                DataGridView4.Rows(i).Cells(5).Value = dt2.Rows(i).Item(5).ToString
                DataGridView4.Rows(i).Cells(6).Value = dt2.Rows(i).Item(6).ToString
            Next
        End If
    End Sub

    Private Sub DataGridView3_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles DataGridView3.CellFormatting
        If e.ColumnIndex = 6 Then
            If e.Value IsNot Nothing Then
                e.Value = New String("*", e.Value.ToString().Length)
            End If
        End If
    End Sub

    Private Sub TextBox11_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox11_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox11.TextChanged

    End Sub

    Private Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        TextBox13.ReadOnly = False
        TextBox14.ReadOnly = False
        TextBox15.ReadOnly = False
        TextBox16.ReadOnly = False
        TextBox17.ReadOnly = False
        TextBox18.ReadOnly = False
        TextBox19.ReadOnly = False
        TextBox20.ReadOnly = False
        TextBox21.ReadOnly = False

    End Sub

    Private Sub Button17_Click_1(sender As Object, e As EventArgs) Handles Button17.Click
        Dim db = New Database
        With db
            ''-----------------------------------------EMPTY TransactID---------
            .sqlStr = "INSERT INTO `organizationa_chart`( `lydo`, `president`, `v_pres`, `sec`, `treas`, `auditor`, `business_m`, `pio`,year) 
VALUES ('" & TextBox13.Text.Trim & "','" & TextBox14.Text.Trim & "','" & TextBox15.Text.Trim & "','" & TextBox20.Text.Trim & "','" & TextBox19.Text.Trim & "','" & TextBox18.Text.Trim & "','" & TextBox17.Text.Trim & "','" & TextBox16.Text.Trim & "','" & TextBox21.Text.Trim & "')"
            .sqlDa.InsertCommand = .sqlcm(.sqlStr, .connect)
            .sqlDa.InsertCommand.ExecuteNonQuery()
            .close()
        End With
        MessageBox.Show("Successfully Saved", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Refresh()
        childhistory()
        history_lydo(childPanel, TextBox13.Text)
        history_year(childPanel, TextBox21.Text)
        history_pres(childPanel, TextBox14.Text)
        history_vpres(childPanel, TextBox15.Text)
        history_sec(childPanel, TextBox20.Text)
        history_trea(childPanel, TextBox19.Text)
        history_audi(childPanel, TextBox18.Text)
        history_BM(childPanel, TextBox17.Text)
        history_pio(childPanel, TextBox16.Text)


        TextBox13.ReadOnly = True
        TextBox14.ReadOnly = True
        TextBox15.ReadOnly = True
        TextBox16.ReadOnly = True
        TextBox17.ReadOnly = True
        TextBox18.ReadOnly = True
        TextBox19.ReadOnly = True
        TextBox20.ReadOnly = True


    End Sub
    Public Sub childhistory()
        Dim hPanel As Panel
        hPanel = New Panel()

        With hPanel
            .BackColor = Color.FromArgb(223, 230, 244)
            .Size = New Size(852, 282)
            .Name = "pnl" + (Count + 1).ToString
        End With
        FlowLayoutPanel1.Controls.Add(hPanel)
        childPanel = hPanel.Name
        Count += 1

    End Sub

    Public Sub history_year(ByVal panelName As String, ByVal txtContent As String)
        Dim activity As Label
        activity = New Label

        With activity
            .Location = New Point(38, 5)
            .Name = "lblActivity" + (Count + 1).ToString
            .Text = "PANGLUNGSOD NA PEDERASYON NG SANGGUNIANG KABATAAN - Vigan C.Y " + txtContent
            .Font = New Font("Segoe UI", 11, FontStyle.Bold)
            .Size = New Size(728, 19)
            .TextAlign = ContentAlignment.MiddleCenter
            '  .BackColor = Color.Wh ite
        End With

        For Each obj As Control In FlowLayoutPanel1.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(activity)
            End If
        Next
    End Sub

    Public Sub history_lydo(ByVal panelName As String, ByVal txtContent As String)
        Dim desc As Label
        desc = New Label

        With desc
            .Size = New Size(1000, 17)
            .Location = New Point(80, 38)
            .Name = "lblDesc" + (Count + 1).ToString
            .Text = "LOCAL YOUTH DEVELOPMENT OFFICE--------------------------------------------------" + txtContent
            .Font = New Font("Segoe UI", 10, FontStyle.Regular)
            '   .BackColor = Color.Bisque


        End With

        For Each obj As Control In FlowLayoutPanel1.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(desc)
            End If
        Next
    End Sub

    Public Sub history_pres(ByVal panelName As String, ByVal txtContent As String)
        Dim desc As Label
        desc = New Label

        With desc
            .Size = New Size(1000, 17)
            .Location = New Point(80, 65)
            .Name = "lblDesc" + (Count + 1).ToString
            .Text = "PRESIDENT-------------------------------------------------------------------------------" + txtContent
            .Font = New Font("Segoe UI", 10, FontStyle.Regular)
            '   .BackColor = Color.Bisque


        End With

        For Each obj As Control In FlowLayoutPanel1.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(desc)
            End If
        Next
    End Sub

    Public Sub history_vpres(ByVal panelName As String, ByVal txtContent As String)
        Dim desc As Label
        desc = New Label

        With desc
            .Size = New Size(1000, 17)
            .Location = New Point(80, 93)
            .Name = "lblDesc" + (Count + 1).ToString
            .Text = "VICE PRESIDENT-------------------------------------------------------------------------" + txtContent
            .Font = New Font("Segoe UI", 10, FontStyle.Regular)
            '    .BackColor = Color.Bisque


        End With

        For Each obj As Control In FlowLayoutPanel1.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(desc)
            End If
        Next
    End Sub

    Public Sub history_sec(ByVal panelName As String, ByVal txtContent As String)
        Dim desc As Label
        desc = New Label

        With desc
            .Size = New Size(1000, 17)
            .Location = New Point(80, 120)
            .Name = "lblDesc" + (Count + 1).ToString
            .Text = "SECRETARY------------------------------------------------------------------------------" + txtContent
            .Font = New Font("Segoe UI", 10, FontStyle.Regular)
            '  .BackColor = Color.Bisque


        End With

        For Each obj As Control In FlowLayoutPanel1.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(desc)
            End If
        Next
    End Sub
    Public Sub history_trea(ByVal panelName As String, ByVal txtContent As String)
        Dim desc As Label
        desc = New Label

        With desc
            .Size = New Size(1000, 17)
            .Location = New Point(80, 150)
            .Name = "lblDesc" + (Count + 1).ToString
            .Text = "TREASURER------------------------------------------------------------------------------" + txtContent
            .Font = New Font("Segoe UI", 10, FontStyle.Regular)
            '  .BackColor = Color.Bisque


        End With

        For Each obj As Control In FlowLayoutPanel1.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(desc)
            End If
        Next
    End Sub

    Public Sub history_audi(ByVal panelName As String, ByVal txtContent As String)
        Dim desc As Label
        desc = New Label

        With desc
            .Size = New Size(1000, 17)
            .Location = New Point(80, 179)
            .Name = "lblDesc" + (Count + 1).ToString
            .Text = "AUDITOR--------------------------------------------------------------------------------" + txtContent
            .Font = New Font("Segoe UI", 10, FontStyle.Regular)
            '   .BackColor = Color.Bisque


        End With

        For Each obj As Control In FlowLayoutPanel1.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(desc)
            End If
        Next
    End Sub

    Public Sub history_BM(ByVal panelName As String, ByVal txtContent As String)
        Dim desc As Label
        desc = New Label

        With desc
            .Size = New Size(1000, 17)
            .Location = New Point(80, 210)
            .Name = "lblDesc" + (Count + 1).ToString
            .Text = "BUSINESS MANAGER--------------------------------------------------------------------" + txtContent
            .Font = New Font("Segoe UI", 10, FontStyle.Regular)
            '   .BackColor = Color.Bisque


        End With

        For Each obj As Control In FlowLayoutPanel1.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(desc)
            End If
        Next
    End Sub

    Public Sub history_pio(ByVal panelName As String, ByVal txtContent As String)
        Dim desc As Label
        desc = New Label

        With desc
            .Size = New Size(1000, 17)
            .Location = New Point(80, 243)
            .Name = "lblDesc" + (Count + 1).ToString
            .Text = "PUBLIC INFORMATION OFFICER--------------------------------------------------------" + txtContent
            .Font = New Font("Segoe UI", 10, FontStyle.Regular)
            ' .BackColor = Color.Bisque


        End With

        For Each obj As Control In FlowLayoutPanel1.Controls
            If obj.Name = panelName Then
                obj.Controls.Add(desc)
            End If
        Next
    End Sub
    Public Sub GetAllOfficials(ByVal con As MySqlConnection)
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                ' "SELECT a.title, description, activity_date, posted_date ,b.brgy_name from activities as a Left outer join barangay_tbl as b on a.brgy_id = b.brgy_id"
                .sqlStr = "SELECT `lydo`, `president`, `v_pres`, `sec`, `treas`, `auditor`, `business_m`, `pio`,`year` FROM `organizationa_chart` order by id DESC"
                'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt

            For i = 0 To dt.Rows.Count - 1
                childhistory()
                history_year(childPanel, dt.Rows(i).Item(8).ToString) 'title
                history_lydo(childPanel, dt.Rows(i).Item(0).ToString)
                history_pres(childPanel, dt.Rows(i).Item(1).ToString) 'desc
                history_vpres(childPanel, dt.Rows(i).Item(2).ToString)
                history_sec(childPanel, dt.Rows(i).Item(3).ToString)
                history_trea(childPanel, dt.Rows(i).Item(4).ToString)
                history_audi(childPanel, dt.Rows(i).Item(5).ToString)
                history_BM(childPanel, dt.Rows(i).Item(6).ToString)
                history_pio(childPanel, dt.Rows(i).Item(7).ToString)
                'desc
            Next
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Button24_Click_1(sender As Object, e As EventArgs) Handles Button24.Click
        TextBox13.ReadOnly = True
        TextBox14.ReadOnly = True
        TextBox15.ReadOnly = True
        TextBox16.ReadOnly = True
        TextBox17.ReadOnly = True
        TextBox18.ReadOnly = True
        TextBox19.ReadOnly = True
        TextBox20.ReadOnly = True
        TextBox21.ReadOnly = True
    End Sub

    Private Sub TextBoxLname_TextChanged(sender As Object, e As EventArgs) Handles TextBoxLname.TextChanged
        '    TextBoxLname.Text = StrConv(TextBoxLname.Text, vbProperCase)
    End Sub

    Private Sub TextBoxMname_TextChanged(sender As Object, e As EventArgs) Handles TextBoxMname.TextChanged
        '    TextBoxMname.Text = StrConv(TextBoxMname.Text, vbProperCase)
    End Sub

    Private Sub TextBoxFname_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBoxFname.KeyUp
        TextBoxFname.Text = Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(TextBoxFname.Text)
        TextBoxFname.SelectionStart = TextBoxFname.TextLength + 1
    End Sub

    Private Sub TextBoxLname_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBoxLname.KeyUp
        TextBoxLname.Text = Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(TextBoxLname.Text)
        TextBoxLname.SelectionStart = TextBoxLname.TextLength + 1
    End Sub

    Private Sub TextBoxMname_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBoxMname.KeyUp
        TextBoxMname.Text = Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(TextBoxMname.Text)
        TextBoxMname.SelectionStart = TextBoxMname.TextLength + 1
    End Sub
End Class