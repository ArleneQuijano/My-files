﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        brgyform.Show()
        Me.Hide()
    End Sub
End Class