﻿Imports System.Windows.Forms.DataVisualization.Charting
Imports MySql.Data.MySqlClient
Imports System
Imports System.IO
Public Class brgy_stat
    Dim cn As New MySqlConnection
    Private Sub brgy_stat_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        With cn
            .ConnectionString = "Server=157.245.54.54; user id = thesis; password=2022Thesis!; database = sk_tionery_db"
            .Open()
        End With
        loadGender()
        loadCivilStat()
        loadYouthAge()
        loadClassification()
        loadEduc()
        loadWork()
        total()
    End Sub
    Sub loadGender()
        Dim brgy1 As Integer
        If brgyform.Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf brgyform.Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf brgyform.Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf brgyform.Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf brgyform.Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf brgyform.Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf brgyform.Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf brgyform.Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf brgyform.Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf brgyform.Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf brgyform.Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf brgyform.Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf brgyform.Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf brgyform.Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf brgyform.Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf brgyform.Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf brgyform.Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf brgyform.Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf brgyform.Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf brgyform.Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf brgyform.Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf brgyform.Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf brgyform.Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf brgyform.Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf brgyform.Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf brgyform.Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf brgyform.Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf brgyform.Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf brgyform.Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf brgyform.Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf brgyform.Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf brgyform.Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf brgyform.Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If

        Try
            With Chart1
                .Series.Clear()
                .Series.Add("Series1")

            End With

            Dim da As New MySqlDataAdapter("Select gender,count(id) as genTotal from information_tbl where brgy_id = " & brgy1 & " group by gender ", cn)
            Dim ds As New DataSet

            da.Fill(ds, "gender")
            Chart1.DataSource = ds.Tables("gender")
            Dim series1 As Series = Chart1.Series("Series1")
            series1.ChartType = SeriesChartType.Doughnut
            series1.Name = "gender"
            With Chart1
                .Series(series1.Name).XValueMember = "gender"
                .Series(series1.Name).YValueMembers = "genTotal"
                .Series(0).LabelFormat = "{#,##0}"
                .Series(0).IsValueShownAsLabel = True

                .Series(0).LegendText = "#VALX (#PERCENT)"

            End With
        Catch
            MessageBox.Show("Failed to load", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Sub loadCivilStat()
        Dim brgy1 As Integer
        If brgyform.Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf brgyform.Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf brgyform.Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf brgyform.Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf brgyform.Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf brgyform.Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf brgyform.Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf brgyform.Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf brgyform.Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf brgyform.Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf brgyform.Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf brgyform.Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf brgyform.Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf brgyform.Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf brgyform.Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf brgyform.Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf brgyform.Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf brgyform.Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf brgyform.Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf brgyform.Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf brgyform.Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf brgyform.Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf brgyform.Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf brgyform.Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf brgyform.Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf brgyform.Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf brgyform.Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf brgyform.Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf brgyform.Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf brgyform.Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf brgyform.Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf brgyform.Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf brgyform.Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If


        With Chart2
            .Series.Clear()
            .Series.Add("Series1")

        End With

        Dim da As New MySqlDataAdapter("Select civil_status,count(id) as civTotal from information_tbl where brgy_id = " & brgy1 & " group by civil_status", cn)
        Dim ds As New DataSet

        da.Fill(ds, "civil_status")
        Chart2.DataSource = ds.Tables("civil_status")
        Dim series1 As Series = Chart2.Series("Series1")
        series1.ChartType = SeriesChartType.Column
        series1.Name = "civil_status"
        With Chart2
            .Series(series1.Name).XValueMember = "civil_status"
            .Series(series1.Name).YValueMembers = "civTotal"
            .Series(0).Label = ("#PERCENT{P}")
            '.Series(0).IsValueShownAsLabel = True

            .Series(0).LegendText = "Civil Status"
        End With
    End Sub

    Sub loadYouthAge()

        Dim brgy1 As Integer
        If brgyform.Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf brgyform.Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf brgyform.Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf brgyform.Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf brgyform.Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf brgyform.Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf brgyform.Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf brgyform.Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf brgyform.Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf brgyform.Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf brgyform.Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf brgyform.Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf brgyform.Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf brgyform.Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf brgyform.Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf brgyform.Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf brgyform.Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf brgyform.Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf brgyform.Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf brgyform.Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf brgyform.Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf brgyform.Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf brgyform.Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf brgyform.Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf brgyform.Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf brgyform.Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf brgyform.Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf brgyform.Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf brgyform.Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf brgyform.Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf brgyform.Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf brgyform.Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf brgyform.Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If


        With Chart3
            .Series.Clear()
            .Series.Add("Series1")

        End With

        Dim da As New MySqlDataAdapter("Select youth_age,count(id) as ageTotal from information_tbl where brgy_id = " & brgy1 & " group by youth_age", cn)
        Dim ds As New DataSet

        da.Fill(ds, "youth_age")
        Chart3.DataSource = ds.Tables("youth_age")
        Dim series1 As Series = Chart3.Series("Series1")
        series1.ChartType = SeriesChartType.Pie
        series1.Name = "youth_age"
        With Chart3
            .Series(series1.Name).XValueMember = "youth_age"
            .Series(series1.Name).YValueMembers = "ageTotal"
            .Series(0).LabelFormat = "{#,##0}"
            .Series(0).IsValueShownAsLabel = True

            .Series(0).LegendText = "#VALX (#PERCENT)"
        End With
    End Sub

    Sub loadClassification()

        Dim brgy1 As Integer
        If brgyform.Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf brgyform.Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf brgyform.Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf brgyform.Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf brgyform.Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf brgyform.Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf brgyform.Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf brgyform.Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf brgyform.Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf brgyform.Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf brgyform.Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf brgyform.Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf brgyform.Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf brgyform.Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf brgyform.Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf brgyform.Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf brgyform.Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf brgyform.Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf brgyform.Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf brgyform.Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf brgyform.Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf brgyform.Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf brgyform.Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf brgyform.Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf brgyform.Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf brgyform.Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf brgyform.Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf brgyform.Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf brgyform.Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf brgyform.Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf brgyform.Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf brgyform.Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf brgyform.Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If

        With Chart4
            .Series.Clear()
            .Series.Add("Series1")

        End With

        Dim da As New MySqlDataAdapter("Select youth_classification,count(id) as classTotal from information_tbl where brgy_id = " & brgy1 & " group by youth_classification", cn)
        Dim ds As New DataSet

        da.Fill(ds, "youth_classification")
        Chart4.DataSource = ds.Tables("youth_classification")
        Dim series1 As Series = Chart4.Series("Series1")
        series1.ChartType = SeriesChartType.Pyramid
        series1.Name = "youth_classification"
        With Chart4
            .Series(series1.Name).XValueMember = "youth_classification"
            .Series(series1.Name).YValueMembers = "classTotal"
            .Series(0).LabelFormat = "{#,##0}"
            .Series(0).IsValueShownAsLabel = True

            .Series(0).LegendText = "#VALX (#PERCENT)"

        End With
    End Sub
    Sub loadEduc()
        Dim brgy1 As Integer
        If brgyform.Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf brgyform.Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf brgyform.Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf brgyform.Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf brgyform.Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf brgyform.Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf brgyform.Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf brgyform.Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf brgyform.Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf brgyform.Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf brgyform.Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf brgyform.Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf brgyform.Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf brgyform.Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf brgyform.Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf brgyform.Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf brgyform.Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf brgyform.Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf brgyform.Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf brgyform.Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf brgyform.Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf brgyform.Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf brgyform.Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf brgyform.Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf brgyform.Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf brgyform.Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf brgyform.Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf brgyform.Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf brgyform.Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf brgyform.Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf brgyform.Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf brgyform.Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf brgyform.Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If


        Dim edu As String
        With Chart5
            .Series.Clear()
            .Series.Add("Series1")

        End With

        Dim da As New MySqlDataAdapter("Select information_tbl.educ_id,count(id) as educTotal, educ_tbl.educational_level FROM information_tbl INNER JOIN educ_tbl on information_tbl.educ_id= educ_tbl.educ_id where brgy_id = " & brgy1 & " GROUP BY educ_id", cn)
        Dim ds As New DataSet

        da.Fill(ds, "educ_id")
        Chart5.DataSource = ds.Tables("educ_id")
        Dim series1 As Series = Chart5.Series("Series1")
        series1.ChartType = SeriesChartType.Column
        series1.Name = "educ_id"
        With Chart5
            .Series(series1.Name).XValueMember = "educational_level"
            .Series(series1.Name).YValueMembers = "educTotal"
            .Series(0).Label = ("#PERCENT{P}")
            .Series(0).IsValueShownAsLabel = True
            ' .Series(0).LegendText = text
            .Series(0).LegendText = "Educational Attainment"

        End With
    End Sub
    Sub loadWork()
        Dim brgy1 As Integer
        If brgyform.Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf brgyform.Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf brgyform.Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf brgyform.Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf brgyform.Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf brgyform.Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf brgyform.Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf brgyform.Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf brgyform.Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf brgyform.Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf brgyform.Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf brgyform.Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf brgyform.Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf brgyform.Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf brgyform.Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf brgyform.Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf brgyform.Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf brgyform.Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf brgyform.Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf brgyform.Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf brgyform.Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf brgyform.Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf brgyform.Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf brgyform.Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf brgyform.Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf brgyform.Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf brgyform.Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf brgyform.Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf brgyform.Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf brgyform.Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf brgyform.Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf brgyform.Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf brgyform.Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If

        With Chart6
            .Series.Clear()
            .Series.Add("Series1")

        End With

        Dim da As New MySqlDataAdapter("Select work_status,count(id) as workTotal from information_tbl where brgy_id = " & brgy1 & " group by work_status", cn)
        Dim ds As New DataSet

        da.Fill(ds, "work_status")
        Chart6.DataSource = ds.Tables("work_status")
        Dim series1 As Series = Chart6.Series("Series1")
        series1.ChartType = SeriesChartType.Doughnut
        series1.Name = "work_status"
        With Chart6
            .Series(series1.Name).XValueMember = "work_status"
            .Series(series1.Name).YValueMembers = "workTotal"
            .Series(0).LabelFormat = "{#,##0}"
            .Series(0).IsValueShownAsLabel = True
            ' .Series(0).LegendText = text
            .Series(0).LegendText = "#VALX (#PERCENT)"

        End With
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        brgyform.Show()
        Me.Hide()
        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
    End Sub
    Sub total()
        Dim brgy1 As Integer
        If brgyform.Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf brgyform.Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf brgyform.Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf brgyform.Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf brgyform.Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf brgyform.Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf brgyform.Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf brgyform.Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf brgyform.Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf brgyform.Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf brgyform.Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf brgyform.Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf brgyform.Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf brgyform.Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf brgyform.Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf brgyform.Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf brgyform.Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf brgyform.Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf brgyform.Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf brgyform.Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf brgyform.Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf brgyform.Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf brgyform.Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf brgyform.Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf brgyform.Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf brgyform.Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf brgyform.Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf brgyform.Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf brgyform.Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf brgyform.Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf brgyform.Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf brgyform.Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf brgyform.Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf brgyform.Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf brgyform.Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf brgyform.Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Dim db = New Database
        Dim dt As New DataTable
        With db
            .sqlStr = "select count(*) from information_tbl where brgy_id = " & brgy1 & " "
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
            .close()
        End With
        dt = db.sqlDt
        Label9.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label24.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label25.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label27.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label30.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label31.Text = "Total: " + dt.Rows(0).Item(0).ToString
        Label96.Text = "Total: " + dt.Rows(0).Item(0).ToString
    End Sub

End Class