﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class menuForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(menuForm))
        Dim DataGridViewCellStyle46 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle47 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle48 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle49 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle50 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle51 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle52 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle53 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle54 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle55 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim ChartArea19 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend19 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series19 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea20 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend20 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series20 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea21 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend21 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series21 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea22 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend22 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series22 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea23 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend23 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series23 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea24 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend24 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series24 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim DataGridViewCellStyle56 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle57 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle58 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle59 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle60 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PanelAdminDahboard = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PanelActivities = New System.Windows.Forms.Panel()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.flpPanel = New System.Windows.Forms.FlowLayoutPanel()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.flpAnnouncements = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.panelbarangay = New System.Windows.Forms.Panel()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.brgy20button = New System.Windows.Forms.Button()
        Me.brgy12button = New System.Windows.Forms.Button()
        Me.brgy19button = New System.Windows.Forms.Button()
        Me.brgy18button = New System.Windows.Forms.Button()
        Me.brgy17button = New System.Windows.Forms.Button()
        Me.brgy16button = New System.Windows.Forms.Button()
        Me.brgy15button = New System.Windows.Forms.Button()
        Me.brgy14button = New System.Windows.Forms.Button()
        Me.brgy13button = New System.Windows.Forms.Button()
        Me.brgy11button = New System.Windows.Forms.Button()
        Me.brgy30button = New System.Windows.Forms.Button()
        Me.brgy22button = New System.Windows.Forms.Button()
        Me.brgy29button = New System.Windows.Forms.Button()
        Me.brgy28button = New System.Windows.Forms.Button()
        Me.brgy27button = New System.Windows.Forms.Button()
        Me.brgy26button = New System.Windows.Forms.Button()
        Me.brgy25button = New System.Windows.Forms.Button()
        Me.brgy24button = New System.Windows.Forms.Button()
        Me.brgy23button = New System.Windows.Forms.Button()
        Me.brgy21button = New System.Windows.Forms.Button()
        Me.brgy32button = New System.Windows.Forms.Button()
        Me.brgy39button = New System.Windows.Forms.Button()
        Me.brgy38button = New System.Windows.Forms.Button()
        Me.brgy37button = New System.Windows.Forms.Button()
        Me.brgy36button = New System.Windows.Forms.Button()
        Me.brgy35button = New System.Windows.Forms.Button()
        Me.brgy33button = New System.Windows.Forms.Button()
        Me.brgy34button = New System.Windows.Forms.Button()
        Me.brgy31button = New System.Windows.Forms.Button()
        Me.brgy10button = New System.Windows.Forms.Button()
        Me.brgy2button = New System.Windows.Forms.Button()
        Me.brgy9button = New System.Windows.Forms.Button()
        Me.brgy8button = New System.Windows.Forms.Button()
        Me.brgy7button = New System.Windows.Forms.Button()
        Me.brgy6button = New System.Windows.Forms.Button()
        Me.brgy5button = New System.Windows.Forms.Button()
        Me.brgy4button = New System.Windows.Forms.Button()
        Me.brgy3button = New System.Windows.Forms.Button()
        Me.brgy1button = New System.Windows.Forms.Button()
        Me.panelAboutUs = New System.Windows.Forms.Panel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.PanelMonthlyReport = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Button60 = New System.Windows.Forms.Button()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button59 = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.panelHistory = New System.Windows.Forms.Panel()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.PanelArchive = New System.Windows.Forms.Panel()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.PanelUserManagement = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBoxLname = New System.Windows.Forms.TextBox()
        Me.TextBoxMname = New System.Windows.Forms.TextBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.TextBoxUsername = New System.Windows.Forms.TextBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.TextBoxPassword = New System.Windows.Forms.TextBox()
        Me.TextBoxFname = New System.Windows.Forms.TextBox()
        Me.TextBoxID = New System.Windows.Forms.TextBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.ComboBoxBarangay = New System.Windows.Forms.ComboBox()
        Me.ComboBoxUsertype = New System.Windows.Forms.ComboBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.PanelArchive2 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBoxSearch = New System.Windows.Forms.TextBox()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.infoarchiveDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.PanelStat = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Chart6 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Chart3 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Chart4 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Chart2 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Chart5 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.panelReportArchive = New System.Windows.Forms.Panel()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.PanelSMS = New System.Windows.Forms.Panel()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.DataGridView5 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column25 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.panelOfficials = New System.Windows.Forms.Panel()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.PanelAdminDahboard.SuspendLayout()
        Me.Panel25.SuspendLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel17.SuspendLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelActivities.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.panelbarangay.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.panelAboutUs.SuspendLayout()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.PanelMonthlyReport.SuspendLayout()
        Me.Panel10.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.panelHistory.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.PanelArchive.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.PanelUserManagement.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel24.SuspendLayout()
        Me.PanelArchive2.SuspendLayout()
        CType(Me.infoarchiveDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel26.SuspendLayout()
        Me.PanelStat.SuspendLayout()
        Me.Panel11.SuspendLayout()
        CType(Me.Chart6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel9.SuspendLayout()
        CType(Me.Chart3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        CType(Me.Chart4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel31.SuspendLayout()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel28.SuspendLayout()
        CType(Me.Chart5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel15.SuspendLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel27.SuspendLayout()
        Me.panelReportArchive.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel29.SuspendLayout()
        Me.PanelSMS.SuspendLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel13.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.panelOfficials.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelAdminDahboard
        '
        Me.PanelAdminDahboard.BackColor = System.Drawing.Color.AntiqueWhite
        Me.PanelAdminDahboard.Controls.Add(Me.Label23)
        Me.PanelAdminDahboard.Controls.Add(Me.Label21)
        Me.PanelAdminDahboard.Controls.Add(Me.Label20)
        Me.PanelAdminDahboard.Controls.Add(Me.Label11)
        Me.PanelAdminDahboard.Controls.Add(Me.Panel25)
        Me.PanelAdminDahboard.Controls.Add(Me.Panel17)
        Me.PanelAdminDahboard.Controls.Add(Me.Label19)
        Me.PanelAdminDahboard.Controls.Add(Me.PictureBox1)
        Me.PanelAdminDahboard.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelAdminDahboard.Location = New System.Drawing.Point(0, 0)
        Me.PanelAdminDahboard.Name = "PanelAdminDahboard"
        Me.PanelAdminDahboard.Size = New System.Drawing.Size(281, 751)
        Me.PanelAdminDahboard.TabIndex = 0
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Segoe UI Black", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Label23.Location = New System.Drawing.Point(10, 42)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(153, 25)
        Me.Label23.TabIndex = 17
        Me.Label23.Text = "Arlene Quijano"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Label21.Location = New System.Drawing.Point(50, 72)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(38, 17)
        Me.Label21.TabIndex = 16
        Me.Label21.Text = "Brgy."
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Label20.Location = New System.Drawing.Point(13, 72)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(40, 17)
        Me.Label20.TabIndex = 15
        Me.Label20.Text = "LYDO"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Segoe UI Black", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Label11.Location = New System.Drawing.Point(6, 11)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(136, 32)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "WELCOME"
        '
        'Panel25
        '
        Me.Panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel25.Controls.Add(Me.PictureBox12)
        Me.Panel25.Controls.Add(Me.Button10)
        Me.Panel25.Location = New System.Drawing.Point(0, 674)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(281, 60)
        Me.Panel25.TabIndex = 13
        '
        'PictureBox12
        '
        Me.PictureBox12.BackgroundImage = CType(resources.GetObject("PictureBox12.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox12.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(49, 46)
        Me.PictureBox12.TabIndex = 18
        Me.PictureBox12.TabStop = False
        '
        'Button10
        '
        Me.Button10.FlatAppearance.BorderSize = 0
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button10.Location = New System.Drawing.Point(64, 6)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(211, 46)
        Me.Button10.TabIndex = 11
        Me.Button10.Text = "Log Out"
        Me.Button10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Panel17
        '
        Me.Panel17.BackColor = System.Drawing.Color.Transparent
        Me.Panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel17.Controls.Add(Me.PictureBox13)
        Me.Panel17.Controls.Add(Me.Button27)
        Me.Panel17.Controls.Add(Me.PictureBox11)
        Me.Panel17.Controls.Add(Me.PictureBox10)
        Me.Panel17.Controls.Add(Me.Button2)
        Me.Panel17.Controls.Add(Me.PictureBox9)
        Me.Panel17.Controls.Add(Me.PictureBox8)
        Me.Panel17.Controls.Add(Me.PictureBox7)
        Me.Panel17.Controls.Add(Me.PictureBox6)
        Me.Panel17.Controls.Add(Me.PictureBox3)
        Me.Panel17.Controls.Add(Me.PictureBox2)
        Me.Panel17.Controls.Add(Me.Button1)
        Me.Panel17.Controls.Add(Me.Button3)
        Me.Panel17.Controls.Add(Me.Button6)
        Me.Panel17.Controls.Add(Me.Button8)
        Me.Panel17.Controls.Add(Me.Button7)
        Me.Panel17.Controls.Add(Me.Button5)
        Me.Panel17.Controls.Add(Me.Button4)
        Me.Panel17.Location = New System.Drawing.Point(0, 277)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(281, 398)
        Me.Panel17.TabIndex = 12
        '
        'PictureBox13
        '
        Me.PictureBox13.BackgroundImage = CType(resources.GetObject("PictureBox13.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox13.Location = New System.Drawing.Point(9, 136)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(49, 40)
        Me.PictureBox13.TabIndex = 19
        Me.PictureBox13.TabStop = False
        '
        'Button27
        '
        Me.Button27.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Button27.FlatAppearance.BorderSize = 0
        Me.Button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button27.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button27.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button27.Location = New System.Drawing.Point(64, 136)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(216, 40)
        Me.Button27.TabIndex = 18
        Me.Button27.Text = "Statistical Reports"
        Me.Button27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button27.UseVisualStyleBackColor = False
        '
        'PictureBox11
        '
        Me.PictureBox11.BackgroundImage = CType(resources.GetObject("PictureBox11.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox11.Location = New System.Drawing.Point(9, 347)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(49, 40)
        Me.PictureBox11.TabIndex = 17
        Me.PictureBox11.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BackgroundImage = CType(resources.GetObject("PictureBox10.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox10.Location = New System.Drawing.Point(9, 305)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(49, 40)
        Me.PictureBox10.TabIndex = 16
        Me.PictureBox10.TabStop = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(64, 52)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(216, 40)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Barangay"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.UseVisualStyleBackColor = False
        '
        'PictureBox9
        '
        Me.PictureBox9.BackgroundImage = CType(resources.GetObject("PictureBox9.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox9.Location = New System.Drawing.Point(9, 263)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(49, 40)
        Me.PictureBox9.TabIndex = 15
        Me.PictureBox9.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackgroundImage = CType(resources.GetObject("PictureBox8.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox8.Location = New System.Drawing.Point(9, 221)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(49, 40)
        Me.PictureBox8.TabIndex = 14
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackgroundImage = CType(resources.GetObject("PictureBox7.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox7.Location = New System.Drawing.Point(9, 179)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(49, 40)
        Me.PictureBox7.TabIndex = 13
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox6.Location = New System.Drawing.Point(9, 94)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(49, 40)
        Me.PictureBox6.TabIndex = 12
        Me.PictureBox6.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox3.Location = New System.Drawing.Point(9, 53)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(49, 39)
        Me.PictureBox3.TabIndex = 11
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox2.Location = New System.Drawing.Point(9, 9)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(49, 40)
        Me.PictureBox2.TabIndex = 10
        Me.PictureBox2.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(64, 9)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(216, 40)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Activities and Updates"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.Location = New System.Drawing.Point(64, 94)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(216, 40)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Reports"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button6.Location = New System.Drawing.Point(64, 348)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(216, 40)
        Me.Button6.TabIndex = 7
        Me.Button6.Text = "About us"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button8.Location = New System.Drawing.Point(64, 306)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(216, 40)
        Me.Button8.TabIndex = 9
        Me.Button8.Text = "User Management"
        Me.Button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button7.Location = New System.Drawing.Point(64, 263)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(216, 40)
        Me.Button7.TabIndex = 8
        Me.Button7.Text = "Archive"
        Me.Button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.Location = New System.Drawing.Point(64, 221)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(216, 40)
        Me.Button5.TabIndex = 6
        Me.Button5.Text = "History"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.Location = New System.Drawing.Point(64, 179)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(216, 40)
        Me.Button4.TabIndex = 5
        Me.Button4.Text = "Organizational Chart"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Label19.Location = New System.Drawing.Point(86, 72)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(92, 17)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "Ayusan Norte"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(47, 103)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(168, 165)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'PanelActivities
        '
        Me.PanelActivities.BackColor = System.Drawing.Color.LightSteelBlue
        Me.PanelActivities.Controls.Add(Me.TabControl2)
        Me.PanelActivities.Controls.Add(Me.Panel3)
        Me.PanelActivities.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelActivities.Location = New System.Drawing.Point(281, 0)
        Me.PanelActivities.Name = "PanelActivities"
        Me.PanelActivities.Size = New System.Drawing.Size(1091, 751)
        Me.PanelActivities.TabIndex = 1
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl2.Location = New System.Drawing.Point(0, 48)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.Padding = New System.Drawing.Point(185, 10)
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(1091, 703)
        Me.TabControl2.TabIndex = 13
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.TabPage3.BackgroundImage = CType(resources.GetObject("TabPage3.BackgroundImage"), System.Drawing.Image)
        Me.TabPage3.Controls.Add(Me.Panel8)
        Me.TabPage3.Controls.Add(Me.flpPanel)
        Me.TabPage3.Location = New System.Drawing.Point(4, 40)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(200, 3, 3, 3)
        Me.TabPage3.Size = New System.Drawing.Size(1083, 659)
        Me.TabPage3.TabIndex = 0
        Me.TabPage3.Text = "Activities and Updates"
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Transparent
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel8.Controls.Add(Me.Panel16)
        Me.Panel8.Location = New System.Drawing.Point(126, 4)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(808, 201)
        Me.Panel8.TabIndex = 12
        '
        'Panel16
        '
        Me.Panel16.BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.Panel16.Controls.Add(Me.Label29)
        Me.Panel16.Controls.Add(Me.Label28)
        Me.Panel16.Controls.Add(Me.Button25)
        Me.Panel16.Controls.Add(Me.DateTimePicker1)
        Me.Panel16.Controls.Add(Me.Label92)
        Me.Panel16.Controls.Add(Me.RichTextBox1)
        Me.Panel16.Controls.Add(Me.TextBox12)
        Me.Panel16.Location = New System.Drawing.Point(19, 13)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(766, 172)
        Me.Panel16.TabIndex = 7
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(80, 8)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(40, 17)
        Me.Label29.TabIndex = 12
        Me.Label29.Text = "Title:"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(40, 39)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(83, 17)
        Me.Label28.TabIndex = 11
        Me.Label28.Text = "Description:"
        '
        'Button25
        '
        Me.Button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button25.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.Location = New System.Drawing.Point(649, 134)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(84, 25)
        Me.Button25.TabIndex = 7
        Me.Button25.Text = "Post"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CustomFormat = "hh:mm tt ddd dd MMM yyyy"
        Me.DateTimePicker1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker1.Location = New System.Drawing.Point(129, 132)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(405, 25)
        Me.DateTimePicker1.TabIndex = 10
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(13, 136)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(109, 17)
        Me.Label92.TabIndex = 2
        Me.Label92.Text = "Date of Activity:"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(129, 39)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(604, 87)
        Me.RichTextBox1.TabIndex = 9
        Me.RichTextBox1.Text = ""
        '
        'TextBox12
        '
        Me.TextBox12.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(129, 8)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(604, 25)
        Me.TextBox12.TabIndex = 3
        '
        'flpPanel
        '
        Me.flpPanel.AutoScroll = True
        Me.flpPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.flpPanel.FlowDirection = System.Windows.Forms.FlowDirection.BottomUp
        Me.flpPanel.Location = New System.Drawing.Point(126, 212)
        Me.flpPanel.Name = "flpPanel"
        Me.flpPanel.Padding = New System.Windows.Forms.Padding(10, 5, 5, 0)
        Me.flpPanel.Size = New System.Drawing.Size(808, 434)
        Me.flpPanel.TabIndex = 9
        Me.flpPanel.WrapContents = False
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.LightSteelBlue
        Me.TabPage4.BackgroundImage = CType(resources.GetObject("TabPage4.BackgroundImage"), System.Drawing.Image)
        Me.TabPage4.Controls.Add(Me.Panel2)
        Me.TabPage4.Controls.Add(Me.flpAnnouncements)
        Me.TabPage4.Location = New System.Drawing.Point(4, 40)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1083, 659)
        Me.TabPage4.TabIndex = 1
        Me.TabPage4.Text = "Announcements for SK Federation"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Panel6)
        Me.Panel2.Location = New System.Drawing.Point(126, 4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(809, 201)
        Me.Panel2.TabIndex = 13
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.Panel6.Controls.Add(Me.Label14)
        Me.Panel6.Controls.Add(Me.Button13)
        Me.Panel6.Controls.Add(Me.RichTextBox2)
        Me.Panel6.Location = New System.Drawing.Point(19, 13)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(766, 172)
        Me.Panel6.TabIndex = 7
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(18, 11)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(135, 17)
        Me.Label14.TabIndex = 11
        Me.Label14.Text = "Add Announcement:"
        '
        'Button13
        '
        Me.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button13.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.Location = New System.Drawing.Point(649, 132)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(84, 25)
        Me.Button13.TabIndex = 7
        Me.Button13.Text = "Post"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox2.Location = New System.Drawing.Point(21, 33)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(712, 92)
        Me.RichTextBox2.TabIndex = 9
        Me.RichTextBox2.Text = ""
        '
        'flpAnnouncements
        '
        Me.flpAnnouncements.AutoScroll = True
        Me.flpAnnouncements.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.flpAnnouncements.FlowDirection = System.Windows.Forms.FlowDirection.BottomUp
        Me.flpAnnouncements.Location = New System.Drawing.Point(126, 212)
        Me.flpAnnouncements.Name = "flpAnnouncements"
        Me.flpAnnouncements.Padding = New System.Windows.Forms.Padding(10, 5, 5, 0)
        Me.flpAnnouncements.Size = New System.Drawing.Size(808, 434)
        Me.flpAnnouncements.TabIndex = 9
        Me.flpAnnouncements.WrapContents = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Label26)
        Me.Panel3.Controls.Add(Me.Label22)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1091, 48)
        Me.Panel3.TabIndex = 0
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label26.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label26.Location = New System.Drawing.Point(35, 5)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(367, 37)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "ACTIVITIES AND UPDATES"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.Control
        Me.Label22.Location = New System.Drawing.Point(804, 15)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(81, 25)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Label22"
        '
        'panelbarangay
        '
        Me.panelbarangay.AutoScroll = True
        Me.panelbarangay.AutoScrollMargin = New System.Drawing.Size(0, 50)
        Me.panelbarangay.BackColor = System.Drawing.Color.LightSteelBlue
        Me.panelbarangay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.panelbarangay.Controls.Add(Me.Label86)
        Me.panelbarangay.Controls.Add(Me.Label85)
        Me.panelbarangay.Controls.Add(Me.Label83)
        Me.panelbarangay.Controls.Add(Me.Label82)
        Me.panelbarangay.Controls.Add(Me.Label81)
        Me.panelbarangay.Controls.Add(Me.Label80)
        Me.panelbarangay.Controls.Add(Me.Label72)
        Me.panelbarangay.Controls.Add(Me.Label71)
        Me.panelbarangay.Controls.Add(Me.Label70)
        Me.panelbarangay.Controls.Add(Me.Label69)
        Me.panelbarangay.Controls.Add(Me.Label67)
        Me.panelbarangay.Controls.Add(Me.Label66)
        Me.panelbarangay.Controls.Add(Me.Label65)
        Me.panelbarangay.Controls.Add(Me.Label64)
        Me.panelbarangay.Controls.Add(Me.Label63)
        Me.panelbarangay.Controls.Add(Me.Label62)
        Me.panelbarangay.Controls.Add(Me.Label61)
        Me.panelbarangay.Controls.Add(Me.Label60)
        Me.panelbarangay.Controls.Add(Me.Label59)
        Me.panelbarangay.Controls.Add(Me.Label58)
        Me.panelbarangay.Controls.Add(Me.Label56)
        Me.panelbarangay.Controls.Add(Me.Label55)
        Me.panelbarangay.Controls.Add(Me.Label50)
        Me.panelbarangay.Controls.Add(Me.Label49)
        Me.panelbarangay.Controls.Add(Me.Label48)
        Me.panelbarangay.Controls.Add(Me.Label47)
        Me.panelbarangay.Controls.Add(Me.Label46)
        Me.panelbarangay.Controls.Add(Me.Label45)
        Me.panelbarangay.Controls.Add(Me.Label44)
        Me.panelbarangay.Controls.Add(Me.Label43)
        Me.panelbarangay.Controls.Add(Me.Label42)
        Me.panelbarangay.Controls.Add(Me.Label41)
        Me.panelbarangay.Controls.Add(Me.Label40)
        Me.panelbarangay.Controls.Add(Me.Label39)
        Me.panelbarangay.Controls.Add(Me.Label38)
        Me.panelbarangay.Controls.Add(Me.Label37)
        Me.panelbarangay.Controls.Add(Me.Label36)
        Me.panelbarangay.Controls.Add(Me.Label35)
        Me.panelbarangay.Controls.Add(Me.Label34)
        Me.panelbarangay.Controls.Add(Me.Panel1)
        Me.panelbarangay.Controls.Add(Me.brgy20button)
        Me.panelbarangay.Controls.Add(Me.brgy12button)
        Me.panelbarangay.Controls.Add(Me.brgy19button)
        Me.panelbarangay.Controls.Add(Me.brgy18button)
        Me.panelbarangay.Controls.Add(Me.brgy17button)
        Me.panelbarangay.Controls.Add(Me.brgy16button)
        Me.panelbarangay.Controls.Add(Me.brgy15button)
        Me.panelbarangay.Controls.Add(Me.brgy14button)
        Me.panelbarangay.Controls.Add(Me.brgy13button)
        Me.panelbarangay.Controls.Add(Me.brgy11button)
        Me.panelbarangay.Controls.Add(Me.brgy30button)
        Me.panelbarangay.Controls.Add(Me.brgy22button)
        Me.panelbarangay.Controls.Add(Me.brgy29button)
        Me.panelbarangay.Controls.Add(Me.brgy28button)
        Me.panelbarangay.Controls.Add(Me.brgy27button)
        Me.panelbarangay.Controls.Add(Me.brgy26button)
        Me.panelbarangay.Controls.Add(Me.brgy25button)
        Me.panelbarangay.Controls.Add(Me.brgy24button)
        Me.panelbarangay.Controls.Add(Me.brgy23button)
        Me.panelbarangay.Controls.Add(Me.brgy21button)
        Me.panelbarangay.Controls.Add(Me.brgy32button)
        Me.panelbarangay.Controls.Add(Me.brgy39button)
        Me.panelbarangay.Controls.Add(Me.brgy38button)
        Me.panelbarangay.Controls.Add(Me.brgy37button)
        Me.panelbarangay.Controls.Add(Me.brgy36button)
        Me.panelbarangay.Controls.Add(Me.brgy35button)
        Me.panelbarangay.Controls.Add(Me.brgy33button)
        Me.panelbarangay.Controls.Add(Me.brgy34button)
        Me.panelbarangay.Controls.Add(Me.brgy31button)
        Me.panelbarangay.Controls.Add(Me.brgy10button)
        Me.panelbarangay.Controls.Add(Me.brgy2button)
        Me.panelbarangay.Controls.Add(Me.brgy9button)
        Me.panelbarangay.Controls.Add(Me.brgy8button)
        Me.panelbarangay.Controls.Add(Me.brgy7button)
        Me.panelbarangay.Controls.Add(Me.brgy6button)
        Me.panelbarangay.Controls.Add(Me.brgy5button)
        Me.panelbarangay.Controls.Add(Me.brgy4button)
        Me.panelbarangay.Controls.Add(Me.brgy3button)
        Me.panelbarangay.Controls.Add(Me.brgy1button)
        Me.panelbarangay.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelbarangay.Location = New System.Drawing.Point(281, 0)
        Me.panelbarangay.Name = "panelbarangay"
        Me.panelbarangay.Size = New System.Drawing.Size(1091, 751)
        Me.panelbarangay.TabIndex = 5
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(52, 1470)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(160, 25)
        Me.Label86.TabIndex = 82
        Me.Label86.Text = "San Julian Norte"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(260, 1468)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(138, 25)
        Me.Label85.TabIndex = 81
        Me.Label85.Text = "San Julian Sur"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(477, 1466)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(103, 25)
        Me.Label83.TabIndex = 79
        Me.Label83.Text = "San Pedro"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(723, 1468)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(70, 25)
        Me.Label82.TabIndex = 78
        Me.Label82.Text = "Tamag"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.Location = New System.Drawing.Point(884, 1287)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(88, 25)
        Me.Label81.TabIndex = 77
        Me.Label81.Text = "San Jose"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(479, 1287)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(112, 25)
        Me.Label80.TabIndex = 76
        Me.Label80.Text = "Rugsuanan"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.Location = New System.Drawing.Point(704, 1287)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(89, 25)
        Me.Label72.TabIndex = 75
        Me.Label72.Text = "Salindeg"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.Location = New System.Drawing.Point(296, 1288)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(59, 25)
        Me.Label71.TabIndex = 74
        Me.Label71.Text = "Raois"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(50, 1287)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(149, 25)
        Me.Label70.TabIndex = 73
        Me.Label70.Text = "Purok-a-dackel"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.Location = New System.Drawing.Point(870, 1099)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(142, 25)
        Me.Label69.TabIndex = 72
        Me.Label69.Text = "Purok-a-bassit"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(694, 1099)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(84, 25)
        Me.Label67.TabIndex = 71
        Me.Label67.Text = "Pong-ol"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(485, 1097)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(95, 25)
        Me.Label66.TabIndex = 70
        Me.Label66.Text = "Paratong"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.Location = New System.Drawing.Point(302, 1097)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(56, 25)
        Me.Label65.TabIndex = 69
        Me.Label65.Text = "Paoa"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(67, 1097)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(122, 25)
        Me.Label64.TabIndex = 68
        Me.Label64.Text = "Pantay Laud"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(876, 906)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(136, 25)
        Me.Label63.TabIndex = 67
        Me.Label63.Text = "Pantay Fatima"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(671, 906)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(122, 25)
        Me.Label62.TabIndex = 66
        Me.Label62.Text = "Pantay Daya"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.Location = New System.Drawing.Point(465, 906)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(128, 25)
        Me.Label61.TabIndex = 65
        Me.Label61.Text = "Nagsangalan"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(285, 906)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(91, 25)
        Me.Label60.TabIndex = 64
        Me.Label60.Text = "Mindoro"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(45, 906)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(148, 25)
        Me.Label59.TabIndex = 63
        Me.Label59.Text = "Capangpangan"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(892, 718)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(117, 25)
        Me.Label58.TabIndex = 62
        Me.Label58.Text = "Camangaan"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(661, 719)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(147, 25)
        Me.Label56.TabIndex = 61
        Me.Label56.Text = "Cabaroan Laud"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(458, 719)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(147, 25)
        Me.Label55.TabIndex = 60
        Me.Label55.Text = "Cabaroan Daya"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(260, 719)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(139, 25)
        Me.Label50.TabIndex = 59
        Me.Label50.Text = "Cabalangegan"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(90, 719)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(66, 25)
        Me.Label49.TabIndex = 58
        Me.Label49.Text = "Bulala"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(65, 543)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(119, 25)
        Me.Label48.TabIndex = 57
        Me.Label48.Text = "Barangay IX"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(287, 543)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(79, 25)
        Me.Label47.TabIndex = 56
        Me.Label47.Text = "Barraca"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(460, 543)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(141, 25)
        Me.Label46.TabIndex = 55
        Me.Label46.Text = "Beddeng Daya"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(667, 543)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(141, 25)
        Me.Label45.TabIndex = 54
        Me.Label45.Text = "Beddeng Laud"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(892, 543)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(106, 25)
        Me.Label44.TabIndex = 53
        Me.Label44.Text = "Bongtolan"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(876, 368)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(132, 25)
        Me.Label43.TabIndex = 52
        Me.Label43.Text = "Barangay VIII"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(671, 368)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(126, 25)
        Me.Label42.TabIndex = 51
        Me.Label42.Text = "Barangay VII"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(472, 368)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(120, 25)
        Me.Label41.TabIndex = 50
        Me.Label41.Text = "Barangay VI"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(269, 368)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(114, 25)
        Me.Label40.TabIndex = 49
        Me.Label40.Text = "Barangay V"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(64, 368)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(120, 25)
        Me.Label39.TabIndex = 48
        Me.Label39.Text = "Barangay IV"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(882, 193)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(119, 25)
        Me.Label38.TabIndex = 47
        Me.Label38.Text = "Barangay III"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(683, 192)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(113, 25)
        Me.Label37.TabIndex = 46
        Me.Label37.Text = "Barangay II"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(476, 192)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(107, 25)
        Me.Label36.TabIndex = 45
        Me.Label36.Text = "Barangay I"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(276, 192)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(113, 25)
        Me.Label35.TabIndex = 44
        Me.Label35.Text = "Ayusan Sur"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(57, 191)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(135, 25)
        Me.Label34.TabIndex = 43
        Me.Label34.Text = "Ayusan Norte"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1074, 48)
        Me.Panel1.TabIndex = 42
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(35, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(174, 37)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "BARANGAY"
        '
        'brgy20button
        '
        Me.brgy20button.BackColor = System.Drawing.Color.Transparent
        Me.brgy20button.FlatAppearance.BorderSize = 0
        Me.brgy20button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy20button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy20button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy20button.Image = CType(resources.GetObject("brgy20button.Image"), System.Drawing.Image)
        Me.brgy20button.Location = New System.Drawing.Point(845, 597)
        Me.brgy20button.Name = "brgy20button"
        Me.brgy20button.Size = New System.Drawing.Size(192, 118)
        Me.brgy20button.TabIndex = 41
        Me.brgy20button.UseVisualStyleBackColor = False
        '
        'brgy12button
        '
        Me.brgy12button.BackColor = System.Drawing.Color.Transparent
        Me.brgy12button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.brgy12button.FlatAppearance.BorderSize = 0
        Me.brgy12button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy12button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy12button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy12button.Image = CType(resources.GetObject("brgy12button.Image"), System.Drawing.Image)
        Me.brgy12button.Location = New System.Drawing.Point(233, 422)
        Me.brgy12button.Name = "brgy12button"
        Me.brgy12button.Size = New System.Drawing.Size(192, 118)
        Me.brgy12button.TabIndex = 33
        Me.brgy12button.UseVisualStyleBackColor = False
        '
        'brgy19button
        '
        Me.brgy19button.BackColor = System.Drawing.Color.Transparent
        Me.brgy19button.FlatAppearance.BorderSize = 0
        Me.brgy19button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy19button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy19button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy19button.Image = CType(resources.GetObject("brgy19button.Image"), System.Drawing.Image)
        Me.brgy19button.Location = New System.Drawing.Point(639, 598)
        Me.brgy19button.Name = "brgy19button"
        Me.brgy19button.Size = New System.Drawing.Size(192, 118)
        Me.brgy19button.TabIndex = 40
        Me.brgy19button.UseVisualStyleBackColor = False
        '
        'brgy18button
        '
        Me.brgy18button.BackColor = System.Drawing.Color.Transparent
        Me.brgy18button.FlatAppearance.BorderSize = 0
        Me.brgy18button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy18button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy18button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy18button.Image = CType(resources.GetObject("brgy18button.Image"), System.Drawing.Image)
        Me.brgy18button.Location = New System.Drawing.Point(435, 598)
        Me.brgy18button.Name = "brgy18button"
        Me.brgy18button.Size = New System.Drawing.Size(192, 118)
        Me.brgy18button.TabIndex = 39
        Me.brgy18button.UseVisualStyleBackColor = False
        '
        'brgy17button
        '
        Me.brgy17button.BackColor = System.Drawing.Color.Transparent
        Me.brgy17button.FlatAppearance.BorderSize = 0
        Me.brgy17button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy17button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy17button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy17button.Image = CType(resources.GetObject("brgy17button.Image"), System.Drawing.Image)
        Me.brgy17button.Location = New System.Drawing.Point(233, 598)
        Me.brgy17button.Name = "brgy17button"
        Me.brgy17button.Size = New System.Drawing.Size(192, 118)
        Me.brgy17button.TabIndex = 38
        Me.brgy17button.UseVisualStyleBackColor = False
        '
        'brgy16button
        '
        Me.brgy16button.BackColor = System.Drawing.Color.Transparent
        Me.brgy16button.FlatAppearance.BorderSize = 0
        Me.brgy16button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy16button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy16button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy16button.Image = CType(resources.GetObject("brgy16button.Image"), System.Drawing.Image)
        Me.brgy16button.Location = New System.Drawing.Point(30, 598)
        Me.brgy16button.Name = "brgy16button"
        Me.brgy16button.Size = New System.Drawing.Size(192, 118)
        Me.brgy16button.TabIndex = 37
        Me.brgy16button.UseVisualStyleBackColor = False
        '
        'brgy15button
        '
        Me.brgy15button.BackColor = System.Drawing.Color.Transparent
        Me.brgy15button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.brgy15button.FlatAppearance.BorderSize = 0
        Me.brgy15button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy15button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy15button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy15button.Image = CType(resources.GetObject("brgy15button.Image"), System.Drawing.Image)
        Me.brgy15button.Location = New System.Drawing.Point(845, 422)
        Me.brgy15button.Name = "brgy15button"
        Me.brgy15button.Size = New System.Drawing.Size(192, 118)
        Me.brgy15button.TabIndex = 36
        Me.brgy15button.UseVisualStyleBackColor = False
        '
        'brgy14button
        '
        Me.brgy14button.BackColor = System.Drawing.Color.Transparent
        Me.brgy14button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.brgy14button.FlatAppearance.BorderSize = 0
        Me.brgy14button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy14button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy14button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy14button.Image = CType(resources.GetObject("brgy14button.Image"), System.Drawing.Image)
        Me.brgy14button.Location = New System.Drawing.Point(639, 422)
        Me.brgy14button.Name = "brgy14button"
        Me.brgy14button.Size = New System.Drawing.Size(192, 118)
        Me.brgy14button.TabIndex = 35
        Me.brgy14button.UseVisualStyleBackColor = False
        '
        'brgy13button
        '
        Me.brgy13button.BackColor = System.Drawing.Color.Transparent
        Me.brgy13button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.brgy13button.FlatAppearance.BorderSize = 0
        Me.brgy13button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy13button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy13button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy13button.Image = CType(resources.GetObject("brgy13button.Image"), System.Drawing.Image)
        Me.brgy13button.Location = New System.Drawing.Point(435, 422)
        Me.brgy13button.Name = "brgy13button"
        Me.brgy13button.Size = New System.Drawing.Size(192, 118)
        Me.brgy13button.TabIndex = 34
        Me.brgy13button.UseVisualStyleBackColor = False
        '
        'brgy11button
        '
        Me.brgy11button.BackColor = System.Drawing.Color.Transparent
        Me.brgy11button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.brgy11button.FlatAppearance.BorderSize = 0
        Me.brgy11button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy11button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy11button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy11button.Image = CType(resources.GetObject("brgy11button.Image"), System.Drawing.Image)
        Me.brgy11button.Location = New System.Drawing.Point(30, 422)
        Me.brgy11button.Name = "brgy11button"
        Me.brgy11button.Size = New System.Drawing.Size(192, 118)
        Me.brgy11button.TabIndex = 32
        Me.brgy11button.UseVisualStyleBackColor = False
        '
        'brgy30button
        '
        Me.brgy30button.BackColor = System.Drawing.Color.Transparent
        Me.brgy30button.FlatAppearance.BorderSize = 0
        Me.brgy30button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy30button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy30button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy30button.Image = CType(resources.GetObject("brgy30button.Image"), System.Drawing.Image)
        Me.brgy30button.Location = New System.Drawing.Point(845, 978)
        Me.brgy30button.Name = "brgy30button"
        Me.brgy30button.Size = New System.Drawing.Size(192, 118)
        Me.brgy30button.TabIndex = 31
        Me.brgy30button.UseVisualStyleBackColor = False
        '
        'brgy22button
        '
        Me.brgy22button.BackColor = System.Drawing.Color.Transparent
        Me.brgy22button.FlatAppearance.BorderSize = 0
        Me.brgy22button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy22button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy22button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy22button.Image = CType(resources.GetObject("brgy22button.Image"), System.Drawing.Image)
        Me.brgy22button.Location = New System.Drawing.Point(233, 785)
        Me.brgy22button.Name = "brgy22button"
        Me.brgy22button.Size = New System.Drawing.Size(192, 118)
        Me.brgy22button.TabIndex = 23
        Me.brgy22button.UseVisualStyleBackColor = False
        '
        'brgy29button
        '
        Me.brgy29button.BackColor = System.Drawing.Color.Transparent
        Me.brgy29button.FlatAppearance.BorderSize = 0
        Me.brgy29button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy29button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy29button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy29button.Image = CType(resources.GetObject("brgy29button.Image"), System.Drawing.Image)
        Me.brgy29button.Location = New System.Drawing.Point(639, 978)
        Me.brgy29button.Name = "brgy29button"
        Me.brgy29button.Size = New System.Drawing.Size(192, 118)
        Me.brgy29button.TabIndex = 30
        Me.brgy29button.UseVisualStyleBackColor = False
        '
        'brgy28button
        '
        Me.brgy28button.BackColor = System.Drawing.Color.Transparent
        Me.brgy28button.FlatAppearance.BorderSize = 0
        Me.brgy28button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy28button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy28button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy28button.Image = CType(resources.GetObject("brgy28button.Image"), System.Drawing.Image)
        Me.brgy28button.Location = New System.Drawing.Point(435, 976)
        Me.brgy28button.Name = "brgy28button"
        Me.brgy28button.Size = New System.Drawing.Size(192, 118)
        Me.brgy28button.TabIndex = 29
        Me.brgy28button.UseVisualStyleBackColor = False
        '
        'brgy27button
        '
        Me.brgy27button.BackColor = System.Drawing.Color.Transparent
        Me.brgy27button.FlatAppearance.BorderSize = 0
        Me.brgy27button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy27button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy27button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy27button.Image = CType(resources.GetObject("brgy27button.Image"), System.Drawing.Image)
        Me.brgy27button.Location = New System.Drawing.Point(233, 978)
        Me.brgy27button.Name = "brgy27button"
        Me.brgy27button.Size = New System.Drawing.Size(192, 118)
        Me.brgy27button.TabIndex = 28
        Me.brgy27button.UseVisualStyleBackColor = False
        '
        'brgy26button
        '
        Me.brgy26button.BackColor = System.Drawing.Color.Transparent
        Me.brgy26button.FlatAppearance.BorderSize = 0
        Me.brgy26button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy26button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy26button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy26button.Image = CType(resources.GetObject("brgy26button.Image"), System.Drawing.Image)
        Me.brgy26button.Location = New System.Drawing.Point(30, 978)
        Me.brgy26button.Name = "brgy26button"
        Me.brgy26button.Size = New System.Drawing.Size(192, 118)
        Me.brgy26button.TabIndex = 27
        Me.brgy26button.UseVisualStyleBackColor = False
        '
        'brgy25button
        '
        Me.brgy25button.BackColor = System.Drawing.Color.Transparent
        Me.brgy25button.FlatAppearance.BorderSize = 0
        Me.brgy25button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy25button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy25button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy25button.Image = CType(resources.GetObject("brgy25button.Image"), System.Drawing.Image)
        Me.brgy25button.Location = New System.Drawing.Point(845, 785)
        Me.brgy25button.Name = "brgy25button"
        Me.brgy25button.Size = New System.Drawing.Size(192, 118)
        Me.brgy25button.TabIndex = 26
        Me.brgy25button.UseVisualStyleBackColor = False
        '
        'brgy24button
        '
        Me.brgy24button.BackColor = System.Drawing.Color.Transparent
        Me.brgy24button.FlatAppearance.BorderSize = 0
        Me.brgy24button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy24button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy24button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy24button.Image = CType(resources.GetObject("brgy24button.Image"), System.Drawing.Image)
        Me.brgy24button.Location = New System.Drawing.Point(639, 785)
        Me.brgy24button.Name = "brgy24button"
        Me.brgy24button.Size = New System.Drawing.Size(192, 118)
        Me.brgy24button.TabIndex = 25
        Me.brgy24button.UseVisualStyleBackColor = False
        '
        'brgy23button
        '
        Me.brgy23button.BackColor = System.Drawing.Color.Transparent
        Me.brgy23button.FlatAppearance.BorderSize = 0
        Me.brgy23button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy23button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy23button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy23button.Image = CType(resources.GetObject("brgy23button.Image"), System.Drawing.Image)
        Me.brgy23button.Location = New System.Drawing.Point(435, 785)
        Me.brgy23button.Name = "brgy23button"
        Me.brgy23button.Size = New System.Drawing.Size(192, 118)
        Me.brgy23button.TabIndex = 24
        Me.brgy23button.UseVisualStyleBackColor = False
        '
        'brgy21button
        '
        Me.brgy21button.BackColor = System.Drawing.Color.Transparent
        Me.brgy21button.FlatAppearance.BorderSize = 0
        Me.brgy21button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy21button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy21button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy21button.Image = CType(resources.GetObject("brgy21button.Image"), System.Drawing.Image)
        Me.brgy21button.Location = New System.Drawing.Point(30, 785)
        Me.brgy21button.Name = "brgy21button"
        Me.brgy21button.Size = New System.Drawing.Size(192, 118)
        Me.brgy21button.TabIndex = 22
        Me.brgy21button.UseVisualStyleBackColor = False
        '
        'brgy32button
        '
        Me.brgy32button.BackColor = System.Drawing.Color.Transparent
        Me.brgy32button.FlatAppearance.BorderSize = 0
        Me.brgy32button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy32button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy32button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy32button.Image = CType(resources.GetObject("brgy32button.Image"), System.Drawing.Image)
        Me.brgy32button.Location = New System.Drawing.Point(233, 1167)
        Me.brgy32button.Name = "brgy32button"
        Me.brgy32button.Size = New System.Drawing.Size(192, 118)
        Me.brgy32button.TabIndex = 14
        Me.brgy32button.UseVisualStyleBackColor = False
        '
        'brgy39button
        '
        Me.brgy39button.BackColor = System.Drawing.Color.Transparent
        Me.brgy39button.FlatAppearance.BorderSize = 0
        Me.brgy39button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy39button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy39button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy39button.Image = CType(resources.GetObject("brgy39button.Image"), System.Drawing.Image)
        Me.brgy39button.Location = New System.Drawing.Point(657, 1345)
        Me.brgy39button.Name = "brgy39button"
        Me.brgy39button.Size = New System.Drawing.Size(192, 118)
        Me.brgy39button.TabIndex = 21
        Me.brgy39button.UseVisualStyleBackColor = False
        '
        'brgy38button
        '
        Me.brgy38button.BackColor = System.Drawing.Color.Transparent
        Me.brgy38button.FlatAppearance.BorderSize = 0
        Me.brgy38button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy38button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy38button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy38button.Image = CType(resources.GetObject("brgy38button.Image"), System.Drawing.Image)
        Me.brgy38button.Location = New System.Drawing.Point(435, 1346)
        Me.brgy38button.Name = "brgy38button"
        Me.brgy38button.Size = New System.Drawing.Size(192, 118)
        Me.brgy38button.TabIndex = 20
        Me.brgy38button.UseVisualStyleBackColor = False
        '
        'brgy37button
        '
        Me.brgy37button.BackColor = System.Drawing.Color.Transparent
        Me.brgy37button.FlatAppearance.BorderSize = 0
        Me.brgy37button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy37button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy37button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy37button.Image = CType(resources.GetObject("brgy37button.Image"), System.Drawing.Image)
        Me.brgy37button.Location = New System.Drawing.Point(233, 1352)
        Me.brgy37button.Name = "brgy37button"
        Me.brgy37button.Size = New System.Drawing.Size(192, 118)
        Me.brgy37button.TabIndex = 19
        Me.brgy37button.UseVisualStyleBackColor = False
        '
        'brgy36button
        '
        Me.brgy36button.BackColor = System.Drawing.Color.Transparent
        Me.brgy36button.FlatAppearance.BorderSize = 0
        Me.brgy36button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy36button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy36button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy36button.Image = CType(resources.GetObject("brgy36button.Image"), System.Drawing.Image)
        Me.brgy36button.Location = New System.Drawing.Point(30, 1350)
        Me.brgy36button.Name = "brgy36button"
        Me.brgy36button.Size = New System.Drawing.Size(192, 118)
        Me.brgy36button.TabIndex = 18
        Me.brgy36button.UseVisualStyleBackColor = False
        '
        'brgy35button
        '
        Me.brgy35button.BackColor = System.Drawing.Color.Transparent
        Me.brgy35button.FlatAppearance.BorderSize = 0
        Me.brgy35button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy35button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy35button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy35button.Image = CType(resources.GetObject("brgy35button.Image"), System.Drawing.Image)
        Me.brgy35button.Location = New System.Drawing.Point(843, 1169)
        Me.brgy35button.Name = "brgy35button"
        Me.brgy35button.Size = New System.Drawing.Size(192, 118)
        Me.brgy35button.TabIndex = 17
        Me.brgy35button.UseVisualStyleBackColor = False
        '
        'brgy33button
        '
        Me.brgy33button.BackColor = System.Drawing.Color.Transparent
        Me.brgy33button.FlatAppearance.BorderSize = 0
        Me.brgy33button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy33button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy33button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy33button.Image = CType(resources.GetObject("brgy33button.Image"), System.Drawing.Image)
        Me.brgy33button.Location = New System.Drawing.Point(651, 1169)
        Me.brgy33button.Name = "brgy33button"
        Me.brgy33button.Size = New System.Drawing.Size(192, 118)
        Me.brgy33button.TabIndex = 16
        Me.brgy33button.UseVisualStyleBackColor = False
        '
        'brgy34button
        '
        Me.brgy34button.BackColor = System.Drawing.Color.Transparent
        Me.brgy34button.FlatAppearance.BorderSize = 0
        Me.brgy34button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy34button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy34button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy34button.Image = CType(resources.GetObject("brgy34button.Image"), System.Drawing.Image)
        Me.brgy34button.Location = New System.Drawing.Point(435, 1169)
        Me.brgy34button.Name = "brgy34button"
        Me.brgy34button.Size = New System.Drawing.Size(192, 118)
        Me.brgy34button.TabIndex = 15
        Me.brgy34button.UseVisualStyleBackColor = False
        '
        'brgy31button
        '
        Me.brgy31button.BackColor = System.Drawing.Color.Transparent
        Me.brgy31button.FlatAppearance.BorderSize = 0
        Me.brgy31button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy31button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy31button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy31button.Image = CType(resources.GetObject("brgy31button.Image"), System.Drawing.Image)
        Me.brgy31button.Location = New System.Drawing.Point(30, 1166)
        Me.brgy31button.Name = "brgy31button"
        Me.brgy31button.Size = New System.Drawing.Size(192, 118)
        Me.brgy31button.TabIndex = 13
        Me.brgy31button.UseVisualStyleBackColor = False
        '
        'brgy10button
        '
        Me.brgy10button.BackColor = System.Drawing.Color.Transparent
        Me.brgy10button.FlatAppearance.BorderSize = 0
        Me.brgy10button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy10button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy10button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy10button.Image = CType(resources.GetObject("brgy10button.Image"), System.Drawing.Image)
        Me.brgy10button.Location = New System.Drawing.Point(845, 247)
        Me.brgy10button.Name = "brgy10button"
        Me.brgy10button.Size = New System.Drawing.Size(192, 118)
        Me.brgy10button.TabIndex = 12
        Me.brgy10button.UseVisualStyleBackColor = False
        '
        'brgy2button
        '
        Me.brgy2button.BackColor = System.Drawing.Color.Transparent
        Me.brgy2button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.brgy2button.FlatAppearance.BorderSize = 0
        Me.brgy2button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy2button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy2button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy2button.Image = CType(resources.GetObject("brgy2button.Image"), System.Drawing.Image)
        Me.brgy2button.Location = New System.Drawing.Point(233, 70)
        Me.brgy2button.Name = "brgy2button"
        Me.brgy2button.Size = New System.Drawing.Size(192, 118)
        Me.brgy2button.TabIndex = 4
        Me.brgy2button.UseVisualStyleBackColor = False
        '
        'brgy9button
        '
        Me.brgy9button.BackColor = System.Drawing.Color.Transparent
        Me.brgy9button.FlatAppearance.BorderSize = 0
        Me.brgy9button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy9button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy9button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy9button.Image = CType(resources.GetObject("brgy9button.Image"), System.Drawing.Image)
        Me.brgy9button.Location = New System.Drawing.Point(639, 247)
        Me.brgy9button.Name = "brgy9button"
        Me.brgy9button.Size = New System.Drawing.Size(192, 118)
        Me.brgy9button.TabIndex = 11
        Me.brgy9button.UseVisualStyleBackColor = False
        '
        'brgy8button
        '
        Me.brgy8button.BackColor = System.Drawing.Color.Transparent
        Me.brgy8button.FlatAppearance.BorderSize = 0
        Me.brgy8button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy8button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy8button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy8button.Image = CType(resources.GetObject("brgy8button.Image"), System.Drawing.Image)
        Me.brgy8button.Location = New System.Drawing.Point(435, 247)
        Me.brgy8button.Name = "brgy8button"
        Me.brgy8button.Size = New System.Drawing.Size(192, 118)
        Me.brgy8button.TabIndex = 10
        Me.brgy8button.UseVisualStyleBackColor = False
        '
        'brgy7button
        '
        Me.brgy7button.BackColor = System.Drawing.Color.Transparent
        Me.brgy7button.FlatAppearance.BorderSize = 0
        Me.brgy7button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy7button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy7button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy7button.Image = CType(resources.GetObject("brgy7button.Image"), System.Drawing.Image)
        Me.brgy7button.Location = New System.Drawing.Point(233, 247)
        Me.brgy7button.Name = "brgy7button"
        Me.brgy7button.Size = New System.Drawing.Size(192, 118)
        Me.brgy7button.TabIndex = 9
        Me.brgy7button.UseVisualStyleBackColor = False
        '
        'brgy6button
        '
        Me.brgy6button.BackColor = System.Drawing.Color.Transparent
        Me.brgy6button.FlatAppearance.BorderSize = 0
        Me.brgy6button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy6button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy6button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy6button.Image = CType(resources.GetObject("brgy6button.Image"), System.Drawing.Image)
        Me.brgy6button.Location = New System.Drawing.Point(30, 247)
        Me.brgy6button.Name = "brgy6button"
        Me.brgy6button.Size = New System.Drawing.Size(192, 118)
        Me.brgy6button.TabIndex = 8
        Me.brgy6button.UseVisualStyleBackColor = False
        '
        'brgy5button
        '
        Me.brgy5button.BackColor = System.Drawing.Color.Transparent
        Me.brgy5button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.brgy5button.FlatAppearance.BorderSize = 0
        Me.brgy5button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy5button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy5button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy5button.Image = CType(resources.GetObject("brgy5button.Image"), System.Drawing.Image)
        Me.brgy5button.Location = New System.Drawing.Point(845, 70)
        Me.brgy5button.Name = "brgy5button"
        Me.brgy5button.Size = New System.Drawing.Size(192, 118)
        Me.brgy5button.TabIndex = 7
        Me.brgy5button.UseVisualStyleBackColor = False
        '
        'brgy4button
        '
        Me.brgy4button.BackColor = System.Drawing.Color.Transparent
        Me.brgy4button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.brgy4button.FlatAppearance.BorderSize = 0
        Me.brgy4button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy4button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy4button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy4button.Image = CType(resources.GetObject("brgy4button.Image"), System.Drawing.Image)
        Me.brgy4button.Location = New System.Drawing.Point(639, 70)
        Me.brgy4button.Name = "brgy4button"
        Me.brgy4button.Size = New System.Drawing.Size(192, 118)
        Me.brgy4button.TabIndex = 6
        Me.brgy4button.UseVisualStyleBackColor = False
        '
        'brgy3button
        '
        Me.brgy3button.BackColor = System.Drawing.Color.Transparent
        Me.brgy3button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.brgy3button.FlatAppearance.BorderSize = 0
        Me.brgy3button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy3button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.brgy3button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy3button.Image = CType(resources.GetObject("brgy3button.Image"), System.Drawing.Image)
        Me.brgy3button.Location = New System.Drawing.Point(435, 70)
        Me.brgy3button.Name = "brgy3button"
        Me.brgy3button.Size = New System.Drawing.Size(192, 118)
        Me.brgy3button.TabIndex = 5
        Me.brgy3button.UseVisualStyleBackColor = False
        '
        'brgy1button
        '
        Me.brgy1button.BackColor = System.Drawing.Color.Transparent
        Me.brgy1button.FlatAppearance.BorderSize = 0
        Me.brgy1button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.brgy1button.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.brgy1button.ForeColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.brgy1button.Image = CType(resources.GetObject("brgy1button.Image"), System.Drawing.Image)
        Me.brgy1button.Location = New System.Drawing.Point(30, 70)
        Me.brgy1button.Name = "brgy1button"
        Me.brgy1button.Size = New System.Drawing.Size(192, 118)
        Me.brgy1button.TabIndex = 0
        Me.brgy1button.UseVisualStyleBackColor = False
        '
        'panelAboutUs
        '
        Me.panelAboutUs.BackColor = System.Drawing.Color.LightSteelBlue
        Me.panelAboutUs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.panelAboutUs.Controls.Add(Me.LinkLabel1)
        Me.panelAboutUs.Controls.Add(Me.Label8)
        Me.panelAboutUs.Controls.Add(Me.PictureBox14)
        Me.panelAboutUs.Controls.Add(Me.PictureBox5)
        Me.panelAboutUs.Controls.Add(Me.PictureBox4)
        Me.panelAboutUs.Controls.Add(Me.Panel12)
        Me.panelAboutUs.Controls.Add(Me.Panel4)
        Me.panelAboutUs.Controls.Add(Me.Label57)
        Me.panelAboutUs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelAboutUs.Location = New System.Drawing.Point(281, 0)
        Me.panelAboutUs.Name = "panelAboutUs"
        Me.panelAboutUs.Size = New System.Drawing.Size(1091, 751)
        Me.panelAboutUs.TabIndex = 9
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Black
        Me.LinkLabel1.Location = New System.Drawing.Point(477, 704)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(129, 21)
        Me.LinkLabel1.TabIndex = 23
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "+639516474863"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI Black", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(470, 618)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(134, 25)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "CONTACT US"
        '
        'PictureBox14
        '
        Me.PictureBox14.BackgroundImage = CType(resources.GetObject("PictureBox14.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox14.Location = New System.Drawing.Point(477, 657)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(38, 39)
        Me.PictureBox14.TabIndex = 21
        Me.PictureBox14.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = CType(resources.GetObject("PictureBox5.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox5.Location = New System.Drawing.Point(565, 657)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(38, 39)
        Me.PictureBox5.TabIndex = 20
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox4.Location = New System.Drawing.Point(521, 657)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(38, 39)
        Me.PictureBox4.TabIndex = 17
        Me.PictureBox4.TabStop = False
        '
        'Panel12
        '
        Me.Panel12.BackgroundImage = CType(resources.GetObject("Panel12.BackgroundImage"), System.Drawing.Image)
        Me.Panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel12.Location = New System.Drawing.Point(69, 134)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(949, 442)
        Me.Panel12.TabIndex = 12
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel4.Controls.Add(Me.Label6)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1091, 48)
        Me.Panel4.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label6.Location = New System.Drawing.Point(35, 5)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(157, 37)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "ABOUT US"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.BackColor = System.Drawing.Color.Transparent
        Me.Label57.Font = New System.Drawing.Font("Segoe UI Black", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(29, 271)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(0, 40)
        Me.Label57.TabIndex = 2
        '
        'PanelMonthlyReport
        '
        Me.PanelMonthlyReport.BackColor = System.Drawing.Color.LightSteelBlue
        Me.PanelMonthlyReport.Controls.Add(Me.Panel10)
        Me.PanelMonthlyReport.Controls.Add(Me.Panel5)
        Me.PanelMonthlyReport.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelMonthlyReport.Location = New System.Drawing.Point(281, 0)
        Me.PanelMonthlyReport.Name = "PanelMonthlyReport"
        Me.PanelMonthlyReport.Size = New System.Drawing.Size(1091, 751)
        Me.PanelMonthlyReport.TabIndex = 10
        '
        'Panel10
        '
        Me.Panel10.AutoScrollMargin = New System.Drawing.Size(0, 100)
        Me.Panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel10.Controls.Add(Me.Label32)
        Me.Panel10.Controls.Add(Me.ComboBox3)
        Me.Panel10.Controls.Add(Me.Button11)
        Me.Panel10.Controls.Add(Me.Label2)
        Me.Panel10.Controls.Add(Me.TextBox2)
        Me.Panel10.Controls.Add(Me.DataGridView1)
        Me.Panel10.Controls.Add(Me.Label18)
        Me.Panel10.Controls.Add(Me.Button60)
        Me.Panel10.Controls.Add(Me.Button49)
        Me.Panel10.Controls.Add(Me.Button47)
        Me.Panel10.Controls.Add(Me.TextBox1)
        Me.Panel10.Controls.Add(Me.Button59)
        Me.Panel10.Location = New System.Drawing.Point(53, 52)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(997, 675)
        Me.Panel10.TabIndex = 4
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(24, 598)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(78, 21)
        Me.Label32.TabIndex = 16
        Me.Label32.Text = "SORT BY:"
        '
        'ComboBox3
        '
        Me.ComboBox3.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"Name", "Barangay", "File", "Status", "Date Upload", "Approved Date"})
        Me.ComboBox3.Location = New System.Drawing.Point(28, 623)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(181, 29)
        Me.ComboBox3.TabIndex = 15
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Image = CType(resources.GetObject("Button11.Image"), System.Drawing.Image)
        Me.Button11.Location = New System.Drawing.Point(762, 231)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(204, 63)
        Me.Button11.TabIndex = 14
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(223, 599)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 21)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "SEARCH:"
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(220, 623)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(266, 29)
        Me.TextBox2.TabIndex = 11
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        DataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle46.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle46.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle46.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle46.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle46
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column5, Me.Column17, Me.Column1, Me.Column3, Me.Column4, Me.Column2, Me.Column15})
        DataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle47.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle47
        Me.DataGridView1.Location = New System.Drawing.Point(28, 75)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(717, 505)
        Me.DataGridView1.TabIndex = 10
        '
        'Column5
        '
        Me.Column5.HeaderText = "report ID"
        Me.Column5.Name = "Column5"
        Me.Column5.Visible = False
        '
        'Column17
        '
        Me.Column17.HeaderText = "Name"
        Me.Column17.Name = "Column17"
        Me.Column17.Width = 110
        '
        'Column1
        '
        Me.Column1.HeaderText = "Barangay"
        Me.Column1.Name = "Column1"
        '
        'Column3
        '
        Me.Column3.HeaderText = "File"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "Status"
        Me.Column4.Name = "Column4"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Date Upload"
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 150
        '
        'Column15
        '
        Me.Column15.HeaderText = "Approved Date"
        Me.Column15.Name = "Column15"
        Me.Column15.Width = 150
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Label18.Location = New System.Drawing.Point(34, 26)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(113, 30)
        Me.Label18.TabIndex = 9
        Me.Label18.Text = "File name:"
        '
        'Button60
        '
        Me.Button60.BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.Button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button60.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button60.Image = CType(resources.GetObject("Button60.Image"), System.Drawing.Image)
        Me.Button60.Location = New System.Drawing.Point(762, 153)
        Me.Button60.Name = "Button60"
        Me.Button60.Size = New System.Drawing.Size(204, 63)
        Me.Button60.TabIndex = 6
        Me.Button60.UseVisualStyleBackColor = False
        '
        'Button49
        '
        Me.Button49.BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.Button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button49.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button49.Image = CType(resources.GetObject("Button49.Image"), System.Drawing.Image)
        Me.Button49.Location = New System.Drawing.Point(867, 15)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(99, 39)
        Me.Button49.TabIndex = 2
        Me.Button49.UseVisualStyleBackColor = False
        '
        'Button47
        '
        Me.Button47.BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.Button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button47.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button47.Image = CType(resources.GetObject("Button47.Image"), System.Drawing.Image)
        Me.Button47.Location = New System.Drawing.Point(762, 15)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(99, 39)
        Me.Button47.TabIndex = 0
        Me.Button47.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(153, 26)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(592, 29)
        Me.TextBox1.TabIndex = 1
        '
        'Button59
        '
        Me.Button59.BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.Button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button59.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button59.Image = CType(resources.GetObject("Button59.Image"), System.Drawing.Image)
        Me.Button59.Location = New System.Drawing.Point(762, 75)
        Me.Button59.Name = "Button59"
        Me.Button59.Size = New System.Drawing.Size(204, 63)
        Me.Button59.TabIndex = 4
        Me.Button59.UseVisualStyleBackColor = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel5.Controls.Add(Me.Label3)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1091, 48)
        Me.Panel5.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label3.Location = New System.Drawing.Point(35, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(266, 37)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "ANNUAL REPORTS"
        '
        'panelHistory
        '
        Me.panelHistory.AutoScroll = True
        Me.panelHistory.AutoScrollMargin = New System.Drawing.Size(0, 100)
        Me.panelHistory.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.panelHistory.Controls.Add(Me.Label107)
        Me.panelHistory.Controls.Add(Me.FlowLayoutPanel1)
        Me.panelHistory.Controls.Add(Me.Label12)
        Me.panelHistory.Controls.Add(Me.Label10)
        Me.panelHistory.Controls.Add(Me.Panel21)
        Me.panelHistory.Controls.Add(Me.Panel19)
        Me.panelHistory.Controls.Add(Me.Panel20)
        Me.panelHistory.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelHistory.Location = New System.Drawing.Point(281, 0)
        Me.panelHistory.Name = "panelHistory"
        Me.panelHistory.Size = New System.Drawing.Size(1091, 751)
        Me.panelHistory.TabIndex = 14
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.BackColor = System.Drawing.Color.Transparent
        Me.Label107.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.Location = New System.Drawing.Point(444, 1857)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(267, 37)
        Me.Label107.TabIndex = 6
        Me.Label107.Text = "HISTORICAL TRAIL"
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(106, 1901)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(895, 566)
        Me.FlowLayoutPanel1.TabIndex = 5
        Me.FlowLayoutPanel1.WrapContents = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(206, 1358)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(689, 37)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "SANGGUNIANG KABATAAN REFORM ACT OF 2015"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(469, 101)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(176, 37)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "VIGAN CITY"
        '
        'Panel21
        '
        Me.Panel21.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel21.Controls.Add(Me.Label13)
        Me.Panel21.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel21.Location = New System.Drawing.Point(0, 0)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(1074, 48)
        Me.Panel21.TabIndex = 4
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label13.Location = New System.Drawing.Point(35, 5)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(137, 37)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "HISTORY"
        '
        'Panel19
        '
        Me.Panel19.BackgroundImage = CType(resources.GetObject("Panel19.BackgroundImage"), System.Drawing.Image)
        Me.Panel19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel19.Location = New System.Drawing.Point(118, 138)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(852, 1112)
        Me.Panel19.TabIndex = 3
        '
        'Panel20
        '
        Me.Panel20.BackgroundImage = CType(resources.GetObject("Panel20.BackgroundImage"), System.Drawing.Image)
        Me.Panel20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel20.Location = New System.Drawing.Point(118, 1405)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(852, 279)
        Me.Panel20.TabIndex = 2
        '
        'PanelArchive
        '
        Me.PanelArchive.BackColor = System.Drawing.Color.LightSteelBlue
        Me.PanelArchive.Controls.Add(Me.Panel23)
        Me.PanelArchive.Controls.Add(Me.Panel22)
        Me.PanelArchive.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelArchive.Location = New System.Drawing.Point(281, 0)
        Me.PanelArchive.Name = "PanelArchive"
        Me.PanelArchive.Size = New System.Drawing.Size(1091, 751)
        Me.PanelArchive.TabIndex = 18
        '
        'Panel23
        '
        Me.Panel23.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel23.Controls.Add(Me.Label51)
        Me.Panel23.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel23.Location = New System.Drawing.Point(0, 0)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(1091, 48)
        Me.Panel23.TabIndex = 47
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.BackColor = System.Drawing.Color.Transparent
        Me.Label51.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label51.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label51.Location = New System.Drawing.Point(35, 5)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(137, 37)
        Me.Label51.TabIndex = 46
        Me.Label51.Text = "ARCHIVE"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.Label99)
        Me.Panel22.Controls.Add(Me.Button14)
        Me.Panel22.Controls.Add(Me.Label97)
        Me.Panel22.Controls.Add(Me.Button12)
        Me.Panel22.Controls.Add(Me.Label53)
        Me.Panel22.Controls.Add(Me.Label52)
        Me.Panel22.Controls.Add(Me.Button15)
        Me.Panel22.Controls.Add(Me.Button16)
        Me.Panel22.Location = New System.Drawing.Point(50, 68)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(985, 611)
        Me.Panel22.TabIndex = 46
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.Label99.Location = New System.Drawing.Point(641, 521)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(221, 25)
        Me.Label99.TabIndex = 55
        Me.Label99.Text = "Announcement Archive"
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.Transparent
        Me.Button14.FlatAppearance.BorderSize = 0
        Me.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button14.Image = CType(resources.GetObject("Button14.Image"), System.Drawing.Image)
        Me.Button14.Location = New System.Drawing.Point(620, 352)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(251, 161)
        Me.Button14.TabIndex = 54
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.Label97.Location = New System.Drawing.Point(192, 521)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(149, 25)
        Me.Label97.TabIndex = 53
        Me.Label97.Text = "Activity Archive"
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.Color.Transparent
        Me.Button12.FlatAppearance.BorderSize = 0
        Me.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button12.Image = CType(resources.GetObject("Button12.Image"), System.Drawing.Image)
        Me.Button12.Location = New System.Drawing.Point(137, 352)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(251, 161)
        Me.Button12.TabIndex = 52
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.Label53.Location = New System.Drawing.Point(710, 251)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(82, 25)
        Me.Label53.TabIndex = 51
        Me.Label53.Text = "Reports"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(159, 251)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(209, 25)
        Me.Label52.TabIndex = 50
        Me.Label52.Text = "Barangay Information"
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.Color.Transparent
        Me.Button15.FlatAppearance.BorderSize = 0
        Me.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button15.Image = CType(resources.GetObject("Button15.Image"), System.Drawing.Image)
        Me.Button15.Location = New System.Drawing.Point(620, 82)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(251, 161)
        Me.Button15.TabIndex = 48
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.Color.Transparent
        Me.Button16.FlatAppearance.BorderSize = 0
        Me.Button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button16.Image = CType(resources.GetObject("Button16.Image"), System.Drawing.Image)
        Me.Button16.Location = New System.Drawing.Point(137, 82)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(251, 161)
        Me.Button16.TabIndex = 47
        Me.Button16.UseVisualStyleBackColor = False
        '
        'PanelUserManagement
        '
        Me.PanelUserManagement.BackColor = System.Drawing.Color.LightSteelBlue
        Me.PanelUserManagement.Controls.Add(Me.GroupBox1)
        Me.PanelUserManagement.Controls.Add(Me.Label5)
        Me.PanelUserManagement.Controls.Add(Me.TextBox4)
        Me.PanelUserManagement.Controls.Add(Me.Button18)
        Me.PanelUserManagement.Controls.Add(Me.Button19)
        Me.PanelUserManagement.Controls.Add(Me.Button20)
        Me.PanelUserManagement.Controls.Add(Me.Button21)
        Me.PanelUserManagement.Controls.Add(Me.Button22)
        Me.PanelUserManagement.Controls.Add(Me.DataGridView3)
        Me.PanelUserManagement.Controls.Add(Me.Panel24)
        Me.PanelUserManagement.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelUserManagement.Location = New System.Drawing.Point(281, 0)
        Me.PanelUserManagement.Name = "PanelUserManagement"
        Me.PanelUserManagement.Size = New System.Drawing.Size(1091, 751)
        Me.PanelUserManagement.TabIndex = 53
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.TextBox3)
        Me.GroupBox1.Controls.Add(Me.TextBoxLname)
        Me.GroupBox1.Controls.Add(Me.TextBoxMname)
        Me.GroupBox1.Controls.Add(Me.Label79)
        Me.GroupBox1.Controls.Add(Me.Label78)
        Me.GroupBox1.Controls.Add(Me.Label77)
        Me.GroupBox1.Controls.Add(Me.TextBoxUsername)
        Me.GroupBox1.Controls.Add(Me.Label76)
        Me.GroupBox1.Controls.Add(Me.TextBoxPassword)
        Me.GroupBox1.Controls.Add(Me.TextBoxFname)
        Me.GroupBox1.Controls.Add(Me.TextBoxID)
        Me.GroupBox1.Controls.Add(Me.Label68)
        Me.GroupBox1.Controls.Add(Me.ComboBoxBarangay)
        Me.GroupBox1.Controls.Add(Me.ComboBoxUsertype)
        Me.GroupBox1.Controls.Add(Me.Label75)
        Me.GroupBox1.Controls.Add(Me.Label73)
        Me.GroupBox1.Controls.Add(Me.Label74)
        Me.GroupBox1.Location = New System.Drawing.Point(42, 60)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(987, 181)
        Me.GroupBox1.TabIndex = 97
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "User Management"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label15.Location = New System.Drawing.Point(73, 132)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(101, 21)
        Me.Label15.TabIndex = 89
        Me.Label15.Text = "Contact no.:"
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(185, 133)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(318, 27)
        Me.TextBox3.TabIndex = 88
        '
        'TextBoxLname
        '
        Me.TextBoxLname.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxLname.Location = New System.Drawing.Point(185, 75)
        Me.TextBoxLname.Name = "TextBoxLname"
        Me.TextBoxLname.Size = New System.Drawing.Size(318, 27)
        Me.TextBoxLname.TabIndex = 76
        '
        'TextBoxMname
        '
        Me.TextBoxMname.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMname.Location = New System.Drawing.Point(185, 104)
        Me.TextBoxMname.Name = "TextBoxMname"
        Me.TextBoxMname.Size = New System.Drawing.Size(318, 27)
        Me.TextBoxMname.TabIndex = 75
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label79.Location = New System.Drawing.Point(84, 75)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(91, 21)
        Me.Label79.TabIndex = 80
        Me.Label79.Text = "Last name:"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label78.Location = New System.Drawing.Point(82, 46)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(93, 21)
        Me.Label78.TabIndex = 79
        Me.Label78.Text = "First name:"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label77.Location = New System.Drawing.Point(60, 104)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(115, 21)
        Me.Label77.TabIndex = 81
        Me.Label77.Text = "Middle name:"
        '
        'TextBoxUsername
        '
        Me.TextBoxUsername.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxUsername.Location = New System.Drawing.Point(629, 21)
        Me.TextBoxUsername.Name = "TextBoxUsername"
        Me.TextBoxUsername.Size = New System.Drawing.Size(318, 27)
        Me.TextBoxUsername.TabIndex = 74
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label76.Location = New System.Drawing.Point(120, 17)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(55, 21)
        Me.Label76.TabIndex = 78
        Me.Label76.Text = "ID no."
        '
        'TextBoxPassword
        '
        Me.TextBoxPassword.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPassword.Location = New System.Drawing.Point(629, 50)
        Me.TextBoxPassword.Name = "TextBoxPassword"
        Me.TextBoxPassword.Size = New System.Drawing.Size(319, 27)
        Me.TextBoxPassword.TabIndex = 77
        Me.TextBoxPassword.UseSystemPasswordChar = True
        '
        'TextBoxFname
        '
        Me.TextBoxFname.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxFname.Location = New System.Drawing.Point(185, 46)
        Me.TextBoxFname.Name = "TextBoxFname"
        Me.TextBoxFname.Size = New System.Drawing.Size(318, 27)
        Me.TextBoxFname.TabIndex = 73
        '
        'TextBoxID
        '
        Me.TextBoxID.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxID.Location = New System.Drawing.Point(185, 17)
        Me.TextBoxID.MaxLength = 1010101010
        Me.TextBoxID.Name = "TextBoxID"
        Me.TextBoxID.Size = New System.Drawing.Size(318, 27)
        Me.TextBoxID.TabIndex = 72
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label68.Location = New System.Drawing.Point(531, 108)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(86, 21)
        Me.Label68.TabIndex = 87
        Me.Label68.Text = "Barangay:"
        '
        'ComboBoxBarangay
        '
        Me.ComboBoxBarangay.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!)
        Me.ComboBoxBarangay.FormattingEnabled = True
        Me.ComboBoxBarangay.Items.AddRange(New Object() {"Ayusan Norte", "Ayusan Sur", "Barangay 1", "Barangay 2", "Barangay 3", "Barangay 4", "Barangay 5", "Barangay 6", "Barangay 7", "Barangay 8", "Barangay 9", "Barraca", "Beddeng Daya", "Beddeng Laud", "Bongtolan", "Bulala", "Cabalangegan", "Cabaroan Daya", "Cabaroan Laud", "Camangaan", "Capangpangan", "Mindoro", "Nagsangalan", "Pantay Daya", "Pantay Fatima", "Pantay Laud", "Paoa", "Paratong", "Pong-ol", "Purok-a-bassit", "Purok-a-dackel", "Raois", "Rugsaunan", "Salindeg", "San Jose", "San Julian Norte", "San Julian Sur", "San Pedro", "Tamag"})
        Me.ComboBoxBarangay.Location = New System.Drawing.Point(629, 108)
        Me.ComboBoxBarangay.Name = "ComboBoxBarangay"
        Me.ComboBoxBarangay.Size = New System.Drawing.Size(320, 27)
        Me.ComboBoxBarangay.TabIndex = 82
        '
        'ComboBoxUsertype
        '
        Me.ComboBoxUsertype.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!)
        Me.ComboBoxUsertype.FormattingEnabled = True
        Me.ComboBoxUsertype.Items.AddRange(New Object() {"LYDO", "SK Federated", "SK Chairperson"})
        Me.ComboBoxUsertype.Location = New System.Drawing.Point(629, 79)
        Me.ComboBoxUsertype.Name = "ComboBoxUsertype"
        Me.ComboBoxUsertype.Size = New System.Drawing.Size(320, 27)
        Me.ComboBoxUsertype.TabIndex = 86
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label75.Location = New System.Drawing.Point(528, 21)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(91, 21)
        Me.Label75.TabIndex = 83
        Me.Label75.Text = "Username:"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label73.Location = New System.Drawing.Point(528, 79)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(89, 21)
        Me.Label73.TabIndex = 85
        Me.Label73.Text = "User Type:"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label74.Location = New System.Drawing.Point(533, 50)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(86, 21)
        Me.Label74.TabIndex = 84
        Me.Label74.Text = "Password:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(53, 322)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 21)
        Me.Label5.TabIndex = 94
        Me.Label5.Text = "SEARCH:"
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!)
        Me.TextBox4.Location = New System.Drawing.Point(134, 317)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(368, 27)
        Me.TextBox4.TabIndex = 93
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.Color.Transparent
        Me.Button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue
        Me.Button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.Button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button18.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.Image = CType(resources.GetObject("Button18.Image"), System.Drawing.Image)
        Me.Button18.Location = New System.Drawing.Point(701, 246)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(79, 47)
        Me.Button18.TabIndex = 92
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.Color.Transparent
        Me.Button19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue
        Me.Button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.Button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button19.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.Image = CType(resources.GetObject("Button19.Image"), System.Drawing.Image)
        Me.Button19.Location = New System.Drawing.Point(314, 247)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(79, 47)
        Me.Button19.TabIndex = 88
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.Color.Transparent
        Me.Button20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue
        Me.Button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.Button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button20.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.Image = CType(resources.GetObject("Button20.Image"), System.Drawing.Image)
        Me.Button20.Location = New System.Drawing.Point(410, 247)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(79, 47)
        Me.Button20.TabIndex = 89
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.Color.Transparent
        Me.Button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue
        Me.Button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.Button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button21.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.Image = CType(resources.GetObject("Button21.Image"), System.Drawing.Image)
        Me.Button21.Location = New System.Drawing.Point(603, 246)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(79, 47)
        Me.Button21.TabIndex = 90
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.Color.Transparent
        Me.Button22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue
        Me.Button22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.Button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button22.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.Image = CType(resources.GetObject("Button22.Image"), System.Drawing.Image)
        Me.Button22.Location = New System.Drawing.Point(505, 246)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(79, 47)
        Me.Button22.TabIndex = 91
        Me.Button22.UseVisualStyleBackColor = False
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowDrop = True
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToDeleteRows = False
        DataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView3.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle48
        Me.DataGridView3.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle49.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle49.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle49.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle49.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView3.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle49
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.Column16, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17})
        DataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle50.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle50.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle50.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle50.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle50.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView3.DefaultCellStyle = DataGridViewCellStyle50
        Me.DataGridView3.Location = New System.Drawing.Point(53, 350)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.ReadOnly = True
        DataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle51.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle51.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle51.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle51.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle51.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle51.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView3.RowHeadersDefaultCellStyle = DataGridViewCellStyle51
        Me.DataGridView3.RowHeadersVisible = False
        Me.DataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView3.Size = New System.Drawing.Size(965, 351)
        Me.DataGridView3.TabIndex = 71
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "Last name"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.HeaderText = "First name"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "Middle name"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        '
        'Column16
        '
        Me.Column16.HeaderText = "Contact No."
        Me.Column16.Name = "Column16"
        Me.Column16.ReadOnly = True
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.HeaderText = "Username"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "Password"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.Width = 120
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "User Type"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        Me.DataGridViewTextBoxColumn16.Width = 120
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "Barangay"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Width = 120
        '
        'Panel24
        '
        Me.Panel24.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel24.Controls.Add(Me.Label16)
        Me.Panel24.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel24.Location = New System.Drawing.Point(0, 0)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(1091, 48)
        Me.Panel24.TabIndex = 1
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label16.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label16.Location = New System.Drawing.Point(35, 5)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(298, 37)
        Me.Label16.TabIndex = 47
        Me.Label16.Text = "USER MANAGEMENT"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PanelArchive2
        '
        Me.PanelArchive2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.PanelArchive2.Controls.Add(Me.Label4)
        Me.PanelArchive2.Controls.Add(Me.Label90)
        Me.PanelArchive2.Controls.Add(Me.ComboBox1)
        Me.PanelArchive2.Controls.Add(Me.TextBoxSearch)
        Me.PanelArchive2.Controls.Add(Me.Button28)
        Me.PanelArchive2.Controls.Add(Me.infoarchiveDataGridView)
        Me.PanelArchive2.Controls.Add(Me.Panel26)
        Me.PanelArchive2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelArchive2.Location = New System.Drawing.Point(281, 0)
        Me.PanelArchive2.Name = "PanelArchive2"
        Me.PanelArchive2.Size = New System.Drawing.Size(1091, 751)
        Me.PanelArchive2.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(222, 652)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 21)
        Me.Label4.TabIndex = 55
        Me.Label4.Text = "SORT BY:"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(426, 651)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(75, 21)
        Me.Label90.TabIndex = 54
        Me.Label90.Text = "SEARCH:"
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!)
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"ID", "Last Name", "First Name", "Middle Name", "Gender", "Birthday", "Contact Number", "Email", "Civil Status", "Youth Age", "Youth Classification", "Educational Attainment", "Work Status", "Barangay"})
        Me.ComboBox1.Location = New System.Drawing.Point(226, 675)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(190, 27)
        Me.ComboBox1.TabIndex = 53
        '
        'TextBoxSearch
        '
        Me.TextBoxSearch.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSearch.Location = New System.Drawing.Point(432, 674)
        Me.TextBoxSearch.Name = "TextBoxSearch"
        Me.TextBoxSearch.Size = New System.Drawing.Size(424, 27)
        Me.TextBoxSearch.TabIndex = 52
        '
        'Button28
        '
        Me.Button28.BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.Button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button28.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button28.Image = CType(resources.GetObject("Button28.Image"), System.Drawing.Image)
        Me.Button28.Location = New System.Drawing.Point(95, 666)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(83, 39)
        Me.Button28.TabIndex = 48
        Me.Button28.UseVisualStyleBackColor = False
        '
        'infoarchiveDataGridView
        '
        Me.infoarchiveDataGridView.AllowDrop = True
        Me.infoarchiveDataGridView.AllowUserToAddRows = False
        Me.infoarchiveDataGridView.AllowUserToDeleteRows = False
        DataGridViewCellStyle52.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle52.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle52.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle52.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        Me.infoarchiveDataGridView.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle52
        Me.infoarchiveDataGridView.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle53.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle53.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle53.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle53.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle53.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.infoarchiveDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle53
        Me.infoarchiveDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.infoarchiveDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn18, Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10, Me.Column11, Me.Column12, Me.Column13, Me.Column14})
        DataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle54.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle54.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle54.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle54.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle54.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.infoarchiveDataGridView.DefaultCellStyle = DataGridViewCellStyle54
        Me.infoarchiveDataGridView.Location = New System.Drawing.Point(28, 84)
        Me.infoarchiveDataGridView.Name = "infoarchiveDataGridView"
        Me.infoarchiveDataGridView.ReadOnly = True
        DataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle55.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle55.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle55.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle55.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle55.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle55.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.infoarchiveDataGridView.RowHeadersDefaultCellStyle = DataGridViewCellStyle55
        Me.infoarchiveDataGridView.RowHeadersVisible = False
        Me.infoarchiveDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.infoarchiveDataGridView.Size = New System.Drawing.Size(1041, 564)
        Me.infoarchiveDataGridView.TabIndex = 45
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "Last name"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "First name"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "Middle name"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Gender"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        '
        'Column6
        '
        Me.Column6.HeaderText = "Birthday"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.HeaderText = "Contact No."
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'Column8
        '
        Me.Column8.HeaderText = "Email Address"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column9
        '
        Me.Column9.HeaderText = "Civil Status"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        '
        'Column10
        '
        Me.Column10.HeaderText = "Youth Age"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'Column11
        '
        Me.Column11.HeaderText = "Youth Classification"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        '
        'Column12
        '
        Me.Column12.HeaderText = "Educational Background"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        '
        'Column13
        '
        Me.Column13.HeaderText = "Work Status"
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        '
        'Column14
        '
        Me.Column14.HeaderText = "Barangay"
        Me.Column14.Name = "Column14"
        Me.Column14.ReadOnly = True
        '
        'Panel26
        '
        Me.Panel26.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel26.Controls.Add(Me.Label7)
        Me.Panel26.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel26.Location = New System.Drawing.Point(0, 0)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(1091, 48)
        Me.Panel26.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label7.Location = New System.Drawing.Point(35, 5)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(511, 37)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "BARANGAY INFORMATION ARCHIVE"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Timer2
        '
        '
        'PanelStat
        '
        Me.PanelStat.AutoScroll = True
        Me.PanelStat.AutoScrollMargin = New System.Drawing.Size(0, 20)
        Me.PanelStat.BackColor = System.Drawing.Color.LightSteelBlue
        Me.PanelStat.Controls.Add(Me.Panel11)
        Me.PanelStat.Controls.Add(Me.Panel9)
        Me.PanelStat.Controls.Add(Me.Panel7)
        Me.PanelStat.Controls.Add(Me.Button9)
        Me.PanelStat.Controls.Add(Me.Panel31)
        Me.PanelStat.Controls.Add(Me.Panel28)
        Me.PanelStat.Controls.Add(Me.Panel15)
        Me.PanelStat.Controls.Add(Me.Panel27)
        Me.PanelStat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelStat.Location = New System.Drawing.Point(281, 0)
        Me.PanelStat.Name = "PanelStat"
        Me.PanelStat.Size = New System.Drawing.Size(1091, 751)
        Me.PanelStat.TabIndex = 2
        '
        'Panel11
        '
        Me.Panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel11.Controls.Add(Me.Label96)
        Me.Panel11.Controls.Add(Me.Label94)
        Me.Panel11.Controls.Add(Me.Chart6)
        Me.Panel11.Location = New System.Drawing.Point(10, 476)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(544, 215)
        Me.Panel11.TabIndex = 23
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label96.Location = New System.Drawing.Point(319, 190)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(44, 17)
        Me.Label96.TabIndex = 16
        Me.Label96.Text = "Total: "
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label94.Location = New System.Drawing.Point(167, 5)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(212, 21)
        Me.Label94.TabIndex = 15
        Me.Label94.Text = "Percentage of Work Status"
        '
        'Chart6
        '
        Me.Chart6.BackColor = System.Drawing.Color.Transparent
        Me.Chart6.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart6.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea19.Area3DStyle.Enable3D = True
        ChartArea19.BackColor = System.Drawing.Color.Transparent
        ChartArea19.Name = "ChartArea1"
        Me.Chart6.ChartAreas.Add(ChartArea19)
        Legend19.BackColor = System.Drawing.Color.Transparent
        Legend19.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend19.IsTextAutoFit = False
        Legend19.Name = "Legend1"
        Me.Chart6.Legends.Add(Legend19)
        Me.Chart6.Location = New System.Drawing.Point(26, 33)
        Me.Chart6.Name = "Chart6"
        Me.Chart6.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart6.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.Bisque, System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series19.ChartArea = "ChartArea1"
        Series19.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut
        Series19.Legend = "Legend1"
        Series19.Name = "Series1"
        Series19.YValuesPerPoint = 4
        Me.Chart6.Series.Add(Series19)
        Me.Chart6.Size = New System.Drawing.Size(509, 169)
        Me.Chart6.TabIndex = 10
        Me.Chart6.Text = "Chart6"
        '
        'Panel9
        '
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel9.Controls.Add(Me.Label93)
        Me.Panel9.Controls.Add(Me.Label31)
        Me.Panel9.Controls.Add(Me.Chart3)
        Me.Panel9.Location = New System.Drawing.Point(10, 249)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(544, 221)
        Me.Panel9.TabIndex = 22
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.Location = New System.Drawing.Point(164, 4)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(199, 21)
        Me.Label93.TabIndex = 14
        Me.Label93.Text = "Percentage of Youth Age"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label31.Location = New System.Drawing.Point(311, 192)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(44, 17)
        Me.Label31.TabIndex = 12
        Me.Label31.Text = "Total: "
        '
        'Chart3
        '
        Me.Chart3.BackColor = System.Drawing.Color.Transparent
        Me.Chart3.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart3.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea20.Area3DStyle.Enable3D = True
        ChartArea20.BackColor = System.Drawing.Color.Transparent
        ChartArea20.Name = "ChartArea1"
        Me.Chart3.ChartAreas.Add(ChartArea20)
        Legend20.BackColor = System.Drawing.Color.Transparent
        Legend20.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend20.IsTextAutoFit = False
        Legend20.Name = "Legend1"
        Me.Chart3.Legends.Add(Legend20)
        Me.Chart3.Location = New System.Drawing.Point(14, 33)
        Me.Chart3.Name = "Chart3"
        Me.Chart3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart3.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.Bisque, System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series20.ChartArea = "ChartArea1"
        Series20.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pyramid
        Series20.Legend = "Legend1"
        Series20.Name = "Series1"
        Me.Chart3.Series.Add(Series20)
        Me.Chart3.Size = New System.Drawing.Size(521, 144)
        Me.Chart3.TabIndex = 7
        Me.Chart3.Text = "Chart3"
        '
        'Panel7
        '
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.Label91)
        Me.Panel7.Controls.Add(Me.Chart4)
        Me.Panel7.Controls.Add(Me.Label27)
        Me.Panel7.Location = New System.Drawing.Point(10, 56)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(545, 187)
        Me.Panel7.TabIndex = 21
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(117, 5)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(271, 21)
        Me.Label91.TabIndex = 14
        Me.Label91.Text = "Percentage of Youth Classification"
        '
        'Chart4
        '
        Me.Chart4.BackColor = System.Drawing.Color.Transparent
        Me.Chart4.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart4.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea21.Area3DStyle.Enable3D = True
        ChartArea21.BackColor = System.Drawing.Color.Transparent
        ChartArea21.Name = "ChartArea1"
        Me.Chart4.ChartAreas.Add(ChartArea21)
        Legend21.BackColor = System.Drawing.Color.Transparent
        Legend21.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend21.IsTextAutoFit = False
        Legend21.Name = "Legend1"
        Me.Chart4.Legends.Add(Legend21)
        Me.Chart4.Location = New System.Drawing.Point(10, 34)
        Me.Chart4.Name = "Chart4"
        Me.Chart4.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart4.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.Bisque, System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series21.ChartArea = "ChartArea1"
        Series21.Legend = "Legend1"
        Series21.Name = "Series1"
        Series21.YValuesPerPoint = 4
        Me.Chart4.Series.Add(Series21)
        Me.Chart4.Size = New System.Drawing.Size(524, 116)
        Me.Chart4.TabIndex = 8
        Me.Chart4.Text = "Chart4"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label27.Location = New System.Drawing.Point(311, 165)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(44, 17)
        Me.Label27.TabIndex = 12
        Me.Label27.Text = "Total: "
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.Transparent
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(477, 700)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(161, 44)
        Me.Button9.TabIndex = 20
        Me.Button9.Text = "View Statistical Archive"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Panel31
        '
        Me.Panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel31.Controls.Add(Me.Label54)
        Me.Panel31.Controls.Add(Me.Label84)
        Me.Panel31.Controls.Add(Me.Label25)
        Me.Panel31.Controls.Add(Me.Chart2)
        Me.Panel31.Location = New System.Drawing.Point(560, 249)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(509, 222)
        Me.Panel31.TabIndex = 19
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(798, -52)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(184, 21)
        Me.Label54.TabIndex = 12
        Me.Label54.Text = "Percenatage of Gender"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(158, 7)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(205, 21)
        Me.Label84.TabIndex = 13
        Me.Label84.Text = "Percentage of Civil Status"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label25.Location = New System.Drawing.Point(252, 200)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(44, 17)
        Me.Label25.TabIndex = 11
        Me.Label25.Text = "Total: "
        '
        'Chart2
        '
        Me.Chart2.BackColor = System.Drawing.Color.Transparent
        Me.Chart2.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart2.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea22.Area3DStyle.Enable3D = True
        ChartArea22.BackColor = System.Drawing.Color.Transparent
        ChartArea22.Name = "ChartArea1"
        Me.Chart2.ChartAreas.Add(ChartArea22)
        Legend22.BackColor = System.Drawing.Color.Transparent
        Legend22.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend22.IsTextAutoFit = False
        Legend22.Name = "Legend1"
        Me.Chart2.Legends.Add(Legend22)
        Me.Chart2.Location = New System.Drawing.Point(22, 29)
        Me.Chart2.Name = "Chart2"
        Me.Chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart2.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series22.ChartArea = "ChartArea1"
        Series22.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie
        Series22.Legend = "Legend1"
        Series22.Name = "Series1"
        Me.Chart2.Series.Add(Series22)
        Me.Chart2.Size = New System.Drawing.Size(463, 161)
        Me.Chart2.TabIndex = 6
        Me.Chart2.Text = "Chart2"
        '
        'Panel28
        '
        Me.Panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel28.Controls.Add(Me.Label95)
        Me.Panel28.Controls.Add(Me.Label30)
        Me.Panel28.Controls.Add(Me.Chart5)
        Me.Panel28.Location = New System.Drawing.Point(560, 476)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(509, 214)
        Me.Panel28.TabIndex = 19
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(129, 5)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(302, 21)
        Me.Label95.TabIndex = 16
        Me.Label95.Text = "Percentage of Educational Attainment"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label30.Location = New System.Drawing.Point(307, 188)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(44, 17)
        Me.Label30.TabIndex = 11
        Me.Label30.Text = "Total: "
        '
        'Chart5
        '
        Me.Chart5.BackColor = System.Drawing.Color.Transparent
        Me.Chart5.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart5.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea23.Area3DStyle.Enable3D = True
        ChartArea23.BackColor = System.Drawing.Color.Transparent
        ChartArea23.Name = "ChartArea1"
        Me.Chart5.ChartAreas.Add(ChartArea23)
        Legend23.BackColor = System.Drawing.Color.Transparent
        Legend23.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend23.IsTextAutoFit = False
        Legend23.LegendItemOrder = System.Windows.Forms.DataVisualization.Charting.LegendItemOrder.ReversedSeriesOrder
        Legend23.Name = "Legend1"
        Me.Chart5.Legends.Add(Legend23)
        Me.Chart5.Location = New System.Drawing.Point(22, 33)
        Me.Chart5.Name = "Chart5"
        Me.Chart5.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart5.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series23.ChartArea = "ChartArea1"
        Series23.Legend = "Legend1"
        Series23.Name = "Series1"
        Me.Chart5.Series.Add(Series23)
        Me.Chart5.Size = New System.Drawing.Size(474, 166)
        Me.Chart5.TabIndex = 9
        Me.Chart5.Text = "Chart5"
        '
        'Panel15
        '
        Me.Panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel15.Controls.Add(Me.Label33)
        Me.Panel15.Controls.Add(Me.Label24)
        Me.Panel15.Controls.Add(Me.Label9)
        Me.Panel15.Controls.Add(Me.Chart1)
        Me.Panel15.Location = New System.Drawing.Point(560, 56)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(509, 186)
        Me.Panel15.TabIndex = 18
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(170, 6)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(175, 21)
        Me.Label33.TabIndex = 11
        Me.Label33.Text = "Percentage of Gender"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label24.Location = New System.Drawing.Point(896, 152)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(44, 17)
        Me.Label24.TabIndex = 10
        Me.Label24.Text = "Total: "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(237, 164)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(44, 17)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Total: "
        '
        'Chart1
        '
        Me.Chart1.BackColor = System.Drawing.Color.Transparent
        Me.Chart1.BorderlineColor = System.Drawing.Color.Transparent
        Me.Chart1.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea24.Area3DStyle.Enable3D = True
        ChartArea24.BackColor = System.Drawing.Color.Transparent
        ChartArea24.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea24)
        Legend24.BackColor = System.Drawing.Color.Transparent
        Legend24.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend24.IsTextAutoFit = False
        Legend24.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend24)
        Me.Chart1.Location = New System.Drawing.Point(18, 33)
        Me.Chart1.Name = "Chart1"
        Me.Chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.Chart1.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.Bisque, System.Drawing.Color.LightSlateGray, System.Drawing.Color.Linen, System.Drawing.Color.SlateGray, System.Drawing.Color.LightBlue, System.Drawing.Color.PapayaWhip}
        Series24.ChartArea = "ChartArea1"
        Series24.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut
        Series24.Legend = "Legend1"
        Series24.Name = "Series1"
        Me.Chart1.Series.Add(Series24)
        Me.Chart1.Size = New System.Drawing.Size(478, 140)
        Me.Chart1.TabIndex = 2
        Me.Chart1.Text = "Chart1"
        '
        'Panel27
        '
        Me.Panel27.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel27.Controls.Add(Me.Label87)
        Me.Panel27.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel27.Location = New System.Drawing.Point(0, 0)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(1074, 48)
        Me.Panel27.TabIndex = 1
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.BackColor = System.Drawing.Color.Transparent
        Me.Label87.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label87.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label87.Location = New System.Drawing.Point(35, 5)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(283, 37)
        Me.Label87.TabIndex = 1
        Me.Label87.Text = "STATISTIC REPORTS"
        '
        'panelReportArchive
        '
        Me.panelReportArchive.BackColor = System.Drawing.Color.LightSteelBlue
        Me.panelReportArchive.Controls.Add(Me.Button29)
        Me.panelReportArchive.Controls.Add(Me.DataGridView2)
        Me.panelReportArchive.Controls.Add(Me.Label88)
        Me.panelReportArchive.Controls.Add(Me.TextBox9)
        Me.panelReportArchive.Controls.Add(Me.Panel29)
        Me.panelReportArchive.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelReportArchive.Location = New System.Drawing.Point(281, 0)
        Me.panelReportArchive.Name = "panelReportArchive"
        Me.panelReportArchive.Size = New System.Drawing.Size(1091, 751)
        Me.panelReportArchive.TabIndex = 54
        '
        'Button29
        '
        Me.Button29.BackColor = System.Drawing.Color.FromArgb(CType(CType(223, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.Button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button29.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button29.Image = CType(resources.GetObject("Button29.Image"), System.Drawing.Image)
        Me.Button29.Location = New System.Drawing.Point(95, 657)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(83, 39)
        Me.Button29.TabIndex = 49
        Me.Button29.UseVisualStyleBackColor = False
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        DataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle56.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle56.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle56.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle56.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle56.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle56.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle56
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.Column18, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn19})
        DataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle57.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle57.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle57.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle57.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle57.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView2.DefaultCellStyle = DataGridViewCellStyle57
        Me.DataGridView2.Location = New System.Drawing.Point(95, 81)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle58.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle58.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle58.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle58.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle58.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.RowHeadersDefaultCellStyle = DataGridViewCellStyle58
        Me.DataGridView2.RowHeadersVisible = False
        Me.DataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView2.Size = New System.Drawing.Size(850, 570)
        Me.DataGridView2.TabIndex = 48
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "report ID"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Visible = False
        '
        'Column18
        '
        Me.Column18.HeaderText = "Name"
        Me.Column18.Name = "Column18"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Barangay"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 150
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "File"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 180
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "Status"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 150
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "Date Upload"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 130
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.HeaderText = "Approved Date"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.Width = 130
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Label88.Location = New System.Drawing.Point(189, 662)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(100, 30)
        Me.Label88.TabIndex = 47
        Me.Label88.Text = "SEARCH:"
        '
        'TextBox9
        '
        Me.TextBox9.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.Location = New System.Drawing.Point(295, 664)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(418, 29)
        Me.TextBox9.TabIndex = 46
        '
        'Panel29
        '
        Me.Panel29.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel29.Controls.Add(Me.Label89)
        Me.Panel29.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel29.Location = New System.Drawing.Point(0, 0)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(1091, 48)
        Me.Panel29.TabIndex = 1
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.BackColor = System.Drawing.Color.Transparent
        Me.Label89.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label89.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label89.Location = New System.Drawing.Point(35, 5)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(379, 37)
        Me.Label89.TabIndex = 2
        Me.Label89.Text = "ANNUAL REPORT ARCHIVE"
        '
        'PanelSMS
        '
        Me.PanelSMS.BackColor = System.Drawing.Color.LightSteelBlue
        Me.PanelSMS.Controls.Add(Me.Label105)
        Me.PanelSMS.Controls.Add(Me.Label106)
        Me.PanelSMS.Controls.Add(Me.ComboBox4)
        Me.PanelSMS.Controls.Add(Me.TextBox10)
        Me.PanelSMS.Controls.Add(Me.btnBack)
        Me.PanelSMS.Controls.Add(Me.Label104)
        Me.PanelSMS.Controls.Add(Me.TextBox8)
        Me.PanelSMS.Controls.Add(Me.Label103)
        Me.PanelSMS.Controls.Add(Me.Label102)
        Me.PanelSMS.Controls.Add(Me.Label101)
        Me.PanelSMS.Controls.Add(Me.Label100)
        Me.PanelSMS.Controls.Add(Me.TextBox7)
        Me.PanelSMS.Controls.Add(Me.TextBox6)
        Me.PanelSMS.Controls.Add(Me.TextBox5)
        Me.PanelSMS.Controls.Add(Me.RichTextBox3)
        Me.PanelSMS.Controls.Add(Me.DataGridView5)
        Me.PanelSMS.Controls.Add(Me.DataGridView4)
        Me.PanelSMS.Controls.Add(Me.Panel13)
        Me.PanelSMS.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelSMS.Location = New System.Drawing.Point(281, 0)
        Me.PanelSMS.Name = "PanelSMS"
        Me.PanelSMS.Size = New System.Drawing.Size(1091, 751)
        Me.PanelSMS.TabIndex = 55
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label105.Location = New System.Drawing.Point(325, 609)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(78, 21)
        Me.Label105.TabIndex = 64
        Me.Label105.Text = "SORT BY:"
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(529, 608)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(75, 21)
        Me.Label106.TabIndex = 63
        Me.Label106.Text = "SEARCH:"
        '
        'ComboBox4
        '
        Me.ComboBox4.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!)
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Items.AddRange(New Object() {"Activity/Announcements", "Date", "Barangay", "Name", "User Type"})
        Me.ComboBox4.Location = New System.Drawing.Point(329, 632)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(190, 27)
        Me.ComboBox4.TabIndex = 62
        '
        'TextBox10
        '
        Me.TextBox10.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox10.Location = New System.Drawing.Point(535, 631)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(424, 27)
        Me.TextBox10.TabIndex = 61
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Transparent
        Me.btnBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue
        Me.btnBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Image = CType(resources.GetObject("btnBack.Image"), System.Drawing.Image)
        Me.btnBack.Location = New System.Drawing.Point(42, 609)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(154, 50)
        Me.btnBack.TabIndex = 60
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(813, 508)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(82, 20)
        Me.Label104.TabIndex = 59
        Me.Label104.Text = "User Type:"
        '
        'TextBox8
        '
        Me.TextBox8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.Location = New System.Drawing.Point(810, 531)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(240, 25)
        Me.TextBox8.TabIndex = 58
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(284, 508)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(55, 20)
        Me.Label103.TabIndex = 57
        Me.Label103.Text = "Name:"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label102.Location = New System.Drawing.Point(539, 509)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(79, 20)
        Me.Label102.TabIndex = 56
        Me.Label102.Text = "Barangay:"
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label101.Location = New System.Drawing.Point(45, 508)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(46, 20)
        Me.Label101.TabIndex = 55
        Me.Label101.Text = "Date:"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label100.Location = New System.Drawing.Point(46, 359)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(200, 20)
        Me.Label100.TabIndex = 54
        Me.Label100.Text = "Activities/Announcements:"
        '
        'TextBox7
        '
        Me.TextBox7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.Location = New System.Drawing.Point(281, 531)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(241, 25)
        Me.TextBox7.TabIndex = 53
        '
        'TextBox6
        '
        Me.TextBox6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(535, 531)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(264, 25)
        Me.TextBox6.TabIndex = 52
        '
        'TextBox5
        '
        Me.TextBox5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(41, 531)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(229, 25)
        Me.TextBox5.TabIndex = 51
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox3.Location = New System.Drawing.Point(42, 382)
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.Size = New System.Drawing.Size(1004, 121)
        Me.RichTextBox3.TabIndex = 50
        Me.RichTextBox3.Text = ""
        '
        'DataGridView5
        '
        Me.DataGridView5.AllowUserToAddRows = False
        Me.DataGridView5.AllowUserToDeleteRows = False
        Me.DataGridView5.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle59.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle59.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle59.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle59.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle59.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView5.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle59
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23, Me.DataGridViewTextBoxColumn24})
        Me.DataGridView5.Location = New System.Drawing.Point(42, 103)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.ReadOnly = True
        Me.DataGridView5.Size = New System.Drawing.Size(999, 241)
        Me.DataGridView5.TabIndex = 49
        Me.DataGridView5.Visible = False
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.HeaderText = "Announcement"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        Me.DataGridViewTextBoxColumn20.Width = 130
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.HeaderText = "User Type"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.ReadOnly = True
        Me.DataGridViewTextBoxColumn21.Width = 160
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.HeaderText = "Barangay"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        Me.DataGridViewTextBoxColumn22.Width = 130
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        Me.DataGridViewTextBoxColumn23.Width = 130
        '
        'DataGridViewTextBoxColumn24
        '
        Me.DataGridViewTextBoxColumn24.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        Me.DataGridViewTextBoxColumn24.ReadOnly = True
        Me.DataGridViewTextBoxColumn24.Width = 130
        '
        'DataGridView4
        '
        Me.DataGridView4.AllowUserToAddRows = False
        Me.DataGridView4.AllowUserToDeleteRows = False
        Me.DataGridView4.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle60.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle60.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle60.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle60.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle60.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView4.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle60
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column19, Me.Column20, Me.Column21, Me.Column22, Me.Column23, Me.Column24, Me.Column25})
        Me.DataGridView4.Location = New System.Drawing.Point(42, 103)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.ReadOnly = True
        Me.DataGridView4.Size = New System.Drawing.Size(999, 241)
        Me.DataGridView4.TabIndex = 48
        Me.DataGridView4.Visible = False
        '
        'Column19
        '
        Me.Column19.HeaderText = " Title"
        Me.Column19.Name = "Column19"
        Me.Column19.ReadOnly = True
        '
        'Column20
        '
        Me.Column20.HeaderText = "Description"
        Me.Column20.Name = "Column20"
        Me.Column20.ReadOnly = True
        '
        'Column21
        '
        Me.Column21.HeaderText = "Activity Date"
        Me.Column21.Name = "Column21"
        Me.Column21.ReadOnly = True
        '
        'Column22
        '
        Me.Column22.HeaderText = "Barangay"
        Me.Column22.Name = "Column22"
        Me.Column22.ReadOnly = True
        '
        'Column23
        '
        Me.Column23.HeaderText = "User"
        Me.Column23.Name = "Column23"
        Me.Column23.ReadOnly = True
        '
        'Column24
        '
        Me.Column24.HeaderText = "Posted Time"
        Me.Column24.Name = "Column24"
        Me.Column24.ReadOnly = True
        '
        'Column25
        '
        Me.Column25.HeaderText = "Name"
        Me.Column25.Name = "Column25"
        Me.Column25.ReadOnly = True
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel13.Controls.Add(Me.Label98)
        Me.Panel13.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel13.Location = New System.Drawing.Point(0, 0)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(1091, 48)
        Me.Panel13.TabIndex = 47
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.BackColor = System.Drawing.Color.Transparent
        Me.Label98.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label98.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label98.Location = New System.Drawing.Point(35, 5)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(202, 37)
        Me.Label98.TabIndex = 46
        Me.Label98.Text = "SMS ARCHIVE"
        Me.Label98.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel18
        '
        Me.Panel18.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.Panel18.Controls.Add(Me.Label17)
        Me.Panel18.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel18.Location = New System.Drawing.Point(0, 0)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(1091, 48)
        Me.Panel18.TabIndex = 2
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Segoe UI Black", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Label17.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label17.Location = New System.Drawing.Point(35, 5)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(370, 37)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "ORGANIZATIONAL CHART"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox11
        '
        Me.TextBox11.BackColor = System.Drawing.Color.LightSteelBlue
        Me.TextBox11.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox11.Font = New System.Drawing.Font("Segoe UI Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.TextBox11.Location = New System.Drawing.Point(77, 71)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(790, 29)
        Me.TextBox11.TabIndex = 3
        Me.TextBox11.Text = "PANGLUNGSOD NA PEDERASYON NG SANGGUNIANG KABATAAN - Vigan"
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox13
        '
        Me.TextBox13.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.TextBox13.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox13.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox13.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox13.Location = New System.Drawing.Point(589, 222)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(308, 20)
        Me.TextBox13.TabIndex = 4
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox15
        '
        Me.TextBox15.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.TextBox15.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox15.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox15.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox15.Location = New System.Drawing.Point(245, 450)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(252, 20)
        Me.TextBox15.TabIndex = 6
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox16
        '
        Me.TextBox16.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.TextBox16.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox16.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox16.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox16.Location = New System.Drawing.Point(821, 589)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(211, 20)
        Me.TextBox16.TabIndex = 7
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox17
        '
        Me.TextBox17.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.TextBox17.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox17.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox17.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox17.Location = New System.Drawing.Point(625, 591)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(171, 20)
        Me.TextBox17.TabIndex = 8
        Me.TextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox18
        '
        Me.TextBox18.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.TextBox18.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox18.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox18.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox18.Location = New System.Drawing.Point(434, 587)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(171, 20)
        Me.TextBox18.TabIndex = 9
        Me.TextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox19
        '
        Me.TextBox19.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.TextBox19.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox19.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox19.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox19.Location = New System.Drawing.Point(245, 589)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(165, 20)
        Me.TextBox19.TabIndex = 10
        Me.TextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'panelOfficials
        '
        Me.panelOfficials.BackColor = System.Drawing.Color.LightSteelBlue
        Me.panelOfficials.BackgroundImage = CType(resources.GetObject("panelOfficials.BackgroundImage"), System.Drawing.Image)
        Me.panelOfficials.Controls.Add(Me.Button24)
        Me.panelOfficials.Controls.Add(Me.TextBox21)
        Me.panelOfficials.Controls.Add(Me.Button23)
        Me.panelOfficials.Controls.Add(Me.Button17)
        Me.panelOfficials.Controls.Add(Me.TextBox14)
        Me.panelOfficials.Controls.Add(Me.TextBox20)
        Me.panelOfficials.Controls.Add(Me.TextBox19)
        Me.panelOfficials.Controls.Add(Me.TextBox18)
        Me.panelOfficials.Controls.Add(Me.TextBox17)
        Me.panelOfficials.Controls.Add(Me.TextBox16)
        Me.panelOfficials.Controls.Add(Me.TextBox15)
        Me.panelOfficials.Controls.Add(Me.TextBox13)
        Me.panelOfficials.Controls.Add(Me.TextBox11)
        Me.panelOfficials.Controls.Add(Me.Panel18)
        Me.panelOfficials.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelOfficials.Location = New System.Drawing.Point(281, 0)
        Me.panelOfficials.Name = "panelOfficials"
        Me.panelOfficials.Size = New System.Drawing.Size(1091, 751)
        Me.panelOfficials.TabIndex = 13
        '
        'Button24
        '
        Me.Button24.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button24.Image = CType(resources.GetObject("Button24.Image"), System.Drawing.Image)
        Me.Button24.Location = New System.Drawing.Point(955, 680)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(75, 41)
        Me.Button24.TabIndex = 16
        Me.Button24.UseVisualStyleBackColor = True
        '
        'TextBox21
        '
        Me.TextBox21.BackColor = System.Drawing.Color.LightSteelBlue
        Me.TextBox21.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox21.Font = New System.Drawing.Font("Segoe UI Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.TextBox21.Location = New System.Drawing.Point(863, 69)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(183, 29)
        Me.TextBox21.TabIndex = 15
        Me.TextBox21.Text = "YEAR"
        '
        'Button23
        '
        Me.Button23.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button23.Image = CType(resources.GetObject("Button23.Image"), System.Drawing.Image)
        Me.Button23.Location = New System.Drawing.Point(799, 680)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(75, 41)
        Me.Button23.TabIndex = 14
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button17.Image = CType(resources.GetObject("Button17.Image"), System.Drawing.Image)
        Me.Button17.Location = New System.Drawing.Point(877, 680)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(75, 41)
        Me.Button17.TabIndex = 13
        Me.Button17.UseVisualStyleBackColor = True
        '
        'TextBox14
        '
        Me.TextBox14.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.TextBox14.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox14.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox14.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox14.Location = New System.Drawing.Point(392, 328)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(249, 20)
        Me.TextBox14.TabIndex = 12
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox20
        '
        Me.TextBox20.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.TextBox20.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox20.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox20.Location = New System.Drawing.Point(53, 589)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(167, 20)
        Me.TextBox20.TabIndex = 11
        Me.TextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'menuForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1372, 751)
        Me.Controls.Add(Me.PanelUserManagement)
        Me.Controls.Add(Me.panelAboutUs)
        Me.Controls.Add(Me.panelOfficials)
        Me.Controls.Add(Me.PanelActivities)
        Me.Controls.Add(Me.panelHistory)
        Me.Controls.Add(Me.panelbarangay)
        Me.Controls.Add(Me.PanelStat)
        Me.Controls.Add(Me.PanelMonthlyReport)
        Me.Controls.Add(Me.PanelSMS)
        Me.Controls.Add(Me.PanelArchive)
        Me.Controls.Add(Me.PanelArchive2)
        Me.Controls.Add(Me.panelReportArchive)
        Me.Controls.Add(Me.PanelAdminDahboard)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "menuForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "menuForm"
        Me.PanelAdminDahboard.ResumeLayout(False)
        Me.PanelAdminDahboard.PerformLayout()
        Me.Panel25.ResumeLayout(False)
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel17.ResumeLayout(False)
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelActivities.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.panelbarangay.ResumeLayout(False)
        Me.panelbarangay.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.panelAboutUs.ResumeLayout(False)
        Me.panelAboutUs.PerformLayout()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.PanelMonthlyReport.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.panelHistory.ResumeLayout(False)
        Me.panelHistory.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.PanelArchive.ResumeLayout(False)
        Me.Panel23.ResumeLayout(False)
        Me.Panel23.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.PanelUserManagement.ResumeLayout(False)
        Me.PanelUserManagement.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        Me.PanelArchive2.ResumeLayout(False)
        Me.PanelArchive2.PerformLayout()
        CType(Me.infoarchiveDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout()
        Me.PanelStat.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        CType(Me.Chart6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        CType(Me.Chart3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        CType(Me.Chart4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel31.ResumeLayout(False)
        Me.Panel31.PerformLayout()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        CType(Me.Chart5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.panelReportArchive.ResumeLayout(False)
        Me.panelReportArchive.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        Me.PanelSMS.ResumeLayout(False)
        Me.PanelSMS.PerformLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.panelOfficials.ResumeLayout(False)
        Me.panelOfficials.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelAdminDahboard As Panel
    Friend WithEvents Button10 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PanelActivities As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents panelbarangay As Panel
    Friend WithEvents brgy20button As Button
    Friend WithEvents brgy12button As Button
    Friend WithEvents brgy19button As Button
    Friend WithEvents brgy18button As Button
    Friend WithEvents brgy17button As Button
    Friend WithEvents brgy16button As Button
    Friend WithEvents brgy15button As Button
    Friend WithEvents brgy14button As Button
    Friend WithEvents brgy13button As Button
    Friend WithEvents brgy11button As Button
    Friend WithEvents brgy30button As Button
    Friend WithEvents brgy22button As Button
    Friend WithEvents brgy29button As Button
    Friend WithEvents brgy28button As Button
    Friend WithEvents brgy27button As Button
    Friend WithEvents brgy26button As Button
    Friend WithEvents brgy25button As Button
    Friend WithEvents brgy24button As Button
    Friend WithEvents brgy23button As Button
    Friend WithEvents brgy21button As Button
    Friend WithEvents brgy32button As Button
    Friend WithEvents brgy39button As Button
    Friend WithEvents brgy38button As Button
    Friend WithEvents brgy37button As Button
    Friend WithEvents brgy36button As Button
    Friend WithEvents brgy35button As Button
    Friend WithEvents brgy33button As Button
    Friend WithEvents brgy34button As Button
    Friend WithEvents brgy31button As Button
    Friend WithEvents brgy10button As Button
    Friend WithEvents brgy2button As Button
    Friend WithEvents brgy9button As Button
    Friend WithEvents brgy8button As Button
    Friend WithEvents brgy7button As Button
    Friend WithEvents brgy6button As Button
    Friend WithEvents brgy5button As Button
    Friend WithEvents brgy4button As Button
    Friend WithEvents brgy3button As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents brgy1button As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents panelAboutUs As Panel
    Friend WithEvents Label57 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents PanelMonthlyReport As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents panelHistory As Panel
    Friend WithEvents Panel21 As Panel
    Friend WithEvents Label10 As Label
    Friend WithEvents Panel20 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents PanelArchive As Panel
    Friend WithEvents Panel23 As Panel
    Friend WithEvents Panel22 As Panel
    Friend WithEvents Label51 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents PanelUserManagement As Panel
    Friend WithEvents Panel24 As Panel
    Friend WithEvents Label16 As Label
    Friend WithEvents PanelArchive2 As Panel
    Friend WithEvents Panel26 As Panel
    Friend WithEvents Label19 As Label
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Label68 As Label
    Friend WithEvents ComboBoxUsertype As ComboBox
    Friend WithEvents Label73 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents ComboBoxBarangay As ComboBox
    Friend WithEvents TextBoxID As TextBox
    Friend WithEvents TextBoxFname As TextBox
    Friend WithEvents TextBoxPassword As TextBox
    Friend WithEvents Label76 As Label
    Friend WithEvents TextBoxUsername As TextBox
    Friend WithEvents Label77 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents TextBoxMname As TextBox
    Friend WithEvents TextBoxLname As TextBox
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents infoarchiveDataGridView As DataGridView
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label12 As Label
    Friend WithEvents Panel19 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Label26 As Label
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents Panel17 As Panel
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Panel25 As Panel
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents Label38 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label86 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents Label81 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents Label69 As Label
    Friend WithEvents Label67 As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
    Friend WithEvents Column11 As DataGridViewTextBoxColumn
    Friend WithEvents Column12 As DataGridViewTextBoxColumn
    Friend WithEvents Column13 As DataGridViewTextBoxColumn
    Friend WithEvents Column14 As DataGridViewTextBoxColumn
    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents Button27 As Button
    Friend WithEvents PanelStat As Panel
    Friend WithEvents Panel27 As Panel
    Friend WithEvents Label87 As Label
    Friend WithEvents Chart1 As DataVisualization.Charting.Chart
    Friend WithEvents Chart3 As DataVisualization.Charting.Chart
    Friend WithEvents Chart2 As DataVisualization.Charting.Chart
    Friend WithEvents Chart4 As DataVisualization.Charting.Chart
    Friend WithEvents Chart5 As DataVisualization.Charting.Chart
    Friend WithEvents Chart6 As DataVisualization.Charting.Chart
    Friend WithEvents panelReportArchive As Panel
    Friend WithEvents Label88 As Label
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Panel29 As Panel
    Friend WithEvents Label89 As Label
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents Button28 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents TextBoxSearch As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label90 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents Column16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents Label21 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Label29 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Button25 As Button
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label92 As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents flpPanel As FlowLayoutPanel
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label14 As Label
    Friend WithEvents Button13 As Button
    Friend WithEvents RichTextBox2 As RichTextBox
    Friend WithEvents flpAnnouncements As FlowLayoutPanel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Button11 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column17 As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column15 As DataGridViewTextBoxColumn
    Friend WithEvents Label18 As Label
    Friend WithEvents Button60 As Button
    Friend WithEvents Button49 As Button
    Friend WithEvents Button47 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button59 As Button
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents Column18 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As DataGridViewTextBoxColumn
    Friend WithEvents Panel28 As Panel
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel31 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents Button9 As Button
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label91 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label94 As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label93 As Label
    Friend WithEvents Label95 As Label
    Friend WithEvents Label96 As Label
    Friend WithEvents Label97 As Label
    Friend WithEvents Button12 As Button
    Friend WithEvents PanelSMS As Panel
    Friend WithEvents DataGridView4 As DataGridView
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Label98 As Label
    Friend WithEvents Label99 As Label
    Friend WithEvents Button14 As Button
    Friend WithEvents DataGridView5 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As DataGridViewTextBoxColumn
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents RichTextBox3 As RichTextBox
    Friend WithEvents Column19 As DataGridViewTextBoxColumn
    Friend WithEvents Column20 As DataGridViewTextBoxColumn
    Friend WithEvents Column21 As DataGridViewTextBoxColumn
    Friend WithEvents Column22 As DataGridViewTextBoxColumn
    Friend WithEvents Column23 As DataGridViewTextBoxColumn
    Friend WithEvents Column24 As DataGridViewTextBoxColumn
    Friend WithEvents Column25 As DataGridViewTextBoxColumn
    Friend WithEvents Label104 As Label
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Label103 As Label
    Friend WithEvents Label102 As Label
    Friend WithEvents Label101 As Label
    Friend WithEvents Label100 As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents Label105 As Label
    Friend WithEvents Label106 As Label
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents Panel18 As Panel
    Friend WithEvents Label17 As Label
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents TextBox19 As TextBox
    Friend WithEvents panelOfficials As Panel
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents Button23 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents Button24 As Button
    Friend WithEvents Label107 As Label
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents LinkLabel1 As LinkLabel
End Class
