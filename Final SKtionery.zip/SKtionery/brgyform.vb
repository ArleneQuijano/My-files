﻿Imports System.Windows.Forms.DataVisualization.Charting
Imports MySql.Data.MySqlClient
Imports System
Imports System.IO
Public Class brgyform
    Dim educ As Integer = 0
    Dim brgy1 As Integer = 0
    Dim workS As String
    Dim Flag As Boolean
    Dim cn As New MySqlConnection
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        TextBoxID.Text = ""
        TextBoxFname.Text = ""
        TextBoxLname.Text = ""
        TextBoxMname.Text = ""
        ComboBoxGender.Text = ""
        TextBoxContact.Text = ""
        TextBoxEmail.Text = ""
        ComboBoxCivil.Text = ""
        ComboBoxYouthAge.Text = ""
        ComboBoxEducation.Text = ""
        ComboBoxClassification.Text = ""
        ComboBoxWork.Text = ""
        DateTimePicker1.ResetText()
        menuForm.Show()
        Me.Hide()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        TextBoxID.Text = ""
        TextBoxFname.Text = ""
        TextBoxLname.Text = ""
        TextBoxMname.Text = ""
        ComboBoxGender.Text = ""
        TextBoxContact.Text = ""
        TextBoxEmail.Text = ""
        ComboBoxCivil.Text = ""
        ComboBoxYouthAge.Text = ""
        ComboBoxEducation.Text = ""
        ComboBoxClassification.Text = ""
        ComboBoxWork.Text = ""
        DateTimePicker1.ResetText()


        TextBoxID.Enabled = True
        TextBoxFname.Enabled = True
        TextBoxLname.Enabled = True
        TextBoxMname.Enabled = True
        ComboBoxGender.Enabled = True
        TextBoxContact.Enabled = True
        TextBoxEmail.Enabled = True
        ComboBoxCivil.Enabled = True
        ComboBoxYouthAge.Enabled = True
        ComboBoxEducation.Enabled = True
        ComboBoxClassification.Enabled = True
        ComboBoxWork.Enabled = True
        DateTimePicker1.Enabled = True
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim educ As Integer = 0
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If

        If ComboBoxEducation.Text = "Elementary Level" Then
            educ = 1
        ElseIf ComboBoxEducation.Text = "Elementary Graduate" Then
            educ = 2
        ElseIf ComboBoxEducation.Text = "High School Level" Then
            educ = 3
        ElseIf ComboBoxEducation.Text = "High School Graduate" Then
            educ = 4
        ElseIf ComboBoxEducation.Text = "Vocational Graduate" Then
            educ = 5
        ElseIf ComboBoxEducation.Text = "College Level" Then
            educ = 6
        ElseIf ComboBoxEducation.Text = "College Graduate" Then
            educ = 7
        ElseIf ComboBoxEducation.Text = "Masters Level" Then
            educ = 8
        ElseIf ComboBoxEducation.Text = "Masters Graduate" Then
            educ = 9
        ElseIf ComboBoxEducation.Text = "Doctorate Level" Then
            educ = 10
        ElseIf ComboBoxEducation.Text = "Doctorate Graduate" Then
            educ = 11
        End If
        If TextBoxID.Text = "" Or
        TextBoxFname.Text = "" Or
        TextBoxLname.Text = "" Or
        ComboBoxGender.Text = "" Or
        TextBoxContact.Text = "" Or
        TextBoxEmail.Text = "" Or
        ComboBoxCivil.Text = "" Or
        ComboBoxYouthAge.Text = "" Or
        ComboBoxEducation.Text = "" Or
        ComboBoxClassification.Text = "" Or
         ComboBoxCivil.Text = "" Or
        ComboBoxWork.Text = "" Then
            MessageBox.Show("Missing Fields!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else

            Try
                Dim db1 = New Database
                Dim dt1 As New DataTable
                With db1
                    .sqlStr = "SELECT * from information_tbl where id ='" & TextBoxID.Text.Trim & "'" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                    .close()
                End With
                dt1 = db1.sqlDt



                If dt1.Rows.Count > 0 Then
                    MessageBox.Show("ID NUMBER ALREADY REGISTERED!", "ALERT", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                Else
                    Dim db = New Database
                    With db
                        ''-----------------------------------------EMPTY TransactID---------
                        .sqlStr = "insert into information_tbl (id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                                        youth_classification,educ_id,work_status,brgy_id) values
                ('" & TextBoxID.Text.Trim & "','" & TextBoxLname.Text.Trim & "','" & TextBoxFname.Text.Trim & "','" & TextBoxMname.Text.Trim &
                    "','" & ComboBoxGender.Text.Trim & "','" & DateTimePicker1.Text.Trim & "','" & TextBoxContact.Text.Trim & "','" & TextBoxEmail.Text.Trim &
                    "','" & ComboBoxCivil.Text.Trim & "','" & ComboBoxYouthAge.Text.Trim & "','" & ComboBoxClassification.Text.Trim & "','" & educ &
                            "','" & ComboBoxWork.Text.Trim & "','" & brgy1 & "')"
                        .sqlDa.InsertCommand = .sqlcm(.sqlStr, .connect)
                        .sqlDa.InsertCommand.ExecuteNonQuery()
                        .close()
                    End With
                    MessageBox.Show("Successfully Saved", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    Refresh()

                    If Label14.Text = "Barangay Ayusan Norte" Then
                        loadFormBrgy1()
                    ElseIf Label14.Text = "Barangay Ayusan Sur" Then
                        loadFormBrgy2()
                    ElseIf Label14.Text = "Barangay I" Then
                        loadFormBrgy3()
                    ElseIf Label14.Text = "Barangay II" Then
                        loadFormBrgy4()
                    ElseIf Label14.Text = "Barangay III" Then
                        loadFormBrgy5()
                    ElseIf Label14.Text = "Barangay IV" Then
                        loadFormBrgy6()
                    ElseIf Label14.Text = "Barangay V" Then
                        loadFormBrgy7()
                    ElseIf Label14.Text = "Barangay VI" Then
                        loadFormBrgy8()
                    ElseIf Label14.Text = "Barangay VII" Then
                        loadFormBrgy9()
                    ElseIf Label14.Text = "Barangay VIII" Then
                        loadFormBrgy10()
                    ElseIf Label14.Text = "Barangay IX" Then
                        loadFormBrgy11()
                    ElseIf Label14.Text = "Barangay Barraca" Then
                        loadFormBrgy12()
                    ElseIf Label14.Text = "Barangay Beddeng Daya" Then
                        loadFormBrgy13()
                    ElseIf Label14.Text = "Barangay Beddeng Laud" Then
                        loadFormBrgy14()
                    ElseIf Label14.Text = "Barangay Bongtolan" Then
                        loadFormBrgy15()
                    ElseIf Label14.Text = "Barangay Bulala" Then
                        loadFormBrgy16()
                    ElseIf Label14.Text = "Barangay Cabalangegan" Then
                        loadFormBrgy17()
                    ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
                        loadFormBrgy18()
                    ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
                        loadFormBrgy19()
                    ElseIf Label14.Text = "Barangay Camangaan" Then
                        loadFormBrgy20()
                    ElseIf Label14.Text = "Barangay Capangpangan" Then
                        loadFormBrgy21()
                    ElseIf Label14.Text = "Barangay Mindoro" Then
                        loadFormBrgy22()
                    ElseIf Label14.Text = "Barangay Nagsangalan" Then
                        loadFormBrgy23()
                    ElseIf Label14.Text = "Barangay Pantay Daya" Then
                        loadFormBrgy24()
                    ElseIf Label14.Text = "Barangay Pantay Fatima" Then
                        loadFormBrgy25()
                    ElseIf Label14.Text = "Barangay Pantay Laud" Then
                        loadFormBrgy26()
                    ElseIf Label14.Text = "Barangay Paoa" Then
                        loadFormBrgy27()
                    ElseIf Label14.Text = "Barangay Paratong" Then
                        loadFormBrgy28()
                    ElseIf Label14.Text = "Barangay Pong-ol" Then
                        loadFormBrgy29()
                    ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
                        loadFormBrgy30()
                    ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
                        loadFormBrgy31()
                    ElseIf Label14.Text = "Barangay Raois" Then
                        loadFormBrgy32()
                    ElseIf Label14.Text = "Barangay Rugsaunan" Then
                        loadFormBrgy33()
                    ElseIf Label14.Text = "Barangay Salindeg" Then
                        loadFormBrgy34()
                    ElseIf Label14.Text = "Barangay San Jose" Then
                        loadFormBrgy35()
                    ElseIf Label14.Text = "Barangay San Julian Norte" Then
                        loadFormBrgy36()
                    ElseIf Label14.Text = "Barangay San Julian Sur" Then
                        loadFormBrgy37()
                    ElseIf Label14.Text = "Barangay San Pedro" Then
                        loadFormBrgy38()
                    ElseIf Label14.Text = "Barangay Tamag" Then
                        loadFormBrgy39()
                    End If
                    TextBoxID.Text = ""
                    TextBoxFname.Text = ""
                    TextBoxLname.Text = ""
                    ComboBoxGender.Text = ""
                    TextBoxContact.Text = ""
                    TextBoxEmail.Text = ""
                    ComboBoxCivil.Text = ""
                    ComboBoxYouthAge.Text = ""
                    ComboBoxEducation.Text = ""
                    ComboBoxClassification.Text = ""
                    ComboBoxCivil.Text = ""
                    ComboBoxWork.Text = ""
                End If


            Catch
                MessageBox.Show("error")
            End Try
        End If
    End Sub
    Public Sub loadFormBrgy1()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
                `youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 1 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString

                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If


                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy2()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 2 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy3()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 3 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy4()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 4 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy5()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
                `youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 5 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString

                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If


                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy6()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 6 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString

                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy7()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 7 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString

                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy8()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 8 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy9()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 9 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy10()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 10 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy11()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT`id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 11 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy12()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT`id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 12 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy13()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 13 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy14()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 14 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy15()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 15 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Public Sub loadFormBrgy16()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 16 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy17()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 17 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy18()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 18 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy19()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 19 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy20()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 20 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy21()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 21 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy22()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 22 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy23()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 23 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy24()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 24 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy25()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 25 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy26()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 26 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy27()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 27 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy28()
        '      Try
        Dim db = New Database
        Dim dt As New DataTable
        With db
            .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 28 Order by lastname ASC" 'query string
            .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
            .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
            .close()
        End With
        dt = db.sqlDt
        infoDataGridView.Rows.Clear()
        For i = 0 To dt.Rows.Count - 1
            infoDataGridView.Rows.Add()
            infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
            infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
            infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
            infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
            infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
            infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
            infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
            infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
            infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
            infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
            infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
            infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
            infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
            infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString

            If dt.Rows(i).Item(11).ToString = "1" Then
                infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
            ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
            ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
            ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
            ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
            ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                infoDataGridView.Rows(i).Cells(11).Value = "College Level"
            ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
            ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
            ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
            ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
            ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

            End If

            If dt.Rows(i).Item(13).ToString = "1" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
            ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
            ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
            ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
            ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
            ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
            ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
            ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
            ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
            ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
            ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
            ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
            ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
            ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
            ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
            ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
            ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
            ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
            ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
            ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
            ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
            ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
            ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
            ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
            ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
            ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
            ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
            ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
            ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
            ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
            ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
            ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Raois"
            ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
            ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
            ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
            ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
            ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
            ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
            ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
            End If

            TextBoxID.Enabled = True
            TextBoxFname.Enabled = True
            TextBoxLname.Enabled = True
            TextBoxMname.Enabled = True
            ComboBoxGender.Enabled = True
            TextBoxContact.Enabled = True
            TextBoxEmail.Enabled = True
            ComboBoxCivil.Enabled = True
            ComboBoxYouthAge.Enabled = True
            ComboBoxEducation.Enabled = True
            ComboBoxClassification.Enabled = True
            ComboBoxWork.Enabled = True
            DateTimePicker1.Enabled = True


        Next
        '    Catch
        '       MessageBox.Show("error")
        '    End Try
    End Sub

    Public Sub loadFormBrgy29()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT`id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 29 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy30()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 30 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy31()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 31 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy32()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 32 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy33()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 33 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub



    Public Sub loadFormBrgy34()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 34 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy35()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 35 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy36()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 36 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy37()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 37 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy38()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 38 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If

                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub

    Public Sub loadFormBrgy39()
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT `id`,`lastname`,`firstname`,`middlename`,`gender`,`birthday`,`contact_no`,`email`,`civil_status`,`youth_age`,
`youth_classification`,`educ_id`,`work_status`,`brgy_id` from information_tbl where brgy_id = 39 Order by lastname ASC" 'query string
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                infoDataGridView.Rows(i).Cells(13).Value = dt.Rows(i).Item(13).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If
                If dt.Rows(i).Item(13).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Ayusan Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 1"
                ElseIf dt.Rows(i).Item(13).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 2"
                ElseIf dt.Rows(i).Item(13).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 3"
                ElseIf dt.Rows(i).Item(13).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 4"
                ElseIf dt.Rows(i).Item(13).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 5"
                ElseIf dt.Rows(i).Item(13).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 6"
                ElseIf dt.Rows(i).Item(13).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 7"
                ElseIf dt.Rows(i).Item(13).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 8"
                ElseIf dt.Rows(i).Item(13).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barangay 9"
                ElseIf dt.Rows(i).Item(13).ToString = "12" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Barraca"
                ElseIf dt.Rows(i).Item(13).ToString = "13" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "14" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Beddeng Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "15" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bongtolan"
                ElseIf dt.Rows(i).Item(13).ToString = "16" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Bulala"
                ElseIf dt.Rows(i).Item(13).ToString = "17" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabalangegan"
                ElseIf dt.Rows(i).Item(13).ToString = "18" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "19" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Cabaroan Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "20" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Camangaan"
                ElseIf dt.Rows(i).Item(13).ToString = "21" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Capangpangan"
                ElseIf dt.Rows(i).Item(13).ToString = "22" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Mindoro"
                ElseIf dt.Rows(i).Item(13).ToString = "23" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Nagsangalan"
                ElseIf dt.Rows(i).Item(13).ToString = "24" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Daya"
                ElseIf dt.Rows(i).Item(13).ToString = "25" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Fatima"
                ElseIf dt.Rows(i).Item(13).ToString = "26" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pantay Laud"
                ElseIf dt.Rows(i).Item(13).ToString = "27" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paoa"
                ElseIf dt.Rows(i).Item(13).ToString = "28" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Paratong"
                ElseIf dt.Rows(i).Item(13).ToString = "29" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Pong-ol"
                ElseIf dt.Rows(i).Item(13).ToString = "30" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-bassit"
                ElseIf dt.Rows(i).Item(13).ToString = "31" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Purok-a-dackel"
                ElseIf dt.Rows(i).Item(13).ToString = "32" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Raois"
                ElseIf dt.Rows(i).Item(13).ToString = "33" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Rugsaunan"
                ElseIf dt.Rows(i).Item(13).ToString = "34" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Salindeg"
                ElseIf dt.Rows(i).Item(13).ToString = "35" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Jose"
                ElseIf dt.Rows(i).Item(13).ToString = "36" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Norte"
                ElseIf dt.Rows(i).Item(13).ToString = "37" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Julian Sur"
                ElseIf dt.Rows(i).Item(13).ToString = "38" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "San Pedro"
                ElseIf dt.Rows(i).Item(13).ToString = "39" Then
                    infoDataGridView.Rows(i).Cells(13).Value = "Tamag"
                End If

                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True


            Next
        Catch
            MessageBox.Show("error")
        End Try
    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim educ As Integer = 0
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If

        If ComboBoxEducation.Text = "Elementary Level" Then
            educ = 1
        ElseIf ComboBoxEducation.Text = "Elementary Graduate" Then
            educ = 2
        ElseIf ComboBoxEducation.Text = "High School Level" Then
            educ = 3
        ElseIf ComboBoxEducation.Text = "High School Graduate" Then
            educ = 4
        ElseIf ComboBoxEducation.Text = "Vocational Graduate" Then
            educ = 5
        ElseIf ComboBoxEducation.Text = "College Level" Then
            educ = 6
        ElseIf ComboBoxEducation.Text = "College Graduate" Then
            educ = 7
        ElseIf ComboBoxEducation.Text = "Masters Level" Then
            educ = 8
        ElseIf ComboBoxEducation.Text = "Masters Graduate" Then
            educ = 9
        ElseIf ComboBoxEducation.Text = "Doctorate Level" Then
            educ = 10
        ElseIf ComboBoxEducation.Text = "Doctorate Graduate" Then
            educ = 11
        End If
        If TextBoxID.Text = "" Or
            TextBoxLname.Text = "" Or
            TextBoxFname.Text = "" Or
            ComboBoxGender.Text = "" Or
            DateTimePicker1.Text = "" Or
            TextBoxContact.Text = "" Or
            TextBoxEmail.Text = "" Or
            ComboBoxCivil.Text = "" Or
            ComboBoxYouthAge.Text = "" Or
            ComboBoxEducation.Text = "" Or
            ComboBoxClassification.Text = "" Or
            ComboBoxWork.Text = "" Then
            MessageBox.Show("Please Select Data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim result = MessageBox.Show("ARE YOU SURE?", "DELETE SELECTED", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If result = DialogResult.No Then
                TextBoxID.Text = ""
                TextBoxFname.Text = ""
                TextBoxLname.Text = ""
                TextBoxMname.Text = ""
                ComboBoxGender.Text = ""
                TextBoxContact.Text = ""
                TextBoxEmail.Text = ""
                ComboBoxCivil.Text = ""
                ComboBoxYouthAge.Text = ""
                ComboBoxEducation.Text = ""
                ComboBoxClassification.Text = ""
                ComboBoxWork.Text = ""
                DateTimePicker1.ResetText()
                TextBoxID.Enabled = True
                TextBoxFname.Enabled = True
                TextBoxLname.Enabled = True
                TextBoxMname.Enabled = True
                ComboBoxGender.Enabled = True
                TextBoxContact.Enabled = True
                TextBoxEmail.Enabled = True
                ComboBoxCivil.Enabled = True
                ComboBoxYouthAge.Enabled = True
                ComboBoxEducation.Enabled = True
                ComboBoxClassification.Enabled = True
                ComboBoxWork.Enabled = True
                DateTimePicker1.Enabled = True
            ElseIf result = DialogResult.Yes Then

                Try
                    Dim db = New Database
                    Dim dt As New DataTable
                    With db
                        .sqlStr = "insert into information_archive (archive_id,lname,fname,mname,gender,birthday,contact,email,civilstatus,youthage,
                                        youthclassification,educ_id,workstatus,brgy_id) values
                ('" & TextBoxID.Text.Trim & "','" & TextBoxLname.Text.Trim & "','" & TextBoxFname.Text.Trim & "','" & TextBoxMname.Text.Trim &
                        "','" & ComboBoxGender.Text.Trim & "','" & DateTimePicker1.Text.Trim & "','" & TextBoxContact.Text.Trim & "','" & TextBoxEmail.Text.Trim &
                        "','" & ComboBoxCivil.Text.Trim & "','" & ComboBoxYouthAge.Text.Trim & "','" & ComboBoxClassification.Text.Trim & "','" & educ &
                                "','" & ComboBoxWork.Text.Trim & "','" & brgy1 & "')"
                        .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                        .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                        .close()
                    End With
                    Dim db1 = New Database
                    Dim dt1 As New DataTable
                    With db1
                        .sqlStr = "delete from information_tbl where id='" & infoDataGridView.CurrentRow.Cells(0).Value & "'" 'query string
                        .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                        .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                        .close()
                    End With
                    MessageBox.Show("Successfully Deleted", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)


                    If Label14.Text = "Barangay Ayusan Norte" Then
                        loadFormBrgy1()
                    ElseIf Label14.Text = "Barangay Ayusan Sur" Then
                        loadFormBrgy2()
                    ElseIf Label14.Text = "Barangay I" Then
                        loadFormBrgy3()
                    ElseIf Label14.Text = "Barangay II" Then
                        loadFormBrgy4()
                    ElseIf Label14.Text = "Barangay III" Then
                        loadFormBrgy5()
                    ElseIf Label14.Text = "Barangay IV" Then
                        loadFormBrgy6()
                    ElseIf Label14.Text = "Barangay V" Then
                        loadFormBrgy7()
                    ElseIf Label14.Text = "Barangay VI" Then
                        loadFormBrgy8()
                    ElseIf Label14.Text = "Barangay VII" Then
                        loadFormBrgy9()
                    ElseIf Label14.Text = "Barangay VIII" Then
                        loadFormBrgy10()
                    ElseIf Label14.Text = "Barangay IX" Then
                        loadFormBrgy11()
                    ElseIf Label14.Text = "Barangay Barraca" Then
                        loadFormBrgy12()
                    ElseIf Label14.Text = "Barangay Beddeng Daya" Then
                        loadFormBrgy13()
                    ElseIf Label14.Text = "Barangay Beddeng Laud" Then
                        loadFormBrgy14()
                    ElseIf Label14.Text = "Barangay Bongtolan" Then
                        loadFormBrgy15()
                    ElseIf Label14.Text = "Barangay Bulala" Then
                        loadFormBrgy16()
                    ElseIf Label14.Text = "Barangay Cabalangegan" Then
                        loadFormBrgy17()
                    ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
                        loadFormBrgy18()
                    ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
                        loadFormBrgy19()
                    ElseIf Label14.Text = "Barangay Camangaan" Then
                        loadFormBrgy20()
                    ElseIf Label14.Text = "Barangay Capangpangan" Then
                        loadFormBrgy21()
                    ElseIf Label14.Text = "Barangay Mindoro" Then
                        loadFormBrgy22()
                    ElseIf Label14.Text = "Barangay Nagsangalan" Then
                        loadFormBrgy23()
                    ElseIf Label14.Text = "Barangay Pantay Daya" Then
                        loadFormBrgy24()
                    ElseIf Label14.Text = "Barangay Pantay Fatima" Then
                        loadFormBrgy25()
                    ElseIf Label14.Text = "Barangay Pantay Laud" Then
                        loadFormBrgy26()
                    ElseIf Label14.Text = "Barangay Paoa" Then
                        loadFormBrgy27()
                    ElseIf Label14.Text = "Barangay Paratong" Then
                        loadFormBrgy28()
                    ElseIf Label14.Text = "Barangay Pong-ol" Then
                        loadFormBrgy29()
                    ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
                        loadFormBrgy30()
                    ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
                        loadFormBrgy31()
                    ElseIf Label14.Text = "Barangay Raois" Then
                        loadFormBrgy32()
                    ElseIf Label14.Text = "Barangay Rugsaunan" Then
                        loadFormBrgy33()
                    ElseIf Label14.Text = "Barangay Salindeg" Then
                        loadFormBrgy34()
                    ElseIf Label14.Text = "Barangay San Jose" Then
                        loadFormBrgy35()
                    ElseIf Label14.Text = "Barangay San Julian Norte" Then
                        loadFormBrgy36()
                    ElseIf Label14.Text = "Barangay San Julian Sur" Then
                        loadFormBrgy37()
                    ElseIf Label14.Text = "Barangay San Pedro" Then
                        loadFormBrgy38()
                    ElseIf Label14.Text = "Barangay Tamag" Then
                        loadFormBrgy39()
                    End If

                    TextBoxID.Text = ""
                    TextBoxFname.Text = ""
                    TextBoxLname.Text = ""
                    TextBoxMname.Text = ""
                    ComboBoxGender.Text = ""
                    TextBoxContact.Text = ""
                    TextBoxEmail.Text = ""
                    ComboBoxCivil.Text = ""
                    ComboBoxYouthAge.Text = ""
                    ComboBoxEducation.Text = ""
                    ComboBoxClassification.Text = ""
                    ComboBoxWork.Text = ""
                    DateTimePicker1.ResetText()


                Catch
                    MessageBox.Show("ERROR")
                End Try
            End If
        End If
    End Sub


    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If TextBoxID.Text = "" Or
            TextBoxLname.Text = "" Or
            TextBoxFname.Text = "" Or
            ComboBoxGender.Text = "" Or
            DateTimePicker1.Text = "" Or
            TextBoxContact.Text = "" Or
            TextBoxEmail.Text = "" Or
            ComboBoxCivil.Text = "" Or
            ComboBoxYouthAge.Text = "" Or
            ComboBoxEducation.Text = "" Or
            ComboBoxClassification.Text = "" Or
            ComboBoxWork.Text = "" Then
            MessageBox.Show("Please Select Data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            TextBoxID.Text = infoDataGridView.CurrentRow.Cells(0).Value
            TextBoxLname.Text = infoDataGridView.CurrentRow.Cells(1).Value
            TextBoxFname.Text = infoDataGridView.CurrentRow.Cells(2).Value
            TextBoxMname.Text = infoDataGridView.CurrentRow.Cells(3).Value
            ComboBoxGender.Text = infoDataGridView.CurrentRow.Cells(4).Value
            DateTimePicker1.Text = infoDataGridView.CurrentRow.Cells(5).Value
            TextBoxContact.Text = infoDataGridView.CurrentRow.Cells(6).Value
            TextBoxEmail.Text = infoDataGridView.CurrentRow.Cells(7).Value
            ComboBoxCivil.Text = infoDataGridView.CurrentRow.Cells(8).Value
            ComboBoxYouthAge.Text = infoDataGridView.CurrentRow.Cells(9).Value
            ComboBoxEducation.Text = infoDataGridView.CurrentRow.Cells(11).Value
            ComboBoxClassification.Text = infoDataGridView.CurrentRow.Cells(10).Value
            ComboBoxWork.Text = infoDataGridView.CurrentRow.Cells(12).Value

        End If



        TextBoxID.Enabled = False
        TextBoxFname.Enabled = True
        TextBoxLname.Enabled = True
        TextBoxMname.Enabled = True
        ComboBoxGender.Enabled = True
        TextBoxContact.Enabled = True
        TextBoxEmail.Enabled = True
        ComboBoxCivil.Enabled = True
        ComboBoxYouthAge.Enabled = True
        ComboBoxEducation.Enabled = True
        ComboBoxClassification.Enabled = True
        ComboBoxWork.Enabled = True
        DateTimePicker1.Enabled = True
    End Sub

    Private Sub infoDataGridView_CellEnter(sender As Object, e As DataGridViewCellEventArgs) Handles infoDataGridView.CellEnter
        '  Format(Convert.ToDateTime(infoDataGridView.CurrentRow.Cells(5).Value), "MM/dd/yyy")
        TextBoxID.Text = infoDataGridView.CurrentRow.Cells(0).Value
        TextBoxLname.Text = infoDataGridView.CurrentRow.Cells(1).Value
        TextBoxFname.Text = infoDataGridView.CurrentRow.Cells(2).Value
        TextBoxMname.Text = infoDataGridView.CurrentRow.Cells(3).Value
        ComboBoxGender.Text = infoDataGridView.CurrentRow.Cells(4).Value
        '       Dim currentDate As String = infoDataGridView.CurrentRow.Cells(5).Value
        '    Dim convertedDate As DateTime = Convert.ToDateTime(currentDate)
        DateTimePicker1.Text = Convert.ToDateTime(infoDataGridView.CurrentRow.Cells(5).Value)
        TextBoxContact.Text = infoDataGridView.CurrentRow.Cells(6).Value
        TextBoxEmail.Text = infoDataGridView.CurrentRow.Cells(7).Value
        ComboBoxCivil.Text = infoDataGridView.CurrentRow.Cells(8).Value
        ComboBoxYouthAge.Text = infoDataGridView.CurrentRow.Cells(9).Value
        ComboBoxEducation.Text = infoDataGridView.CurrentRow.Cells(11).Value
        ComboBoxClassification.Text = infoDataGridView.CurrentRow.Cells(10).Value
        ComboBoxWork.Text = infoDataGridView.CurrentRow.Cells(12).Value
        ''  MessageBox.Show(convertedDate)
        TextBoxID.Enabled = False
        TextBoxFname.Enabled = False
        TextBoxLname.Enabled = False
        TextBoxMname.Enabled = False
        ComboBoxGender.Enabled = False
        TextBoxContact.Enabled = False
        TextBoxEmail.Enabled = False
        ComboBoxCivil.Enabled = False
        ComboBoxYouthAge.Enabled = False
        ComboBoxEducation.Enabled = False
        ComboBoxClassification.Enabled = False
        ComboBoxWork.Enabled = False
        DateTimePicker1.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim educ As Integer = 0
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If

        If ComboBoxEducation.Text = "Elementary Level" Then
            educ = 1
        ElseIf ComboBoxEducation.Text = "Elementary Graduate" Then
            educ = 2
        ElseIf ComboBoxEducation.Text = "High School Level" Then
            educ = 3
        ElseIf ComboBoxEducation.Text = "High School Graduate" Then
            educ = 4
        ElseIf ComboBoxEducation.Text = "Vocational Graduate" Then
            educ = 5
        ElseIf ComboBoxEducation.Text = "College Level" Then
            educ = 6
        ElseIf ComboBoxEducation.Text = "College Graduate" Then
            educ = 7
        ElseIf ComboBoxEducation.Text = "Masters Level" Then
            educ = 8
        ElseIf ComboBoxEducation.Text = "Masters Graduate" Then
            educ = 9
        ElseIf ComboBoxEducation.Text = "Doctorate Level" Then
            educ = 10
        ElseIf ComboBoxEducation.Text = "Doctorate Graduate" Then
            educ = 11
        End If
        If TextBoxID.Text = "" Or
       TextBoxFname.Text = "" Or
       TextBoxLname.Text = "" Or
       ComboBoxGender.Text = "" Or
       TextBoxContact.Text = "" Or
       TextBoxEmail.Text = "" Or
       ComboBoxCivil.Text = "" Or
       ComboBoxYouthAge.Text = "" Or
       ComboBoxEducation.Text = "" Or
       ComboBoxClassification.Text = "" Or
        ComboBoxCivil.Text = "" Or
       ComboBoxWork.Text = "" Then
            MessageBox.Show("Missing Fields!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Try
                Dim db1 = New Database
                Dim dt1 As New DataTable
                With db1
                    .sqlStr = "delete from information_tbl where id='" & infoDataGridView.CurrentRow.Cells(0).Value & "'" 'query string
                    .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                    .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                    .close()
                End With
                Dim db = New Database
                With db
                    ''-----------------------------------------EMPTY TransactID---------
                    .sqlStr = "insert into information_tbl (id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                                        youth_classification,educ_id,work_status,brgy_id) values
                ('" & TextBoxID.Text.Trim & "','" & TextBoxLname.Text.Trim & "','" & TextBoxFname.Text.Trim & "','" & TextBoxMname.Text.Trim &
        "','" & ComboBoxGender.Text.Trim & "','" & DateTimePicker1.Text.Trim & "','" & TextBoxContact.Text.Trim & "','" & TextBoxEmail.Text.Trim &
        "','" & ComboBoxCivil.Text.Trim & "','" & ComboBoxYouthAge.Text.Trim & "','" & ComboBoxClassification.Text.Trim & "','" & educ &
                "','" & ComboBoxWork.Text.Trim & "','" & brgy1 & "')"
                    .sqlDa.InsertCommand = .sqlcm(.sqlStr, .connect)
                    .sqlDa.InsertCommand.ExecuteNonQuery()
                    .close()
                End With
                MessageBox.Show("Successfully Updated", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

                If Label14.Text = "Barangay Ayusan Norte" Then
                    loadFormBrgy1()
                ElseIf Label14.Text = "Barangay Ayusan Sur" Then
                    loadFormBrgy2()
                ElseIf Label14.Text = "Barangay I" Then
                    loadFormBrgy3()
                ElseIf Label14.Text = "Barangay II" Then
                    loadFormBrgy4()
                ElseIf Label14.Text = "Barangay III" Then
                    loadFormBrgy5()
                ElseIf Label14.Text = "Barangay IV" Then
                    loadFormBrgy6()
                ElseIf Label14.Text = "Barangay V" Then
                    loadFormBrgy7()
                ElseIf Label14.Text = "Barangay VI" Then
                    loadFormBrgy8()
                ElseIf Label14.Text = "Barangay VII" Then
                    loadFormBrgy9()
                ElseIf Label14.Text = "Barangay VIII" Then
                    loadFormBrgy10()
                ElseIf Label14.Text = "Barangay IX" Then
                    loadFormBrgy11()
                ElseIf Label14.Text = "Barangay Barraca" Then
                    loadFormBrgy12()
                ElseIf Label14.Text = "Barangay Beddeng Daya" Then
                    loadFormBrgy13()
                ElseIf Label14.Text = "Barangay Beddeng Laud" Then
                    loadFormBrgy14()
                ElseIf Label14.Text = "Barangay Bongtolan" Then
                    loadFormBrgy15()
                ElseIf Label14.Text = "Barangay Bulala" Then
                    loadFormBrgy16()
                ElseIf Label14.Text = "Barangay Cabalangegan" Then
                    loadFormBrgy17()
                ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
                    loadFormBrgy18()
                ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
                    loadFormBrgy19()
                ElseIf Label14.Text = "Barangay Camangaan" Then
                    loadFormBrgy20()
                ElseIf Label14.Text = "Barangay Capangpangan" Then
                    loadFormBrgy21()
                ElseIf Label14.Text = "Barangay Mindoro" Then
                    loadFormBrgy22()
                ElseIf Label14.Text = "Barangay Nagsangalan" Then
                    loadFormBrgy23()
                ElseIf Label14.Text = "Barangay Pantay Daya" Then
                    loadFormBrgy24()
                ElseIf Label14.Text = "Barangay Pantay Fatima" Then
                    loadFormBrgy25()
                ElseIf Label14.Text = "Barangay Pantay Laud" Then
                    loadFormBrgy26()
                ElseIf Label14.Text = "Barangay Paoa" Then
                    loadFormBrgy27()
                ElseIf Label14.Text = "Barangay Paratong" Then
                    loadFormBrgy28()
                ElseIf Label14.Text = "Barangay Pong-ol" Then
                    loadFormBrgy29()
                ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
                    loadFormBrgy30()
                ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
                    loadFormBrgy31()
                ElseIf Label14.Text = "Barangay Raois" Then
                    loadFormBrgy32()
                ElseIf Label14.Text = "Barangay Rugsaunan" Then
                    loadFormBrgy33()
                ElseIf Label14.Text = "Barangay Salindeg" Then
                    loadFormBrgy34()
                ElseIf Label14.Text = "Barangay San Jose" Then
                    loadFormBrgy35()
                ElseIf Label14.Text = "Barangay San Julian Norte" Then
                    loadFormBrgy36()
                ElseIf Label14.Text = "Barangay San Julian Sur" Then
                    loadFormBrgy37()
                ElseIf Label14.Text = "Barangay San Pedro" Then
                    loadFormBrgy38()
                ElseIf Label14.Text = "Barangay Tamag" Then
                    loadFormBrgy39()
                End If
                TextBoxID.Text = ""
                TextBoxFname.Text = ""
                TextBoxLname.Text = ""
                ComboBoxGender.Text = ""
                TextBoxContact.Text = ""
                TextBoxEmail.Text = ""
                ComboBoxCivil.Text = ""
                ComboBoxYouthAge.Text = ""
                ComboBoxEducation.Text = ""
                ComboBoxClassification.Text = ""
                ComboBoxCivil.Text = ""
                ComboBoxWork.Text = ""
                TextBoxID.Enabled = False
            Catch
                MessageBox.Show("Error")
            End Try
        End If

    End Sub

    Private Sub TextBoxSearch_TextChanged(sender As Object, e As EventArgs) Handles TextBoxSearch.TextChanged
        '     If ComboBox1.Text = "Last Name" Then
        SLastname()
        '  ElseIf ComboBox1.text = "First Name" Then
        '    SearchFirstname()
        '   ElseIf ComboBox1.text = "First Name" Then
        '   SearchFirstname()
        '   ElseIf ComboBox1.text = "Middle Name" Then
        '    Searchmiddlename()
        '     ElseIf ComboBox1.text = "Gender" Then
        '     Searchgender()
        '     ElseIf ComboBox1.text = "Birthday" Then
        '    SearchBirthday()
        '    ElseIf ComboBox1.text = "Contact Number" Then
        '    SearchContact()
        '     ElseIf ComboBox1.text = "Email" Then
        '    SearchEmail()
        '    ElseIf ComboBox1.text = "Civil Status" Then
        '    SearchCivilStatus()
        '    ElseIf ComboBox1.text = "Youth Age" Then
        '   SearchYouth_age()
        '   ElseIf ComboBox1.text = "Youth Classification" Then
        '    SearchYouth_age()
        '    ElseIf ComboBox1.text = "Educational Attainment" Then
        '    SearchEdu()
        '    ElseIf ComboBox1.text = "Work Status" Then
        '   SearchWorkStat()
        '    ElseIf ComboBox1.text = "ID" Then
        '    SearchID()
        '     End If
        If TextBoxSearch.Text = "" Then
            If Label14.Text = "Barangay Ayusan Norte" Then
                loadFormBrgy1()
            ElseIf Label14.Text = "Barangay Ayusan Sur" Then
                loadFormBrgy2()
            ElseIf Label14.Text = "Barangay I" Then
                loadFormBrgy3()
            ElseIf Label14.Text = "Barangay II" Then
                loadFormBrgy4()
            ElseIf Label14.Text = "Barangay III" Then
                loadFormBrgy5()
            ElseIf Label14.Text = "Barangay IV" Then
                loadFormBrgy6()
            ElseIf Label14.Text = "Barangay V" Then
                loadFormBrgy7()
            ElseIf Label14.Text = "Barangay VI" Then
                loadFormBrgy8()
            ElseIf Label14.Text = "Barangay VII" Then
                loadFormBrgy9()
            ElseIf Label14.Text = "Barangay VIII" Then
                loadFormBrgy10()
            ElseIf Label14.Text = "Barangay IX" Then
                loadFormBrgy11()
            ElseIf Label14.Text = "Barangay Barraca" Then
                loadFormBrgy12()
            ElseIf Label14.Text = "Barangay Beddeng Daya" Then
                loadFormBrgy13()
            ElseIf Label14.Text = "Barangay Beddeng Laud" Then
                loadFormBrgy14()
            ElseIf Label14.Text = "Barangay Bongtolan" Then
                loadFormBrgy15()
            ElseIf Label14.Text = "Barangay Bulala" Then
                loadFormBrgy16()
            ElseIf Label14.Text = "Barangay Cabalangegan" Then
                loadFormBrgy17()
            ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
                loadFormBrgy18()
            ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
                loadFormBrgy19()
            ElseIf Label14.Text = "Barangay Camangaan" Then
                loadFormBrgy20()
            ElseIf Label14.Text = "Barangay Capangpangan" Then
                loadFormBrgy21()
            ElseIf Label14.Text = "Barangay Mindoro" Then
                loadFormBrgy22()
            ElseIf Label14.Text = "Barangay Nagsangalan" Then
                loadFormBrgy23()
            ElseIf Label14.Text = "Barangay Pantay Daya" Then
                loadFormBrgy24()
            ElseIf Label14.Text = "Barangay Pantay Fatima" Then
                loadFormBrgy25()
            ElseIf Label14.Text = "Barangay Pantay Laud" Then
                loadFormBrgy26()
            ElseIf Label14.Text = "Barangay Paoa" Then
                loadFormBrgy27()
            ElseIf Label14.Text = "Barangay Paratong" Then
                loadFormBrgy28()
            ElseIf Label14.Text = "Barangay Pong-ol" Then
                loadFormBrgy29()
            ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
                loadFormBrgy30()
            ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
                loadFormBrgy31()
            ElseIf Label14.Text = "Barangay Raois" Then
                loadFormBrgy32()
            ElseIf Label14.Text = "Barangay Rugsaunan" Then
                loadFormBrgy33()
            ElseIf Label14.Text = "Barangay Salindeg" Then
                loadFormBrgy34()
            ElseIf Label14.Text = "Barangay San Jose" Then
                loadFormBrgy35()
            ElseIf Label14.Text = "Barangay San Julian Norte" Then
                loadFormBrgy36()
            ElseIf Label14.Text = "Barangay San Julian Sur" Then
                loadFormBrgy37()
            ElseIf Label14.Text = "Barangay San Pedro" Then
                loadFormBrgy38()
            ElseIf Label14.Text = "Barangay Tamag" Then
                loadFormBrgy39()
            End If
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub brgyform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolTip1.SetToolTip(btnBack, "Back")
        ToolTip1.SetToolTip(btnClear, "Clear")
        ToolTip1.SetToolTip(btnSave, "Save")
        ToolTip1.SetToolTip(btnDelete, "Delete")
        ToolTip1.SetToolTip(btnEdit, "Edit")
        ToolTip1.SetToolTip(Button1, "Update")
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Dim dt1 As New DataTable

        dt1.Columns.Add("ID", Type.GetType("System.String"))
        dt1.Columns.Add("Last name", Type.GetType("System.String"))
        dt1.Columns.Add("First name", Type.GetType("System.String"))
        dt1.Columns.Add("Middle name", Type.GetType("System.String"))
        dt1.Columns.Add("Gender", Type.GetType("System.String"))
        dt1.Columns.Add("Birthday", Type.GetType("System.String"))
        dt1.Columns.Add("Contact No.", Type.GetType("System.String"))
        dt1.Columns.Add("Email", Type.GetType("System.String"))
        dt1.Columns.Add("Civil Status", Type.GetType("System.String"))
        dt1.Columns.Add("Youth Age", Type.GetType("System.String"))
        dt1.Columns.Add("Youth Classification", Type.GetType("System.String"))
        dt1.Columns.Add("Education", Type.GetType("System.String"))
        dt1.Columns.Add("Work Status", Type.GetType("System.String"))
        dt1.Columns.Add("Barangay", Type.GetType("System.String"))
        For Each row As DataGridViewRow In infoDataGridView.Rows
            dt1.Rows.Add(row.Cells(0).Value,
                         row.Cells(1).Value,
                         row.Cells(2).Value,
                         row.Cells(3).Value,
                         row.Cells(4).Value,
                         row.Cells(5).Value,
                         row.Cells(6).Value,
                         row.Cells(7).Value,
                         row.Cells(8).Value,
                         row.Cells(9).Value,
                         row.Cells(10).Value,
                         row.Cells(11).Value,
                         row.Cells(12).Value,
            row.Cells(13).Value)
        Next
        Form2.Show()
        Dim report As New CrystalReport1
        report.SetDataSource(dt1)
        Form2.CrystalReportViewer1.ReportSource = report

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub
    Public Sub SLastname()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (lastname like '%" & TextBoxSearch.Text.Trim & "%' or  id like '%" & TextBoxSearch.Text.Trim & "%' or
                        firstname like '%" & TextBoxSearch.Text.Trim & "%') & (brgy_id = " & brgy1 & ") order by lastname ASC"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SearchFirstname()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (firstname like '%" & TextBoxSearch.Text.Trim & "%') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub Searchmiddlename()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (middlename like '%" & TextBoxSearch.Text.Trim & "%') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SearchBirthday()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (birthday like '%" & TextBoxSearch.Text.Trim & "%') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SearchContact()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (contact_no like '%" & TextBoxSearch.Text.Trim & "%') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SearchEmail()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (email like '%" & TextBoxSearch.Text.Trim & "%') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SearchCivilStatus()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (civil_status like '%" & TextBoxSearch.Text.Trim & "%') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SearchYouth_age()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (youth_age like '%" & TextBoxSearch.Text.Trim & "%') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub Searchclassification()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (youth_classification like '%" & TextBoxSearch.Text.Trim & "%') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub Searchgender()
        Dim brgy1 As Integer = 0

        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (gender = '" & TextBoxSearch.Text.Trim & "') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If


            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SearchEdu()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age, youth_classification, educ_id, work_status from information_tbl where educ_id In (SELECT educ_id from educ_tbl where (educational_level like '%" & TextBoxSearch.Text.Trim & "%')) AND (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SearchWorkStat()
        Dim brgy1 As Integer = 0

        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (work_status = '" & TextBoxSearch.Text.Trim & "') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If


            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub
    Public Sub SearchID()
        Dim brgy1 As Integer = 0
        If Label14.Text = "Barangay Ayusan Norte" Then
            brgy1 = 1
        ElseIf Label14.Text = "Barangay Ayusan Sur" Then
            brgy1 = 2
        ElseIf Label14.Text = "Barangay I" Then
            brgy1 = 3
        ElseIf Label14.Text = "Barangay II" Then
            brgy1 = 4
        ElseIf Label14.Text = "Barangay III" Then
            brgy1 = 5
        ElseIf Label14.Text = "Barangay IV" Then
            brgy1 = 6
        ElseIf Label14.Text = "Barangay V" Then
            brgy1 = 7
        ElseIf Label14.Text = "Barangay VI" Then
            brgy1 = 8
        ElseIf Label14.Text = "Barangay VII" Then
            brgy1 = 9
        ElseIf Label14.Text = "Barangay VIII" Then
            brgy1 = 10
        ElseIf Label14.Text = "Barangay IX" Then
            brgy1 = 11
        ElseIf Label14.Text = "Barangay Barraca" Then
            brgy1 = 12
        ElseIf Label14.Text = "Barangay Beddeng Daya" Then
            brgy1 = 13
        ElseIf Label14.Text = "Barangay Beddeng Laud" Then
            brgy1 = 14
        ElseIf Label14.Text = "Barangay Bongtolan" Then
            brgy1 = 15
        ElseIf Label14.Text = "Barangay Bulala" Then
            brgy1 = 16
        ElseIf Label14.Text = "Barangay Cabalangegan" Then
            brgy1 = 17
        ElseIf Label14.Text = "Barangay Cabaroan Daya" Then
            brgy1 = 18
        ElseIf Label14.Text = "Barangay Cabaroan Laud" Then
            brgy1 = 19
        ElseIf Label14.Text = "Barangay Camangaan" Then
            brgy1 = 20
        ElseIf Label14.Text = "Barangay Capangpangan" Then
            brgy1 = 21
        ElseIf Label14.Text = "Barangay Mindoro" Then
            brgy1 = 22
        ElseIf Label14.Text = "Barangay Nagsangalan" Then
            brgy1 = 23
        ElseIf Label14.Text = "Barangay Pantay Daya" Then
            brgy1 = 24
        ElseIf Label14.Text = "Barangay Pantay Fatima" Then
            brgy1 = 25
        ElseIf Label14.Text = "Barangay Pantay Laud" Then
            brgy1 = 26
        ElseIf Label14.Text = "Barangay Paoa" Then
            brgy1 = 27
        ElseIf Label14.Text = "Barangay Paratong" Then
            brgy1 = 28
        ElseIf Label14.Text = "Barangay Pong-ol" Then
            brgy1 = 29
        ElseIf Label14.Text = "Barangay Purok-a-bassit" Then
            brgy1 = 30
        ElseIf Label14.Text = "Barangay Purok-a-dackel" Then
            brgy1 = 31
        ElseIf Label14.Text = "Barangay Raois" Then
            brgy1 = 32
        ElseIf Label14.Text = "Barangay Rugsaunan" Then
            brgy1 = 33
        ElseIf Label14.Text = "Barangay Salindeg" Then
            brgy1 = 34
        ElseIf Label14.Text = "Barangay San Jose" Then
            brgy1 = 35
        ElseIf Label14.Text = "Barangay San Julian Norte" Then
            brgy1 = 36
        ElseIf Label14.Text = "Barangay San Julian Sur" Then
            brgy1 = 37
        ElseIf Label14.Text = "Barangay San Pedro" Then
            brgy1 = 38
        ElseIf Label14.Text = "Barangay Tamag" Then
            brgy1 = 39
        End If
        Try
            Dim db = New Database
            Dim dt As New DataTable
            With db
                .sqlStr = "SELECT id,lastname,firstname,middlename,gender,birthday,contact_no,email,civil_status,youth_age,
                        youth_classification,educ_id,work_status from information_tbl where (id like '%" & TextBoxSearch.Text.Trim & "%') & (brgy_id = " & brgy1 & ")"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt.
                .close()
            End With
            dt = db.sqlDt
            infoDataGridView.Rows.Clear()
            For i = 0 To dt.Rows.Count - 1
                infoDataGridView.Rows.Add()
                infoDataGridView.Rows(i).Cells(0).Value = dt.Rows(i).Item(0).ToString
                infoDataGridView.Rows(i).Cells(1).Value = dt.Rows(i).Item(1).ToString
                infoDataGridView.Rows(i).Cells(2).Value = dt.Rows(i).Item(2).ToString
                infoDataGridView.Rows(i).Cells(3).Value = dt.Rows(i).Item(3).ToString
                infoDataGridView.Rows(i).Cells(4).Value = dt.Rows(i).Item(4).ToString
                infoDataGridView.Rows(i).Cells(5).Value = Format(Convert.ToDateTime(dt.Rows(i).Item(5).ToString), "MM/dd/yyy")
                infoDataGridView.Rows(i).Cells(6).Value = dt.Rows(i).Item(6).ToString
                infoDataGridView.Rows(i).Cells(7).Value = dt.Rows(i).Item(7).ToString
                infoDataGridView.Rows(i).Cells(8).Value = dt.Rows(i).Item(8).ToString
                infoDataGridView.Rows(i).Cells(9).Value = dt.Rows(i).Item(9).ToString
                infoDataGridView.Rows(i).Cells(10).Value = dt.Rows(i).Item(10).ToString
                infoDataGridView.Rows(i).Cells(11).Value = dt.Rows(i).Item(11).ToString
                infoDataGridView.Rows(i).Cells(12).Value = dt.Rows(i).Item(12).ToString
                If dt.Rows(i).Item(11).ToString = "1" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Level"
                ElseIf dt.Rows(i).Item(11).ToString = "2" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Elementary Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "3" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Level"
                ElseIf dt.Rows(i).Item(11).ToString = "4" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "High School Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "5" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Vocational Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "6" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Level"
                ElseIf dt.Rows(i).Item(11).ToString = "7" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "College Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "8" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Level"
                ElseIf dt.Rows(i).Item(11).ToString = "9" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Masters Graduate"
                ElseIf dt.Rows(i).Item(11).ToString = "10" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Level"
                ElseIf dt.Rows(i).Item(11).ToString = "11" Then
                    infoDataGridView.Rows(i).Cells(11).Value = "Doctorate Graduate"

                End If



            Next
        Catch
            MessageBox.Show("Error")
        End Try
    End Sub



    Private Sub TextBoxContact_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBoxContact.KeyPress
        If Asc(e.KeyChar) < 4 Or Asc(e.KeyChar) > 57 Then
            e.Handled = True
            MessageBox.Show("Please type numbers", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        End If
    End Sub

    Private Sub TextBoxContact_TextChanged(sender As Object, e As EventArgs) Handles TextBoxContact.TextChanged

    End Sub

    Private Sub TextBoxID_TextChanged(sender As Object, e As EventArgs) Handles TextBoxID.TextChanged

    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        brgy_stat.Show()
        With cn
            .ConnectionString = "Server=157.245.54.54; user id = thesis; password=2022Thesis!; database = sk_tionery_db"
            .Open()
        End With
        brgy_stat.loadGender()
        brgy_stat.loadCivilStat()
        brgy_stat.loadYouthAge()
        brgy_stat.loadClassification()
        brgy_stat.loadEduc()
        brgy_stat.loadWork()
        brgy_stat.total()

        If cn.State = ConnectionState.Open Then
            cn.Close()
        End If
    End Sub



    Private Sub TextBoxFname_TextChanged(sender As Object, e As EventArgs) Handles TextBoxFname.TextChanged
        '  TextBoxFname.Text = StrConv(TextBoxFname.Text, vbProperCase)

    End Sub

    Private Sub TextBoxLname_TextChanged(sender As Object, e As EventArgs) Handles TextBoxLname.TextChanged
        '  TextBoxLname.Text = StrConv(TextBoxLname.Text, vbProperCase)
    End Sub

    Private Sub TextBoxMname_TextChanged(sender As Object, e As EventArgs) Handles TextBoxMname.TextChanged
        '   TextBoxMname.Text = StrConv(TextBoxMname.Text, vbProperCase)
    End Sub

    Private Sub TextBoxFname_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBoxFname.KeyUp
        TextBoxFname.Text = Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(TextBoxFname.Text)
        TextBoxFname.SelectionStart = TextBoxFname.TextLength + 1
    End Sub

    Private Sub TextBoxLname_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBoxLname.KeyUp
        TextBoxLname.Text = Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(TextBoxLname.Text)
        TextBoxLname.SelectionStart = TextBoxLname.TextLength + 1
    End Sub

    Private Sub TextBoxMname_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBoxMname.KeyUp
        TextBoxMname.Text = Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(TextBoxMname.Text)
        TextBoxMname.SelectionStart = TextBoxMname.TextLength + 1
    End Sub
End Class