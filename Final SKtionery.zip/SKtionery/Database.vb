﻿Imports MySql.Data.MySqlClient
Public Class Database

    Dim conn As New MySqlConnection
    Public sqlDa As MySqlDataAdapter = New MySqlDataAdapter()
    Public sqlDt As DataTable = New DataTable()
    Public sqlStr As String

    Private datasource As String = "157.245.54.54" 'default
    Private username As String = "thesis" 'default
    Private password As String = "2022Thesis!"
    Private database As String = "sk_tionery_db" 'change
    Private port As String = "3306" 'default

    Private cnString As String = "datasource=" + datasource + ";database=" + database + ";uid=" + username + ";pwd=" + password + ";port=" + port
    'this function will establish a connection
    Public Function connect() As MySqlConnection
        Try
            conn = New MySqlConnection(cnString)
            conn.Open()

        Catch
            MessageBox.Show("Connection Failed", "System Admin")
            Application.Exit()
        End Try
        Return conn
    End Function
    'sqlcm is a mysqlcommand that will take a sql command ex:(select *) and a mysqlconnection;sqlcm will be passed to the MySqlDataAdapter
    Public Function sqlcm(ByVal str As String, ByVal sqlcon As MySqlConnection) As MySqlCommand

        Dim cm As MySqlCommand = New MySqlCommand(str, sqlcon)
        Return cm

    End Function

    Public Function close()
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        Return False
    End Function

End Class

