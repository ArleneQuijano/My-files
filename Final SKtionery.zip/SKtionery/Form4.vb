﻿Public Class Form4
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            Dim db1 = New Database
            Dim dt1 As New DataTable
            With db1
                .sqlStr = "SELECT concat (`firstname`,' ',lastname) as fullname, password, user_id,brgy_id from account_tbl where concat (firstname,' ',lastname) = '" & menuForm.Label23.Text & "'"
                .sqlDa.SelectCommand = .sqlcm(.sqlStr, .connect) 'execute command
                .sqlDa.Fill(.sqlDt) 'get results and store in sqldt
                .close()
            End With
            dt1 = db1.sqlDt
            If dt1.Rows(0)("password") = TextBox2.Text Then
                MessageBox.Show("Success", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                If Label2.Text = "Download File" Then
                    menuForm.download()
                    Me.Close()
                ElseIf Label2.Text = "Delete File" Then
                    menuForm.delete()
                    Me.Close()
                ElseIf Label2.Text = "Approve File" Then
                    menuForm.approve()
                    Me.Close()
                Else
                    MessageBox.Show("error")
                End If
            Else
                MessageBox.Show("Wrong password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch
            MessageBox.Show("Wrong password", "error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class